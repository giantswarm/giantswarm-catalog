# agent-platform

Giant Swarm Agent Platform — MCP gateway deploy unit, packaged as an
app-of-apps meta-package. Renders each component (muster, agentgateway, kagent,
klaus-gateway, valkey, agent-platform-mcps, agent-sandbox, …) and the consumer-side
connectivity layer as a Flux OCIRepository + HelmRelease (Flux is the only
render engine), with each component's version expressed as a value RANGE rather
than a Chart.yaml pin — so a component release rolls forward with no PR to this
chart. Brings its own Flux engine (the flux-engine subchart: Flux Operator +
FluxInstance) where a cluster has none, so `helm install` yields a running
platform; a cluster that runs Flux sets components.flux.enabled=false. Each
component ships its own CRDs (app-owned CRDs, upgraded via Flux CreateReplace);
the Gateway API CRDs and GatewayClass remain cluster-level prerequisites — see
README.

**Homepage:** <https://github.com/giantswarm/agent-platform>

## Source Code

* <https://github.com/giantswarm/agent-platform>

## Requirements

| Repository | Name | Version |
|------------|------|---------|
|  | flux-engine | 0.1.0 |

## One release per target cluster

The serving slice ([#326](https://github.com/giantswarm/agent-platform/issues/326)) and the runtime slice
([#317](https://github.com/giantswarm/agent-platform/issues/317)) are values profiles of this chart that cluster-manager
installs as **one `<cluster>-agent-platform` release per target cluster**, the slices as toggles in its values — created
with the first slice, its values updated in place when the second is switched on, never two releases of the chart on one
cluster (both slices need agentgateway's cluster-scoped CRDs, which have exactly one owner). Such a release runs beside
the platform's own release on the installation's cluster, or installs onto a workload cluster that runs no Flux
([#328](https://github.com/giantswarm/agent-platform/issues/328), bumblebee-plans#46). Four knobs serve that shape:

- **`gitops.target.kubeConfig.secretRef`** — the target cluster. Set `name` (and `key` when the Secret's key is not
  helm-controller's default) to the kubeconfig Secret of the target in the release namespace — the fleet's
  `<cluster>-kubeconfig` — and every component HelmRelease this chart renders carries `spec.kubeConfig.secretRef`
  verbatim, the connectivity release included: the installation's helm-controller installs each component into the
  target from the OCIRepositories in the release namespace, `dependsOn` intact, `install.createNamespace` creating the
  target namespaces there, the connectivity chart's `lookup` / Capabilities guards evaluated against the target. Unset,
  the render is byte-identical to a chart without the key. The bundled engine is refused with it (`components.flux.enabled`
  must be `false`: no Flux is installed into a workload cluster, nor into a cluster that runs one), and no Helm hook of
  this chart renders with it (a hook Job runs where the chart is installed, not on the target).
- **`components.muster.enabled`, `components.dicebear.enabled`** (default `true`) — a slice release turns them off: the
  installation's muster serves every agent, the avatars are the portal's. The connectivity chart reads the same roster
  and renders none of their wiring while they are off (muster's `/mcp` route and egress policy, every policy rule that
  selects its pods, the avatars host in the portal's CSP). `components.agentgateway.enabled` follows the target: **on**
  for a workload cluster, **off** beside the platform's release, which owns the controller and its CRDs.
- **`components.<name>.ownedCrds`** — one owner per cluster-scoped component. When a CRD a component installs already
  exists on the cluster the chart renders against and its Flux labels (`helm.toolkit.fluxcd.io/name`, `/namespace` —
  helm-controller stamps them on every object of a release, `crds/` included) name another HelmRelease than the one this
  render produces, the render fails naming that release: remove it first, or turn the component off in this release.
  Skipped with the target knob, where the render's lookups see the installation while the components land on the target
  (what the target already runs is the composer's to detect). A CRD without the labels is left to Helm as before.
  `components.gpu-operator` adds its own guard on the same principle — a `ClusterPolicy`, HelmRelease or App of the
  operator that is not this release's fails the render naming the handover (root README, "The GPU operator").

`make verify-target` asserts the offline half (`tests/verify-target.py`): the knob's stamp and byte-identity, the
toggles on both charts, the engine guard, the hooks, the serving- and runtime-shaped toggle sets alone, combined and
targeted (`ci/test-slice-*-values.yaml`, `ci/test-target-values.yaml`). The two `lookup` guards need a cluster — on one
that runs Flux (the agentlab, an installation), from a checkout:

```sh
# a foreign helm-controller with the bundled engine on → "this cluster runs Flux; set components.flux.enabled=false …"
helm install t helm/agent-platform -n ap-guard --create-namespace --dry-run=server -f helm/agent-platform/ci/ci-values.yaml
# a second owner of a component's CRDs → "… has exactly one owner per cluster … belongs to HelmRelease <ns>/<name>. Remove that release first …"
helm install t helm/agent-platform -n ap-guard --create-namespace --dry-run=server -f helm/agent-platform/ci/test-slice-serving-values.yaml --set components.agentgateway.enabled=true
```

## Agent Substrate: worker capacity

On kagent API v2 an agent runs as an Agent Substrate actor inside a gVisor worker
pod of a `WorkerPool`. The connectivity chart renders one platform `Harness` that
names this pool (`kagent.substrateWorkerPool.name`, default `kagent-default`); the
pool is the platform's only capacity and scheduling knob, since the Generic agent
chart 1.x carries no per-agent `runtime`, `replicas`, `resources`, `nodeSelector`
or `tolerations`.

- **A worker hosts many actors at once.** A Substrate worker (`ateom`) runs up to
  its `--max-actors` actors, default `1000`; the flag is the worker's own and no
  `WorkerPool` field or chart value sets it, so every worker of the pool takes the
  default and answers `worker is full` beyond it. `kagent.substrateWorkerPool.replicas`
  (default `4`) therefore sets the pool's actor ceiling (`replicas × 1000`) and
  its failure domain; in practice the worker's `resources.limits`, shared by the
  actors it hosts, bound the concurrently active agents long before the count
  does. An idle agent holds no worker. Raise `replicas` for more capacity — the
  node pool budgets `replicas × the worker's limits`.
- **A worker's resources are shared by its actors' sandboxes.**
  `kagent.substrateWorkerPool.template.resources.limits` bound the worker, and with
  it the sum of the sandboxes it hosts (a sandbox's memory is RAM of the worker,
  its CPU counts against the worker's vCPUs). The defaults request
  `250m` / `512Mi` and limit to `2` vCPU / `2Gi`. Measured in agentlab: an idle
  worker holds ~16Mi and a golden-booted actor ~20Mi; a Go ADK turn's working set
  (the model client, tool calls and gVisor overhead) stays well under `2Gi`.
  Raise the limits for heavier agents.
- **One CPU feature set per pool — one vendor and generation, not just one
  architecture.** An actor's golden snapshot is a gVisor checkpoint, and gVisor
  restores it only on a host whose CPU offers every feature the checkpoint
  recorded; a worker on a CPU that lacks one fails every restore placed on it
  (`incompatible FeatureSet: missing features: …` in its log every 30 s, the
  turn `request timed out`) and the actor never recovers.
  `kagent.substrateWorkerPool.template.nodeSelector` pins the pool as precisely
  as the provider's node labels allow: the architecture (`kubernetes.io/arch:
  amd64` by default; an arm64 installation sets `arm64`), and on CAPA — where
  Karpenter consolidation may replace a node with another vendor's at any time —
  the vendor, `karpenter.k8s.aws/instance-cpu-manufacturer: amd`, and the CPU
  generation, `karpenter.k8s.aws/instance-generation: "6"` (quoted — a label
  value is a string, and the render refuses a bare number), both rendered by
  the fleet template from the installation's values: a snapshot taken on a
  newer generation of one vendor does not restore on an older one either
  (gazelle, 2026-09-14: goldens from `m7a` workers, generation 7, failed on
  `c5ad`, generation 5, `missing features: … avx512f …`;
  giantswarm/agent-platform#457). Pin a generation that is one CPU model
  across its families (for AMD on AWS 6, `c6a`/`m6a`/`r6a`, or 7,
  `c7a`/`m7a`/`r7a`; 5 mixes Naples `m5a`/`r5a` with Rome `c5a`/`c5ad`) and
  one the goldens restore on — an older generation's golden restores on a
  newer one, never the reverse — and check the spot pool it leaves (the
  generation's families × the NodePool's sizes; three families is the floor).
  The family (`karpenter.k8s.aws/instance-family`) narrows to one type where
  even that matters; on CAPZ and the other providers the node pool
  (`giantswarm.io/machine-pool`) or `node.kubernetes.io/instance-type` pins
  it. Recognise a mixed pool by `kubectl get nodes -L <the label>` showing two
  values under it (giantswarm/agent-platform#429, #457). `make
  verify-workerpool` asserts the pin reaches the WorkerPool as written.

`kagent.substrateWorkerPool.template` also accepts `labels`, `annotations`,
`tolerations`, `nodeAffinity` and `priorityClassName` — the
`WorkerPool.spec.template` fields of the pinned Substrate line, and nothing else:
the CRD is a structural schema, so a key it does not know is **pruned at
admission, silently**, and the render refuses it instead
(`agent-platform.validateWorkerPool`). See UPGRADE.md, "the Generic chart's
per-agent placement values are gone, capacity is the WorkerPool".

### One source of the Substrate version: `components.substrate.versionRange` (giantswarm/agent-platform#466, giantswarm/agent-platform#822)

The Substrate version an installation runs is **the release Flux resolves from
`components.substrate.versionRange`** (`components.substrate-crds.versionRange`
carries the same range), and nothing else names it. The control plane runs it,
and so do the workers: ate-controller starts every gVisor pool on its own
release's `ateom-gvisor` (`ateController.gvisorWorker.followRelease`, which this
chart sets on the substrate release; giantswarm/substrate#114). A Substrate
patch within the range (`1.13.0` → `1.13.1`) rolls the control plane, the atelet
and the worker pool together, **with no chart release**.

The WorkerPool's `spec.workerImage` is **derived by this chart** from the range's
floor: `<substrate.image.registry>/ateom-gvisor:<floor>`
(`gsoci.azurecr.io/giantswarm/substrate/ateom-gvisor:1.17.0` today), merged over
the kagent block the chart forwards. It is the image the pool runs right after a
re-pin. The pool's `status.workerImage` names the image its pods run; after a patch
it is the patch, and the condition `WorkerImageOverridden` is `True` (reason
`GVisorWorkerImageFlag`) until the floor moves. The kagent chart stamps a worker of
its own at publish (the Substrate its build was published against), and that stamp
never reaches the cluster: the atelet the substrate release installs and the worker
the WorkerPool runs are one Substrate release **whatever kagent build the kagent
range admits**. Chart 4.15.2 showed why. Its open kagent range admitted a build
that stamped the next Substrate's worker under the chart's older atelet. That
Substrate had renamed the pause bundle, so every golden boot failed on
`bundles/_pause/config.json`, every AgentTemplate stayed `Ready=False … compiling`,
and nothing on any hop named the skew.

What follows from it:

- **`kagent.substrateWorkerPool.workerImage` stays empty.** An installation that
  sets it names an `ateom-gvisor` image **tagged with the pinned release** (a mirror
  by a path other than `substrate.image.registry`, which the derived image already
  follows); another tag, or a digest alone, fails the render naming the key, the
  release and the derived image.
- **`substrate.ateController.gvisorWorker.followRelease` stays unset.** The chart
  sets it; `false` fails the render, because the workers would then run the floor
  beside a later patch's atelet. The flag exists from Substrate `1.4.0` on;
  `make verify-worker-image` fails when the chart the range resolves to lacks it.
- **The Substrate range confines one runtime contract**: an exact version (the
  BOM's `1.17.0`) or `>=X.Y.Z <X.(Y+1).0`, the ceiling of the pinned minor and no
  `-0` anywhere. Flux's Masterminds semver skips every prerelease while no bound
  of a range carries one, and evaluates them all once one does, so `<1.1.0-0`
  would admit the line's dev builds. A patch of the line is carried patches or a
  rebuild on the same upstream pin and never changes the worker and atelet bundle
  layout; a re-pin onto another upstream release is at least a minor. So a patch
  rolls the pool on its own, and a minor never changes under a pool without its
  range moving. `0.x`, `~`, `^`, a `-0` bound, a `<=` ceiling, a patch ceiling, a
  floor alone or the former `>=X.Y.Z-gs.N <X.Y.(Z+1)-0` fail the render
  (`agent-platform.substrate.validateRange`).
- **Substrate follows `gitops.prereleases`** like every component: a candidate's
  atelet and worker are one build, as a patch's are. Before `1.4.0`, a `1.3.1`
  candidate's atelet beside the floor's `1.3.0` worker failed every gVisor actor
  at its pause container, which is why the chart kept Substrate on stable
  releases from giantswarm/agent-platform#796 until giantswarm/agent-platform#795.
- **A worker roll keeps the conversations.** The pool's Deployment rolls 10 % of
  its workers at a time (at least one, no surge); a worker that is stopped passes
  SIGTERM to its actors and waits up to an hour for them. A session's
  conversation lives in kagent's database and its snapshot in the object store,
  not on the worker, and a patch changes no persisted format, so the session
  resumes on another worker. A turn still running when its worker's grace ends
  is lost.
- **A Substrate re-pin is one values change**, `components.substrate.versionRange`
  and `components.substrate-crds.versionRange` together; it **rolls the pool once**.
  The kagent range moves on its own,
  when the kagent line's pin moves. `make verify-worker-image` fails the day the
  kagent build the range admits was published against another Substrate release
  than the chart pins (its `Chart.yaml` names it), so the two are moved together,
  and it fails when the substrate chart the range resolves to would run its
  workers on another release than its atelet.

### The Google access-token credential provider runs beside Substrate (giantswarm/giantswarm#38547)

A Vertex AI `ModelConfig` (`GeminiVertexAI`, `AnthropicVertexAI`) with a
service account key binds `ate-secret://google-access-token.k8s.io/...` on
the Vertex AI hostname, and the egress gateway injects an access token minted
from the key. The minting is a Substrate credential provider plugin of its own,
`components.google-access-token-credential-provider`
([giantswarm/substrate-credential-providers](https://github.com/giantswarm/substrate-credential-providers)),
in upstream's plugin shape: a Deployment in `ate-system` behind mutual TLS,
serving the class the Substrate chart routes to it through
`substrate.credentialProvider.additionalProviders`. It follows
`components.kagent` like the Substrate entries and takes its grants from
`substrate.credentialProvider.namespacePolicies` (one list for both providers;
`agent-platform.componentDerivedValues`). Its CiliumNetworkPolicy opens
`oauth2.googleapis.com:443` for the exchange; the bundled provider reads
Secrets only and reaches the apiserver and DNS
(`networkPolicy.substrate.credentialProvider.egressFQDNs`, `[]` by default).
The Substrate line served the class from its bundled provider until 1.11: the
plugin is deployed first, and the routing entry lands with the floor move to
1.12, where the bundled name is gone.

### The one pool is the failure domain (giantswarm/agent-platform#472)

Every agent runs on this one pool, and a worker that goes loses the turn in flight
on it and every session paused on it (a pause checkpoint is node-local,
giantswarm/giantswarm#37795). On a Karpenter installation all four workers may
bin-pack onto one spot node (gazelle, 2026-09-15). The knobs, in the order they
help:

- **`kagent.substrateWorkerPool.podDisruptionBudget`** (`enabled: true`,
  `maxUnavailable: 1`, `unhealthyPodEvictionPolicy: AlwaysAllow` — **on by
  default**): a `PodDisruptionBudget` named after the pool in the kagent
  namespace, rendered by the connectivity chart (the kagent chart has no budget
  template), selecting `ate.dev/worker-pool: <name>`, the label Substrate's
  ate-controller puts on every worker pod. A voluntary drain — Karpenter
  consolidation, a node roll, `kubectl drain` — moves one worker at a time
  (`ALLOWED DISRUPTIONS 1` with four Ready workers) instead of the whole pool.
  Exactly one of `minAvailable` / `maxUnavailable`; the render refuses both,
  neither, and a policy outside the API's enum. `enabled: false` removes it. The
  knob never reaches the kagent release (`components.kagent.omitKeys`).
- **`substrate.ateController.busyWorker.annotations`**
  `karpenter.sh/do-not-disrupt: "true"` (**on by default**;
  giantswarm/agent-platform#1014): ate-controller sets the annotation, and the
  label `ate.dev/busy=true`, on a worker pod while it hosts at least one actor
  and removes both once it hosts none (re-read every 5 s,
  `substrate.ateController.busyWorker.syncPeriod`). A worker's SIGTERM stops
  the actors on it, so Karpenter's consolidation, drift and expiry leave a
  busy worker's node alone, and the nodes of idle workers stay consolidatable;
  `kubectl get pods -n kagent -l ate.dev/busy=true` lists the busy workers.
  A drift or expiry roll waits for the node's workers to go idle, or until the
  NodePool's `terminationGracePeriod` (the fleet's `30m`). Needs a Substrate
  release with the marking (giantswarm/substrate#425); an older one ignores
  the key. `{}` turns it off. Karpenter-only, harmless elsewhere.
- **`kagent.substrateWorkerPool.template.annotations`**
  `karpenter.sh/do-not-disrupt: "true"` (**off**; an installation's choice):
  Karpenter's consolidation, drift and expiry never drain a worker node, idle
  or busy. Caveat:
  a drift or expiry roll then waits on that node until the NodePool's
  `terminationGracePeriod` — the fleet's NodePools set `30m`, a NodePool without
  one never rolls the node while a worker is on it; Substrate's own upgrade
  runbook wants worker nodes rolled deliberately anyway. Karpenter-only, harmless
  elsewhere (an annotation nothing reads).
- **`kagent.substrateWorkerPool.template.nodeSelector`**
  `karpenter.sh/capacity-type: on-demand` (**off**; the fleet template renders it
  from an installation's `agentPlatform.workerPoolCapacityType`): the only knob
  that covers a **spot interruption** — an involuntary disruption the budget and
  the annotation cannot stop: the instance goes two minutes after the notice —
  at on-demand prices for the worker nodes. Karpenter-only: **never on CAPZ,
  on-prem or a CAPA pool that cluster-aws node pools provision** — no node
  carries the label there and the workers stay `Pending`.
- **`kagent.substrateWorkerPool.priorityClass`** (`enabled: true`, `name:
  agent-platform-worker-pool`, `value: 1000000` — **on by default**;
  giantswarm/agent-platform#999): a `PriorityClass` rendered by the connectivity
  chart, which the meta chart names in the pool's `template.priorityClassName`.
  atelet's `ate-node-critical` (`PreemptLowerPriority`) evicts the lowest-priority
  pods of a full node to make room; without a class the workers run at the
  default priority 0 and are among the first victims. Above 0 the ordinary
  workloads go first; below the cluster's own classes (monitoring, the
  platform's, atelet's `1000000000`) they still outrank a worker.
  `preemptionPolicy: Never`: a pending worker evicts nothing itself. An
  installation's own `template.priorityClassName` stands instead; `enabled:
  false` renders no class and names none; the render refuses a value outside
  1..999999999 and a `system-` name. The value is immutable on the API: change it
  under a new name. Setting or moving the name rolls the pool once.

**Every change to `template`** — a label, an annotation, a selector, the
resources — rolls the pool's Deployment once (`RollingUpdate` 25 %/25 %, one
worker at a time under the budget; about a minute per worker on a node that is
up, about three when Karpenter has to launch one). A turn in flight on a replaced
worker is lost, a session paused on it too; the goldens are untouched (a template
change re-snapshots nothing). Land it in a quiet window.

**Spread.** `WorkerPool.spec.template` carries `topologySpreadConstraints` and
`podAntiAffinity` from the Substrate line's `1.0.0` on (the carried patch
giantswarm/giantswarm#37797) — every release before it prunes both silently. The
render **refuses the two keys** naming the key, the floor and the range while
`components.substrate.versionRange`'s floor is below that release
(`agent-platform.substrate.workerPoolSpreadFloor` names it), and forwards them
verbatim from it on. Recommended: hostname `maxSkew: 1`, `minDomains: 2`,
`whenUnsatisfiable: DoNotSchedule` (the provisioner adds the second node) and
zone `maxSkew: 1`, `ScheduleAnyway`, both with a `labelSelector` on
`ate.dev/worker-pool: <name>` — what the fleet template renders behind its knob.
A spread is a template change and rolls the pool's Deployment once (above).
`make verify-workerpool` asserts all of it: the budget, the priority class and
the derived class name, the two knobs reaching the kagent release and the
`WorkerPool` verbatim, the spread refused below the floor and forwarded at it,
still exactly one `WorkerPool`.

**Atelet affinity.** A worker runs sandboxes only through the atelet on its node.
While the atelet DaemonSet rolls on a node without spare CPU, a worker scheduled
in the gap takes the CPU the old atelet pod freed; under a non-preempting atelet
class (`preemptionPolicy: Never`, an installation's choice) the new atelet pod
stays Pending, the rollout stops at that node and the `substrate` release's
upgrade times out (giantswarm/agent-platform#756). From
the Substrate line's `1.3.0` on (`agent-platform.substrate.workerPoolAffinityFloor`)
the chart derives `template.podAffinity`: a preferred term (weight 100) on the
atelet pods (`app: atelet` in `components.substrate.targetNamespace`) with
`topologyKey: kubernetes.io/hostname`, so a worker goes to a node where an atelet
pod is bound whenever such a node has room. A running worker is never evicted by
it. The term is not required: Karpenter cannot see a DaemonSet's pods on a node it
has not launched, so a required term is unsatisfiable on new capacity and a worker
that fits no existing node stays Pending for good (giantswarm/agent-platform#798);
Karpenter relaxes a preferred term and launches the node. An installation's own
`podAffinity` stands instead of the derived one (keep the atelet term in it, never
required); below `1.3.0` the key is refused.

## Voluntary disruption

The platform's core runs as single replicas — the agentgateway data plane, muster, the kagent controller, klaus-gateway, agent-manager — and each carries long-lived streams (MCP sessions, A2A and portal SSE turns, the LLM listener). A voluntary eviction (Karpenter consolidation, a node drain) cuts them mid-turn (giantswarm/agent-platform#431). Two guards, both on by default:

- **`karpenter.sh/do-not-disrupt: "true"`** on the pods that carry live streams — the agentgateway data plane (`gateway.parameters.podAnnotations`, rendered by the connectivity chart through `AgentgatewayParameters`), muster (`muster.podAnnotations`), the kagent controller (`kagent.controller.podAnnotations`) and klaus-gateway (`klausGateway.podAnnotations`). Karpenter's consolidation, drift and expiry work around the node until the NodePool's `terminationGracePeriod`; an involuntary disruption (spot interruption, node failure) is not affected. Set the value to `"false"` (or drop the key) to opt out per component.
- **`PodDisruptionBudget minAvailable: 1`** on muster (`muster.podDisruptionBudget`, the muster chart's knob), the kagent controller (`kagent.controller.pdb`, the kagent chart's knob), klaus-gateway (`klausGateway.podDisruptionBudget`, the klaus-gateway chart's knob, 1.1.0+) and agent-manager (`agentManager.podDisruptionBudget`, rendered by the connectivity chart). With one replica the budget refuses every voluntary eviction: Karpenter reports `DisruptionBlocked … pdb`, a node drain waits for its drain timeout (the fleet's Karpenter NodePools force-terminate after `terminationGracePeriod: 30m`; a MachineDeployment after its `nodeDrainTimeout`). `unhealthyPodEvictionPolicy: AlwaysAllow` where the chart supports it keeps a pod that is not Ready evictable, so a crash-looping component never wedges a drain. `enabled: false` on a knob removes that budget. The data plane's budget is `gateway.parameters.podDisruptionBudget` (with two replicas, so a drain can still proceed one pod at a time).

Two replicas are the long-term answer for the stateless components; the budgets on one replica are the interim guard. Backstage's budget is the backstage chart's (`maxUnavailable: 1` today, which protects nothing with one replica) — a change there, not here.

muster-valkey — muster's OAuth token store, one replica on an RWO volume — carries the same two guards (giantswarm/agent-platform#439): `karpenter.sh/do-not-disrupt` through the valkey subchart's `valkey.valkey.podAnnotations`, and a `PodDisruptionBudget muster-valkey` (`valkey.podDisruptionBudget`, `minAvailable: 1`, `AlwaysAllow`) rendered by the connectivity chart, since neither the wrapper nor the upstream subchart has a budget knob. The budget key never reaches the valkey release (`components.valkey.omitKeys`).

The Substrate worker pool — four workers, each hosting many actors, every agent's runtime — carries a budget of a different shape (giantswarm/agent-platform#472): `kagent.substrateWorkerPool.podDisruptionBudget`, `maxUnavailable: 1`, rendered by the connectivity chart in the kagent namespace on the pods labelled `ate.dev/worker-pool: <pool>`, so a voluntary drain moves one worker at a time and the pool keeps three. A worker carries `karpenter.sh/do-not-disrupt` only while it hosts an actor (`substrate.ateController.busyWorker.annotations`, giantswarm/agent-platform#1014); the static pool-template annotation and the on-demand capacity-type selector stay documented knobs in "The one pool is the failure domain" above.

## Placement of the stateful singletons

The guards above hold off Karpenter's *voluntary* disruption. A spot reclaim is involuntary: the instance goes two minutes after the notice whatever the budget says, and a PDB-blocked pod is then killed with its termination grace instead of being moved first — on gazelle (fifteen spot workers) one reclaim wave took muster-valkey down for two minutes (every token refresh blocked inside muster for up to 27 s) and killed klaus-gateway mid-turn, whose replacement then waited four minutes on a `Multi-Attach` error for its volume (giantswarm/agent-platform#439). On an installation whose workers are Karpenter spot capacity, pin the four single-replica stateful pods — muster, muster-valkey, the kagent controller, klaus-gateway — to on-demand capacity:

```yaml
scheduling:
  singletons:
    nodeSelector:
      karpenter.sh/capacity-type: on-demand
```

The map is merged into each component's own `nodeSelector` (`muster.nodeSelector`, `valkey.valkey.nodeSelector`, `kagent.controller.nodeSelector`, `klausGateway.nodeSelector`; a key a component sets itself wins) and `scheduling.singletons.tolerations` is appended to each one's `tolerations` (for a dedicated, tainted pool). Karpenter launches one small on-demand node for them from a NodePool that admits `on-demand` in the volumes' zone — the fleet's NodePools admit both capacity types and carry no taint — and, with the guards above, leaves it alone. Cost: one `xlarge`-class on-demand instance per such installation. Empty (the default) forwards nothing and every installation renders as before; set it only where nodes carry the label (a cluster without Karpenter — CAPZ, on-prem — would leave the four pods Pending). Enabling rolls each of the four pods once; the two with a `Recreate` strategy (muster-valkey, klaus-gateway) are down until the node is up, about two minutes on AWS. klaus-gateway takes the keys from chart 1.3.3 on (giantswarm/klaus-gateway#253; earlier 1.x schemas refused every key under `nodeSelector`), which the `1.x` range resolves. The block is the meta chart's alone: it is merged before any release renders and held back from the connectivity release. `make verify-disruption` asserts the merge, the precedence and the default.

## The kagent controller's requests follow a VerticalPodAutoscaler

`kagent.controller.vpa` (giantswarm/agent-platform#455) puts a `VerticalPodAutoscaler` on the kagent controller, rendered by the connectivity chart in the kagent namespace (the kagent chart has no VPA knob; the same pattern as the muster-valkey budget). `enabled: auto` renders it where the cluster serves `autoscaling.k8s.io/v1` — resolved once here with the other cluster-shape knobs, an explicit `true` / `false` wins. The mode is `InPlaceOrRecreate`: with one replica behind the budget above an evicting mode could never apply, so the running pod's requests are resized in place, with no eviction and no roll; a resize that cannot apply in place falls back to an eviction the budget refuses, and the pod keeps its requests until its next roll. Only requests move (`controlledValues: RequestsOnly`), between the chart's requests (`minAllowed` 100m / 128Mi) and a step under its limits (`maxAllowed` 1900m / 1280Mi, under the `2` / `1536Mi` limits of `kagent.controller.resources` — requests equal to the limits would change the pod's QoS class, which no resize may do). The key is held back from the kagent release (`components.kagent.omitKeys`); the connectivity chart's README carries the guards and the opt-outs.

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| global.registry | string | `"gsoci.azurecr.io"` |  |
| global.imagePullSecrets | list | `[]` |  |
| global.domain | string | `""` |  |
| global.identity.issuerUrl | string | `""` |  |
| global.identity.clientId | string | `""` |  |
| global.identity.existingSecret | string | `""` |  |
| global.gatewayApi.parentRefs | list | `[]` |  |
| global.observability.metrics.serviceMonitor.enabled | string | `"auto"` | `auto` (default) renders the monitor objects when monitoring.coreos.com/v1 is served on the cluster, detected once by the meta chart (an offline `helm template` resolves to false unless the API is passed in); `true` / `false` force them on or off. |
| global.observability.metrics.serviceMonitor.interval | string | `""` |  |
| global.observability.metrics.serviceMonitor.labels | object | `{}` |  |
| global.observability.traces.otlp.endpoint | string | `"http://otlp-gateway.kube-system.svc:4317"` | The collector's URL. Empty exports nothing: every `auto` endpoint is emptied and kagent's exporters (`auto`) resolve off. |
| global.observability.traces.otlp.protocol | string | `"grpc"` | `grpc` or `http/protobuf`. klaus-gateway, Substrate and kagent's log exporter speak gRPC only: with `http/protobuf` the render fails while one of them would take this endpoint: set its own key. |
| global.observability.traces.otlp.tenant | string | `"giantswarm"` | The collector's tenant. Sent as the X-Scope-OrgID header by the exporters that take headers (kagent, muster, klaus-gateway), and as the pod label observability.giantswarm.io/tenant on the ones that do not (Substrate, the agentgateway data plane). Empty sends neither. |
| global.observability.traces.otlp.headers | object | `{}` | More headers for the exporters that take headers. An X-Scope-OrgID here that differs from `tenant` fails the render. Values in this block are plain values: keep credentials out of it. |
| gitops.engine | string | `"flux"` |  |
| gitops.interval | string | `"10m"` |  |
| gitops.sourceInterval | string | `"1m"` |  |
| gitops.prereleases | bool | `false` |  |
| gitops.namespace | string | `""` |  |
| gitops.targetNamespace | string | `""` |  |
| gitops.serviceAccountName | string | `""` |  |
| gitops.target.name | string | `""` |  |
| gitops.target.kubeConfig.secretRef.name | string | `""` |  |
| gitops.target.kubeConfig.secretRef.key | string | `""` |  |
| gitops.hooks.image.registry | string | `"gsoci.azurecr.io"` |  |
| gitops.hooks.image.repository | string | `"giantswarm/kubectl"` |  |
| gitops.hooks.image.tag | string | `"v1.37.1"` |  |
| gitops.hooks.helmImage.registry | string | `"gsoci.azurecr.io"` |  |
| gitops.hooks.helmImage.repository | string | `"giantswarm/alpine-k8s"` |  |
| gitops.hooks.helmImage.tag | string | `"1.37.1"` |  |
| gitops.self.enabled | string | `"auto"` |  |
| gitops.self.repository | string | `"oci://gsoci.azurecr.io/charts/giantswarm"` |  |
| gitops.self.insecure | bool | `false` |  |
| gitops.self.versionRange | string | `""` |  |
| gitops.self.semverFilter | string | `""` |  |
| gitops.self.interval | string | `"10m"` |  |
| gitops.retries | int | `5` |  |
| gitops.forbidInlineSecrets | bool | `false` |  |
| gitops.forbidPinnedLoginConnector | bool | `false` |  |
| components.flux.enabled | bool | `true` |  |
| components.muster.chart | string | `"muster"` |  |
| components.muster.repository | string | `"oci://gsoci.azurecr.io/charts/giantswarm"` |  |
| components.muster.versionRange | string | `">=5.52.5 <6.0.0"` |  |
| components.muster.valuesFrom | string | `"muster"` |  |
| components.muster.crds | string | `"CreateReplace"` |  |
| components.muster.dependsOn[0] | string | `"valkey"` |  |
| components.muster.driftDetection.mode | string | `"enabled"` |  |
| components.muster.enabled | bool | `true` |  |
| components.muster.ownedCrds[0] | string | `"mcpservers.muster.giantswarm.io"` |  |
| components.agentgateway.chart | string | `"agentgateway"` |  |
| components.agentgateway.repository | string | `"oci://gsoci.azurecr.io/charts/giantswarm"` |  |
| components.agentgateway.versionRange | string | `">=2.8.0 <3.0.0"` |  |
| components.agentgateway.valuesFrom | string | `"agentgateway"` |  |
| components.agentgateway.enabled | bool | `true` |  |
| components.agentgateway.ownedCrds[0] | string | `"agentgatewaypolicies.agentgateway.dev"` |  |
| components.agentgateway.crds | string | `"CreateReplace"` |  |
| components.agentgateway.dependsOn[0] | string | `"gateway-api-crds"` |  |
| components.valkey.chart | string | `"valkey"` |  |
| components.valkey.repository | string | `"oci://gsoci.azurecr.io/charts/giantswarm"` |  |
| components.valkey.versionRange | string | `"0.4.x"` |  |
| components.valkey.valuesFrom | string | `"valkey"` |  |
| components.valkey.enabled | bool | `true` |  |
| components.valkey.omitKeys[0] | string | `"podDisruptionBudget"` |  |
| components.agent-platform-mcps.chart | string | `"agent-platform-mcps"` |  |
| components.agent-platform-mcps.repository | string | `"oci://gsoci.azurecr.io/charts/giantswarm"` |  |
| components.agent-platform-mcps.versionRange | string | `"0.12.x"` |  |
| components.agent-platform-mcps.valuesFrom | string | `"agent-platform-mcps"` |  |
| components.agent-platform-mcps.enabled | bool | `false` |  |
| components.agent-platform-mcps.injectGlobal | bool | `false` |  |
| components.agent-platform-mcps.dependsOn[0] | string | `"muster"` |  |
| components.agent-platform-mcps.dependsOn[1] | string | `"agentgateway"` |  |
| components.kagent.chart | string | `"kagent"` |  |
| components.kagent.repository | string | `"oci://gsoci.azurecr.io/giantswarm/kagent/helm"` |  |
| components.kagent.versionRange | string | `">=1.27.0 <1.28.0"` |  |
| components.kagent.valuesFrom | string | `"kagent"` |  |
| components.kagent.dependsOn[0] | string | `"kagent-crds"` |  |
| components.kagent.dependsOn[1] | string | `"substrate-crds"` |  |
| components.kagent.dependsOn[2] | string | `"substrate"` |  |
| components.kagent.dependsOn[3] | string | `"agent-platform-connectivity"` |  |
| components.kagent.driftDetection.mode | string | `"enabled"` |  |
| components.kagent.valuesSourceObjects[0].kind | string | `"ConfigMap"` |  |
| components.kagent.valuesSourceObjects[0].name | string | `"kagent-images"` |  |
| components.kagent.omitKeys[0] | string | `"controllerRoute"` |  |
| components.kagent.omitKeys[1] | string | `"controller.vpa"` |  |
| components.kagent.omitKeys[2] | string | `"fluxServiceAccountName"` |  |
| components.kagent.omitKeys[3] | string | `"harness.snapshotStore"` |  |
| components.kagent.omitKeys[4] | string | `"modelConfigs"` |  |
| components.kagent.omitKeys[5] | string | `"oauth2ProxyIngress"` |  |
| components.kagent.omitKeys[6] | string | `"remoteMcpServers"` |  |
| components.kagent.omitKeys[7] | string | `"uiRoute"` |  |
| components.kagent.omitKeys[8] | string | `"substrateWorkerPool.podDisruptionBudget"` |  |
| components.kagent.omitKeys[9] | string | `"substrateWorkerPool.priorityClass"` |  |
| components.kagent.omitEmptyKeys[0] | string | `"substrateWorkerPool.workerImage"` |  |
| components.kagent.omitEmptyKeys[1] | string | `"harness.image"` |  |
| components.kagent.enabled | bool | `false` |  |
| components.kagent-crds.chart | string | `"kagent-crds"` |  |
| components.kagent-crds.repository | string | `"oci://gsoci.azurecr.io/giantswarm/kagent/helm"` |  |
| components.kagent-crds.versionRange | string | `">=1.27.0 <1.28.0"` |  |
| components.kagent-crds.valuesFrom | string | `"kagent-crds"` |  |
| components.kagent-crds.injectGlobal | bool | `false` |  |
| components.kagent-crds.ownedCrds[0] | string | `"modelconfigs.api.kagent.dev"` |  |
| components.substrate-crds.chart | string | `"substrate-crds"` |  |
| components.substrate-crds.repository | string | `"oci://gsoci.azurecr.io/giantswarm/substrate/helm"` |  |
| components.substrate-crds.versionRange | string | `">=1.17.5 <1.18.0"` |  |
| components.substrate-crds.valuesFrom | string | `"substrate-crds"` |  |
| components.substrate-crds.injectGlobal | bool | `false` |  |
| components.substrate-crds.targetNamespace | string | `"ate-system"` |  |
| components.substrate.chart | string | `"substrate"` |  |
| components.substrate.repository | string | `"oci://gsoci.azurecr.io/giantswarm/substrate/helm"` |  |
| components.substrate.versionRange | string | `">=1.17.5 <1.18.0"` |  |
| components.substrate.valuesFrom | string | `"substrate"` |  |
| components.substrate.injectGlobal | bool | `false` |  |
| components.substrate.targetNamespace | string | `"ate-system"` |  |
| components.substrate.dependsOn[0] | string | `"substrate-crds"` |  |
| components.substrate.dependsOn[1] | string | `"agent-platform-connectivity"` |  |
| components.substrate.valuesFromRefs[0].kind | string | `"ConfigMap"` |  |
| components.substrate.valuesFromRefs[0].name | string | `"kagent-images"` |  |
| components.substrate.valuesFromRefs[0].valuesKey | string | `"substrate-values.yaml"` |  |
| components.substrate.valuesFromRefs[0].optional | bool | `true` |  |
| components.substrate.omitEmptyKeys[0] | string | `"atelet.imageCache.pinnedImages"` |  |
| components.substrate.timeout | string | `"15m"` |  |
| components.substrate.upgradeRemediation.retries | int | `3` |  |
| components.google-access-token-credential-provider.chart | string | `"google-access-token-credential-provider"` |  |
| components.google-access-token-credential-provider.repository | string | `"oci://gsoci.azurecr.io/charts/giantswarm"` |  |
| components.google-access-token-credential-provider.versionRange | string | `">=0.2.0 <0.3.0"` |  |
| components.google-access-token-credential-provider.valuesFrom | string | `"google-access-token-credential-provider"` |  |
| components.google-access-token-credential-provider.injectGlobal | bool | `false` |  |
| components.google-access-token-credential-provider.targetNamespace | string | `"ate-system"` |  |
| components.google-access-token-credential-provider.dependsOn[0] | string | `"substrate"` |  |
| components.klaus-gateway.chart | string | `"klaus-gateway"` |  |
| components.klaus-gateway.repository | string | `"oci://gsoci.azurecr.io/charts/giantswarm"` |  |
| components.klaus-gateway.versionRange | string | `">=4.11.0 <5.0.0"` |  |
| components.klaus-gateway.valuesFrom | string | `"klausGateway"` |  |
| components.klaus-gateway.omitKeys[0] | string | `"observability.enabled"` |  |
| components.klaus-gateway.omitKeys[1] | string | `"refusals"` |  |
| components.klaus-gateway.omitEmptyKeys[0] | string | `"slack.contextBotIDs"` |  |
| components.klaus-gateway.enabled | bool | `false` |  |
| components.agent-sandbox.chart | string | `"agent-sandbox"` |  |
| components.agent-sandbox.repository | string | `"oci://gsoci.azurecr.io/charts/giantswarm"` |  |
| components.agent-sandbox.versionRange | string | `"0.2.x"` |  |
| components.agent-sandbox.enabled | bool | `false` |  |
| components.agent-sandbox.injectGlobal | bool | `false` |  |
| components.agent-sandbox.crds | string | `"CreateReplace"` |  |
| components.agent-sandbox.dependsOn[0] | string | `"agent-platform-connectivity"` |  |
| components.model-manager.chart | string | `"model-manager"` |  |
| components.model-manager.repository | string | `"oci://gsoci.azurecr.io/charts/giantswarm"` |  |
| components.model-manager.versionRange | string | `">=1.14.0 <2.0.0"` |  |
| components.model-manager.valuesFrom | string | `"model-manager"` |  |
| components.model-manager.enabled | bool | `true` |  |
| components.model-manager.dependsOn[0] | string | `"muster"` |  |
| components.model-manager.dependsOn[1] | string | `"kagent"` |  |
| components.model-manager.dependsOn[2] | string | `"kserve-llmisvc-resources"` |  |
| components.agent-manager.chart | string | `"agent-manager"` |  |
| components.agent-manager.repository | string | `"oci://gsoci.azurecr.io/charts/giantswarm"` |  |
| components.agent-manager.versionRange | string | `">=2.16.0 <3.0.0"` |  |
| components.agent-manager.valuesFrom | string | `"agent-manager"` |  |
| components.agent-manager.omitEmptyKeys[0] | string | `"harness.egress"` |  |
| components.agent-manager.enabled | bool | `false` |  |
| components.agent-manager.dependsOn[0] | string | `"muster"` |  |
| components.agent-manager.dependsOn[1] | string | `"kagent"` |  |
| components.vm-manager.chart | string | `"vm-manager"` |  |
| components.vm-manager.repository | string | `"oci://gsoci.azurecr.io/charts/giantswarm"` |  |
| components.vm-manager.versionRange | string | `">=0.24.0 <0.25.0"` |  |
| components.vm-manager.valuesFrom | string | `"vm-manager"` |  |
| components.vm-manager.enabled | bool | `false` |  |
| components.vm-manager.dependsOn[0] | string | `"muster"` |  |
| components.vm-manager.gatedValues[0] | string | `"vm-manager"` |  |
| components.vm-manager.gatedValues[1] | string | `"vmManager"` |  |
| components.cluster-manager.chart | string | `"cluster-manager"` |  |
| components.cluster-manager.repository | string | `"oci://gsoci.azurecr.io/charts/giantswarm"` |  |
| components.cluster-manager.versionRange | string | `">=0.22.0 <0.35.0"` |  |
| components.cluster-manager.valuesFrom | string | `"cluster-manager"` |  |
| components.cluster-manager.enabled | bool | `false` |  |
| components.cluster-manager.dependsOn[0] | string | `"muster"` |  |
| components.cluster-manager.gatedValues[0] | string | `"cluster-manager"` |  |
| components.cluster-manager.gatedValues[1] | string | `"clusterManager"` |  |
| components.workspace-manager.chart | string | `"workspace-manager"` |  |
| components.workspace-manager.repository | string | `"oci://gsoci.azurecr.io/charts/giantswarm"` |  |
| components.workspace-manager.versionRange | string | `">=0.14.0 <0.15.0"` |  |
| components.workspace-manager.valuesFrom | string | `"workspace-manager"` |  |
| components.workspace-manager.dependsOn[0] | string | `"muster"` |  |
| components.workspace-manager.dependsOn[1] | string | `"agent-platform-connectivity"` |  |
| components.workspace-manager.gatedValues[0] | string | `"workspace-manager"` |  |
| components.workspace-manager.gatedValues[1] | string | `"workspaceManager"` |  |
| components.workspace-manager.gatedValues[2] | string | `"workspaces"` |  |
| components.workspace-manager.gatedRoster | bool | `true` |  |
| components.workspace-manager.omitEmptyKeys[0] | string | `"providers"` |  |
| components.workspace-manager.omitEmptyKeys[1] | string | `"oauth.baseURL"` |  |
| components.workspace-manager.omitEmptyKeys[2] | string | `"grant.signingKey"` |  |
| components.workspace-manager.omitEmptyKeys[3] | string | `"muster.mcpServer.auth.provider"` |  |
| components.workspace-manager.omitEmptyKeys[4] | string | `"muster.mcpServer.auth.authorizationServer"` |  |
| components.workspace-manager.omitEmptyKeys[5] | string | `"sync.cycle"` |  |
| components.workspace-manager.omitEmptyKeys[6] | string | `"sessions.cleanupAfter"` |  |
| components.workspace-manager.omitEmptyKeys[7] | string | `"storage.sizing.factor"` |  |
| components.workspace-manager.omitEmptyKeys[8] | string | `"storage.sizing.headroom"` |  |
| components.workspace-manager.omitEmptyKeys[9] | string | `"storage.sizing.maxSize"` |  |
| components.toolchain-manager.chart | string | `"toolchain-manager"` |  |
| components.toolchain-manager.repository | string | `"oci://gsoci.azurecr.io/charts/giantswarm"` |  |
| components.toolchain-manager.versionRange | string | `">=0.5.0 <0.6.0"` |  |
| components.toolchain-manager.valuesFrom | string | `"toolchain-manager"` |  |
| components.toolchain-manager.enabled | bool | `false` |  |
| components.toolchain-manager.dependsOn[0] | string | `"muster"` |  |
| components.toolchain-manager.omitKeys[0] | string | `"additionalSources"` |  |
| components.toolchain-manager.omitKeys[1] | string | `"registryPullSecret"` |  |
| components.toolchain-manager.gatedRoster | bool | `true` |  |
| components.backstage.chart | string | `"backstage"` |  |
| components.backstage.repository | string | `"oci://gsoci.azurecr.io/charts/giantswarm"` |  |
| components.backstage.versionRange | string | `">=2.68.0 <4.0.0"` |  |
| components.backstage.valuesFrom | string | `"backstage"` |  |
| components.backstage.omitKeys[0] | string | `"hostname"` |  |
| components.backstage.omitKeys[1] | string | `"parentRefs"` |  |
| components.backstage.omitKeys[2] | string | `"installationName"` |  |
| components.backstage.omitKeys[3] | string | `"extraScopes"` |  |
| components.backstage.omitKeys[4] | string | `"startUrlSearchParams"` |  |
| components.backstage.omitKeys[5] | string | `"enabledExtensions"` |  |
| components.backstage.omitKeys[6] | string | `"disabledExtensions"` |  |
| components.backstage.omitKeys[7] | string | `"skillsRepositories"` |  |
| components.backstage.omitKeys[8] | string | `"configReload"` |  |
| components.backstage.enabled | bool | `false` |  |
| components.backstage.dependsOn[0] | string | `"cloudnative-pg"` |  |
| components.backstage.dependsOn[1] | string | `"agent-platform-connectivity"` |  |
| components.mcp-kubernetes.chart | string | `"mcp-kubernetes"` |  |
| components.mcp-kubernetes.repository | string | `"oci://gsoci.azurecr.io/charts/giantswarm"` |  |
| components.mcp-kubernetes.versionRange | string | `">=1.3.0 <2.0.0"` |  |
| components.mcp-kubernetes.valuesFrom | string | `"mcp-kubernetes"` |  |
| components.mcp-kubernetes.omitKeys[0] | string | `"kubernetesAudience"` |  |
| components.mcp-kubernetes.omitKeys[1] | string | `"mcpServer"` |  |
| components.mcp-kubernetes.enabled | bool | `false` |  |
| components.cloudnative-pg.chart | string | `"cloudnative-pg"` |  |
| components.cloudnative-pg.repository | string | `"oci://gsoci.azurecr.io/giantswarm/cloudnative-pg/charts"` |  |
| components.cloudnative-pg.versionRange | string | `"0.29.x"` |  |
| components.cloudnative-pg.valuesFrom | string | `"cloudnative-pg"` |  |
| components.cloudnative-pg.enabled | bool | `false` |  |
| components.kserve-llmisvc-crd.chart | string | `"kserve-llmisvc-crd"` |  |
| components.kserve-llmisvc-crd.repository | string | `"oci://gsoci.azurecr.io/charts/giantswarm"` |  |
| components.kserve-llmisvc-crd.versionRange | string | `"0.7.x"` |  |
| components.kserve-llmisvc-crd.valuesFrom | string | `"kserve-llmisvc-crd"` |  |
| components.kserve-llmisvc-crd.enabled | bool | `false` |  |
| components.kserve-llmisvc-crd.ownedCrds[0] | string | `"llminferenceservices.serving.kserve.io"` |  |
| components.kserve-llmisvc-resources.chart | string | `"kserve-llmisvc-resources"` |  |
| components.kserve-llmisvc-resources.repository | string | `"oci://gsoci.azurecr.io/charts/giantswarm"` |  |
| components.kserve-llmisvc-resources.versionRange | string | `"0.7.x"` |  |
| components.kserve-llmisvc-resources.valuesFrom | string | `"kserve-llmisvc-resources"` |  |
| components.kserve-llmisvc-resources.enabled | bool | `false` |  |
| components.kserve-llmisvc-resources.dependsOn[0] | string | `"kserve-llmisvc-crd"` |  |
| components.kserve-runtime-configs.chart | string | `"kserve-runtime-configs"` |  |
| components.kserve-runtime-configs.repository | string | `"oci://gsoci.azurecr.io/charts/giantswarm"` |  |
| components.kserve-runtime-configs.versionRange | string | `"0.7.x"` |  |
| components.kserve-runtime-configs.valuesFrom | string | `"kserve-runtime-configs"` |  |
| components.kserve-runtime-configs.enabled | bool | `false` |  |
| components.kserve-runtime-configs.dependsOn[0] | string | `"kserve-llmisvc-crd"` |  |
| components.kserve-runtime-configs.driftDetection.mode | string | `"enabled"` |  |
| components.kserve-runtime-configs.driftDetection.ignore[0].paths[0] | string | `"/spec"` |  |
| components.kserve-runtime-configs.driftDetection.ignore[0].target.kind | string | `"LLMInferenceServiceConfig"` |  |
| components.modelServing.enabled | bool | `false` |  |
| components.gpu-operator.chart | string | `"gpu-operator"` |  |
| components.gpu-operator.repository | string | `"oci://gsoci.azurecr.io/charts/giantswarm"` |  |
| components.gpu-operator.versionRange | string | `"1.x"` |  |
| components.gpu-operator.valuesFrom | string | `"gpu-operator"` |  |
| components.gpu-operator.valuesKey | string | `"gpu-operator"` |  |
| components.gpu-operator.injectGlobal | bool | `false` |  |
| components.gpu-operator.enabled | bool | `false` |  |
| components.gpu-operator.targetNamespace | string | `"kube-system"` |  |
| components.gpu-operator.crds | string | `"CreateReplace"` |  |
| components.gpu-operator.ownedCrds[0] | string | `"clusterpolicies.nvidia.com"` |  |
| components.gateway-api-crds.chart | string | `"gateway-api-crds"` |  |
| components.gateway-api-crds.repository | string | `"oci://gsoci.azurecr.io/charts/giantswarm"` |  |
| components.gateway-api-crds.versionRange | string | `">=1.9.1 <2.0.0"` |  |
| components.gateway-api-crds.injectGlobal | bool | `false` |  |
| components.gateway-api-crds.enabled | bool | `false` |  |
| components.gateway-api-crds.targetNamespace | string | `"kube-system"` |  |
| components.dicebear.chart | string | `"dicebear"` |  |
| components.dicebear.repository | string | `"oci://gsoci.azurecr.io/charts/giantswarm"` |  |
| components.dicebear.versionRange | string | `"0.3.x"` |  |
| components.dicebear.valuesFrom | string | `"dicebear"` |  |
| components.dicebear.injectGlobal | bool | `false` |  |
| components.dicebear.enabled | bool | `true` |  |
| components.agent-platform-connectivity.chart | string | `"agent-platform-connectivity"` |  |
| components.agent-platform-connectivity.repository | string | `"oci://gsoci.azurecr.io/charts/giantswarm"` |  |
| components.agent-platform-connectivity.releasedWithChart | bool | `true` |  |
| components.agent-platform-connectivity.versionRange | string | `""` |  |
| components.agent-platform-connectivity.forwardAllValues | bool | `true` |  |
| components.agent-platform-connectivity.disableWaitForJobs | bool | `true` |  |
| components.agent-platform-connectivity.omitKeys[0] | string | `"flux-engine"` |  |
| components.agent-platform-connectivity.omitKeys[1] | string | `"scheduling"` |  |
| components.agent-platform-connectivity.omitKeys[2] | string | `"gpu-operator"` |  |
| components.agent-platform-connectivity.omitKeys[3] | string | `"toolchain-manager"` |  |
| components.agent-platform-connectivity.omitKeys[4] | string | `"kserve-runtime-configs"` |  |
| components.agent-platform-connectivity.dependsOn[0] | string | `"muster"` |  |
| components.agent-platform-connectivity.dependsOn[1] | string | `"agentgateway"` |  |
| components.agent-platform-connectivity.dependsOn[2] | string | `"substrate-crds"` |  |
| components.agent-platform-connectivity.dependsOn[3] | string | `"kagent-crds"` |  |
| components.agent-platform-connectivity.dependsOn[4] | string | `"cloudnative-pg"` |  |
| components.agent-platform-connectivity.dependsOn[5] | string | `"gateway-api-crds"` |  |
| flux-engine | object | `{}` |  |
| dicebear.route.enabled | string | `"auto"` |  |
| dicebear.route.parentRefs | list | `[]` |  |
| dicebear.route.hostnames | list | `[]` |  |
| ingress.mode | string | `"agentgateway-muster"` |  |
| ingress.parentRefs | list | `[]` |  |
| ingress.hostnames | list | `[]` |  |
| ingress.httpRoute.annotations | object | `{}` |  |
| ingress.httpRoute.labels | object | `{}` |  |
| ingress.httpRoute.muster.annotations | object | `{}` |  |
| ingress.httpRoute.muster.labels | object | `{}` |  |
| ingress.httpRoute.mcp.annotations | object | `{}` |  |
| ingress.httpRoute.mcp.labels | object | `{}` |  |
| ingress.httpRoute.timeouts | object | `{}` |  |
| ingress.backendTrafficPolicy.enabled | bool | `false` |  |
| ingress.backendTrafficPolicy.timeout | string | `"0s"` |  |
| ingress.backendTrafficPolicy.annotations | object | `{}` |  |
| ingress.backendTrafficPolicy.labels | object | `{}` |  |
| gateway.name | string | `"agentgateway"` |  |
| gateway.gatewayClassName | string | `"agentgateway"` |  |
| gateway.listeners[0].name | string | `"http"` |  |
| gateway.listeners[0].port | int | `8080` |  |
| gateway.listeners[0].protocol | string | `"HTTP"` |  |
| gateway.listeners[0].allowedRoutes.namespaces.from | string | `"Same"` |  |
| gateway.jwksEgress.enabled | bool | `false` |  |
| gateway.jwksEgress.namespace | string | `"giantswarm"` |  |
| gateway.jwksEgress.port | int | `5556` |  |
| gateway.jwksEgress.podSelector | object | `{}` |  |
| gateway.jwksEgress.external.fqdns | list | `[]` |  |
| gateway.jwksEgress.external.cidrs | list | `[]` |  |
| gateway.jwksEgress.external.port | int | `443` |  |
| gateway.parameters.enabled | bool | `true` |  |
| gateway.parameters.name | string | `""` |  |
| gateway.parameters.serviceType | string | `"ClusterIP"` |  |
| gateway.parameters.podSecurityContext.runAsNonRoot | bool | `true` |  |
| gateway.parameters.podSecurityContext.seccompProfile.type | string | `"RuntimeDefault"` |  |
| gateway.parameters.containerSecurityContext.allowPrivilegeEscalation | bool | `false` |  |
| gateway.parameters.containerSecurityContext.readOnlyRootFilesystem | bool | `true` |  |
| gateway.parameters.containerSecurityContext.runAsNonRoot | bool | `true` |  |
| gateway.parameters.containerSecurityContext.capabilities.drop[0] | string | `"ALL"` |  |
| gateway.parameters.containerSecurityContext.seccompProfile.type | string | `"RuntimeDefault"` |  |
| gateway.parameters.dataPlaneEnv[0].name | string | `"OTEL_EXPORTER_OTLP_ENDPOINT"` |  |
| gateway.parameters.dataPlaneEnv[0].value | string | `"auto"` |  |
| gateway.parameters.dataPlaneEnv[1].name | string | `"OTEL_EXPORTER_OTLP_PROTOCOL"` |  |
| gateway.parameters.dataPlaneEnv[1].value | string | `"auto"` |  |
| gateway.parameters.dataPlaneVolumes | list | `[]` |  |
| gateway.parameters.dataPlaneVolumeMounts | list | `[]` |  |
| gateway.parameters.dataPlaneResources.requests.cpu | string | `"100m"` |  |
| gateway.parameters.dataPlaneResources.requests.memory | string | `"128Mi"` |  |
| gateway.parameters.dataPlaneResources.requests.ephemeral-storage | string | `"50Mi"` |  |
| gateway.parameters.dataPlaneResources.limits.cpu | string | `"2000m"` |  |
| gateway.parameters.dataPlaneResources.limits.memory | string | `"512Mi"` |  |
| gateway.parameters.dataPlaneResources.limits.ephemeral-storage | string | `"512Mi"` |  |
| gateway.parameters.replicas | int | `2` |  |
| gateway.parameters.podDisruptionBudget.enabled | bool | `true` |  |
| gateway.parameters.spread.enabled | bool | `true` |  |
| gateway.parameters.spread.topologyKeys[0] | string | `"kubernetes.io/hostname"` |  |
| gateway.parameters.spread.maxSkew | int | `1` |  |
| gateway.parameters.spread.whenUnsatisfiable | string | `"ScheduleAnyway"` |  |
| gateway.parameters.podAnnotations | object | `{}` |  |
| gateway.parameters.podLabels."observability.giantswarm.io/tenant" | string | `"auto"` |  |
| gateway.http.maxBufferSize | string | `"8Mi"` |  |
| gateway.tracing.randomSampling | string | `"0.1"` |  |
| gateway.metricLabels.agent.enabled | bool | `true` |  |
| gateway.metricLabels.agent.expression | string | `"{{ include \"agent-platform.substrate.egressCall\" . }} ? request.headers[\"x-kagent-agent\"] : source.unverifiedWorkload.serviceAccount"` |  |
| gateway.metricLabels.agent_namespace.enabled | bool | `true` |  |
| gateway.metricLabels.agent_namespace.expression | string | `"{{ include \"agent-platform.substrate.egressCall\" . }} ? request.headers[\"x-kagent-agent-namespace\"] : source.unverifiedWorkload.namespace"` |  |
| gateway.metricLabels.user.enabled | bool | `true` |  |
| gateway.metricLabels.user.expression | string | `"{{ include \"agent-platform.substrate.egressCall\" . }} ? request.headers[\"x-kagent-user\"] : jwt.{{ include \"agent-platform.kagent.userIdClaim\" . }}"` |  |
| gateway.metricLabels.api_key.enabled | bool | `true` |  |
| gateway.metricLabels.api_key.expression | string | `"apiKey.name"` |  |
| gateway.accessLog.attributes.agent_instance_id.enabled | bool | `true` |  |
| gateway.accessLog.attributes.agent_instance_id.expression | string | `"{{ include \"agent-platform.substrate.egressCall\" . }} ? request.headers[\"x-kagent-agent-instance-id\"] : \"\""` |  |
| gateway.accessLog.attributes.request_id.enabled | bool | `true` |  |
| gateway.accessLog.attributes.request_id.expression | string | `"request.headers[\"x-request-id\"]"` |  |
| gatewayApi.gateway.create | bool | `false` |  |
| gatewayApi.gateway.tls.secretName | string | `""` |  |
| gatewayApi.gateway.serviceType | string | `"LoadBalancer"` |  |
| llmRouting.enabled | bool | `false` |  |
| llmRouting.listener.name | string | `"llm"` |  |
| llmRouting.listener.port | int | `8081` |  |
| llmRouting.models[0].name | string | `"anthropic"` |  |
| llmRouting.models[0].provider | string | `"Anthropic"` |  |
| llmRouting.models[0].baseURL | string | `"https://api.anthropic.com/v1"` |  |
| llmRouting.models[0].match | string | `"claude-*"` |  |
| llmRouting.rateLimits | list | `[]` |  |
| llmRouting.external.enabled | bool | `false` |  |
| llmRouting.external.hostPrefix | string | `"llm"` |  |
| llmRouting.external.listener.name | string | `"llm-external"` |  |
| llmRouting.external.listener.port | int | `8082` |  |
| llmRouting.external.rateLimits | list | `[]` |  |
| llmRouting.external.apiKeys.secretRef.name | string | `""` |  |
| llmRouting.external.apiKeys.secretSelector.matchLabels | object | `{}` |  |
| llmRouting.external.apiKeys.configMapSelector.matchLabels | object | `{}` |  |
| llmRouting.modelConfigPolicy.enabled | bool | `true` |  |
| llmRouting.modelCatalog.enabled | bool | `true` |  |
| llmRouting.modelCatalog.name | string | `""` |  |
| llmRouting.modelCatalog.key | string | `"catalog.json"` |  |
| llmRouting.modelCatalog.providers | object | `{}` |  |
| networkPolicy.enabled | bool | `true` |  |
| networkPolicy.flavor | string | `"auto"` | `auto` (default) selects `cilium` when cilium.io/v2 is served on the cluster and `kubernetes` otherwise; `cilium` / `kubernetes` force the flavor. |
| networkPolicy.additionalEgressCIDRs | list | `[]` |  |
| networkPolicy.additionalEgressFQDNs | list | `[]` |  |
| networkPolicy.substrate.credentialProvider.egressFQDNs | list | `[]` |  |
| networkPolicy.musterInClusterMcpPorts[0] | int | `8080` |  |
| networkPolicy.musterInClusterMcpPorts[1] | int | `8443` |  |
| networkPolicy.mcpBackends | object | `{}` |  |
| networkPolicy.mcpBackendScrapers[0].namespace | string | `"kube-system"` |  |
| networkPolicy.mcpBackendScrapers[0].matchLabels."app.kubernetes.io/instance" | string | `"alloy-metrics"` |  |
| networkPolicy.kubernetes.apiServerCIDR | string | `"0.0.0.0/0"` |  |
| networkPolicy.kubernetes.worldExcludedCIDRs[0] | string | `"10.0.0.0/8"` |  |
| networkPolicy.kubernetes.worldExcludedCIDRs[1] | string | `"172.16.0.0/12"` |  |
| networkPolicy.kubernetes.worldExcludedCIDRs[2] | string | `"192.168.0.0/16"` |  |
| networkPolicy.kubernetes.worldExcludedCIDRs[3] | string | `"169.254.0.0/16"` |  |
| kyvernoPolicies.enabled | string | `"auto"` | `auto` (default) renders the Kyverno objects when kyverno.io/v1 is served on the cluster, detected once by the meta chart (an offline `helm template` resolves to false unless the API is passed in); `true` / `false` force them on or off. |
| kyvernoPolicies.policyExceptionNamespace | string | `"policy-exceptions"` |  |
| kyvernoPolicies.rules.privileged-containers | string | `"disallow-privileged-containers"` |  |
| kyvernoPolicies.rules.host-ports-none | string | `"disallow-host-ports"` |  |
| kyvernoPolicies.rules.host-namespaces | string | `"disallow-host-namespaces"` |  |
| kyvernoPolicies.rules.host-path | string | `"disallow-host-path"` |  |
| kyvernoPolicies.rules.restricted-volumes | string | `"restrict-volume-types"` |  |
| kyvernoPolicies.rules.adding-capabilities | string | `"disallow-capabilities"` |  |
| kyvernoPolicies.rules.require-drop-all | string | `"disallow-capabilities-strict"` |  |
| kyvernoPolicies.rules.adding-capabilities-strict | string | `"disallow-capabilities-strict"` |  |
| kyvernoPolicies.rules.run-as-non-root | string | `"require-run-as-nonroot"` |  |
| kyvernoPolicies.rules.run-as-non-root-user | string | `"require-run-as-non-root-user"` |  |
| kyvernoPolicies.rules.privilege-escalation | string | `"disallow-privilege-escalation"` |  |
| kyvernoPolicies.rules.check-seccomp | string | `"restrict-seccomp"` |  |
| kyvernoPolicies.rules.check-seccomp-strict | string | `"restrict-seccomp-strict"` |  |
| kyvernoPolicies.rules.app-armor | string | `"restrict-apparmor-profiles"` |  |
| scheduling.singletons.nodeSelector | object | `{}` | Node labels the four stateful singletons (muster, muster-valkey, the kagent controller, klaus-gateway) must land on, merged into each component's own nodeSelector (its keys win). On a Karpenter spot installation: `karpenter.sh/capacity-type: on-demand`. Empty = as before. |
| scheduling.singletons.tolerations | list | `[]` | Tolerations appended to the four singletons' own, for a dedicated, tainted on-demand pool. The fleet's NodePools carry no taint. |
| extraObjects | list | `[]` |  |
| muster.enabled | bool | `true` |  |
| muster.image.registry | string | `"gsoci.azurecr.io"` |  |
| muster.fullnameOverride | string | `"muster"` |  |
| muster.crds.install | bool | `false` |  |
| muster.rbac.mcpServerEditor.subjects[0].apiGroup | string | `"rbac.authorization.k8s.io"` |  |
| muster.rbac.mcpServerEditor.subjects[0].kind | string | `"Group"` |  |
| muster.rbac.mcpServerEditor.subjects[0].name | string | `"giantswarm-ad:giantswarm-admins"` |  |
| muster.rbac.mcpServerEditor.subjects[1].apiGroup | string | `"rbac.authorization.k8s.io"` |  |
| muster.rbac.mcpServerEditor.subjects[1].kind | string | `"Group"` |  |
| muster.rbac.mcpServerEditor.subjects[1].name | string | `"giantswarm-github:giantswarm:giantswarm-admins"` |  |
| muster.rbac.workflowEditor.subjects[0].apiGroup | string | `"rbac.authorization.k8s.io"` |  |
| muster.rbac.workflowEditor.subjects[0].kind | string | `"Group"` |  |
| muster.rbac.workflowEditor.subjects[0].name | string | `"giantswarm-ad:giantswarm-admins"` |  |
| muster.rbac.workflowEditor.subjects[1].apiGroup | string | `"rbac.authorization.k8s.io"` |  |
| muster.rbac.workflowEditor.subjects[1].kind | string | `"Group"` |  |
| muster.rbac.workflowEditor.subjects[1].name | string | `"giantswarm-github:giantswarm:giantswarm-admins"` |  |
| muster.networkPolicy.enabled | bool | `true` |  |
| muster.networkPolicy.flavor | string | `"auto"` |  |
| muster.networkPolicy.cilium.allowClusterIngress | bool | `true` |  |
| muster.podAnnotations."application.giantswarm.io/team" | string | `"bumblebee"` |  |
| muster.replicaCount | int | `2` |  |
| muster.affinity.podAntiAffinity.preferredDuringSchedulingIgnoredDuringExecution[0].weight | int | `100` |  |
| muster.affinity.podAntiAffinity.preferredDuringSchedulingIgnoredDuringExecution[0].podAffinityTerm.topologyKey | string | `"kubernetes.io/hostname"` |  |
| muster.affinity.podAntiAffinity.preferredDuringSchedulingIgnoredDuringExecution[0].podAffinityTerm.labelSelector.matchLabels."app.kubernetes.io/name" | string | `"muster"` |  |
| muster.podDisruptionBudget.enabled | bool | `true` |  |
| muster.podDisruptionBudget.minAvailable | int | `1` |  |
| muster.gatewayAPI.enabled | bool | `false` |  |
| muster.muster.oauth.server.enabled | bool | `true` |  |
| muster.muster.oauth.server.baseUrl | string | `""` |  |
| muster.muster.oauth.server.dex.issuerUrl | string | `""` |  |
| muster.muster.oauth.server.dex.clientId | string | `""` |  |
| muster.muster.oauth.server.existingSecret | string | `""` |  |
| muster.muster.oauth.server.storage.type | string | `"valkey"` |  |
| muster.muster.oauth.server.storage.valkey.url | string | `"muster-valkey:6379"` |  |
| muster.muster.oauth.server.storage.valkey.secretKeyPassword | string | `"valkey-password"` |  |
| muster.muster.toolsetPresets.infrastructure.description | string | `"The servers for the infrastructure underneath the platform (Giant Swarm installations' management clusters) — mcp-kubernetes, mcp-capi, mcp-prometheus."` |  |
| muster.muster.toolsetPresets.infrastructure.include[0].label | string | `"agent-platform.giantswarm.io/tool-group=infrastructure"` |  |
| muster.muster.toolsetPresets.agent-platform.description | string | `"The platform's own management surface — agent-manager, model-manager, vm-manager, cluster-manager, kagent's session tools and muster's core tools."` |  |
| muster.muster.toolsetPresets.agent-platform.include[0].label | string | `"agent-platform.giantswarm.io/tool-group=agent-platform"` |  |
| muster.muster.toolsetPresets.agent-platform.include[1].pattern | string | `"core_*"` |  |
| muster.muster.observability.otel.endpoint | string | `"auto"` |  |
| muster.muster.observability.otel.protocol | string | `"auto"` |  |
| muster.muster.observability.otel.headers | string | `"auto"` |  |
| muster.muster.observability.metrics.prometheus.serviceMonitor.enabled | string | `"auto"` |  |
| muster.muster.observability.metrics.prometheus.serviceMonitor.interval | string | `"60s"` |  |
| muster.muster.observability.metrics.prometheus.serviceMonitor.labels."observability.giantswarm.io/tenant" | string | `"giantswarm"` |  |
| muster.muster.observability.metrics.prometheus.prometheusRule.enabled | string | `"auto"` |  |
| muster.muster.observability.metrics.prometheus.prometheusRule.labels."observability.giantswarm.io/tenant" | string | `"giantswarm"` |  |
| muster.muster.observability.grafanaDashboard.enabled | string | `"auto"` |  |
| muster.muster.observability.grafanaDashboard.folder | string | `"Agent Platform"` |  |
| muster.muster.observability.grafanaDashboard.giantswarm.enabled | bool | `true` |  |
| muster.muster.observability.grafanaDashboard.giantswarm.organization | string | `"Shared Org"` |  |
| valkey.ciliumNetworkPolicy.enabled | string | `"auto"` |  |
| valkey.ciliumNetworkPolicy.ingress.clients[0].namespace | string | `""` |  |
| valkey.ciliumNetworkPolicy.ingress.clients[0].matchLabels."app.kubernetes.io/name" | string | `"muster"` |  |
| valkey.ciliumNetworkPolicy.ingress.clients[1].namespace | string | `""` |  |
| valkey.ciliumNetworkPolicy.ingress.clients[1].matchLabels."app.kubernetes.io/name" | string | `"klaus-gateway"` |  |
| valkey.vpa.enabled | bool | `false` |  |
| valkey.podDisruptionBudget.enabled | bool | `true` |  |
| valkey.podDisruptionBudget.minAvailable | string | `nil` |  |
| valkey.podDisruptionBudget.maxUnavailable | int | `1` |  |
| valkey.podDisruptionBudget.unhealthyPodEvictionPolicy | string | `"AlwaysAllow"` |  |
| valkey.valkey.fullnameOverride | string | `"muster-valkey"` |  |
| valkey.valkey.replicaCount | int | `1` |  |
| valkey.valkey.deploymentStrategy | string | `"Recreate"` |  |
| valkey.valkey.podAnnotations."karpenter.sh/do-not-disrupt" | string | `"true"` |  |
| valkey.valkey.auth.enabled | bool | `true` |  |
| valkey.valkey.auth.usersExistingSecret | string | `""` |  |
| valkey.valkey.auth.aclUsers.default.permissions | string | `"~* &* +@all"` |  |
| valkey.valkey.auth.aclUsers.default.passwordKey | string | `""` |  |
| valkey.valkey.dataStorage.enabled | bool | `true` |  |
| valkey.valkey.dataStorage.requestedSize | string | `"1Gi"` |  |
| valkey.valkey.valkeyConfig | string | `"maxmemory 640mb\nmaxmemory-policy volatile-lru\n"` |  |
| valkey.valkey.resources.requests.cpu | string | `"50m"` |  |
| valkey.valkey.resources.requests.memory | string | `"256Mi"` |  |
| valkey.valkey.resources.limits.cpu | string | `"200m"` |  |
| valkey.valkey.resources.limits.memory | string | `"1Gi"` |  |
| valkey.valkey.podSecurityContext.fsGroup | int | `1000` |  |
| valkey.valkey.podSecurityContext.runAsUser | int | `1000` |  |
| valkey.valkey.podSecurityContext.runAsGroup | int | `1000` |  |
| valkey.valkey.podSecurityContext.seccompProfile.type | string | `"RuntimeDefault"` |  |
| valkey.valkey.securityContext.allowPrivilegeEscalation | bool | `false` |  |
| valkey.valkey.securityContext.capabilities.drop[0] | string | `"ALL"` |  |
| valkey.valkey.securityContext.readOnlyRootFilesystem | bool | `true` |  |
| valkey.valkey.securityContext.runAsNonRoot | bool | `true` |  |
| valkey.valkey.securityContext.runAsUser | int | `1000` |  |
| valkey.valkey.securityContext.seccompProfile.type | string | `"RuntimeDefault"` |  |
| valkey.valkey.metrics.exporter.securityContext.allowPrivilegeEscalation | bool | `false` |  |
| valkey.valkey.metrics.exporter.securityContext.capabilities.drop[0] | string | `"ALL"` |  |
| valkey.valkey.metrics.exporter.securityContext.readOnlyRootFilesystem | bool | `true` |  |
| valkey.valkey.metrics.exporter.securityContext.runAsNonRoot | bool | `true` |  |
| valkey.valkey.metrics.exporter.securityContext.runAsUser | int | `1000` |  |
| valkey.valkey.metrics.exporter.securityContext.seccompProfile.type | string | `"RuntimeDefault"` |  |
| agent-platform-mcps.agentgateway.enabled | bool | `true` |  |
| agent-platform-mcps.agentgateway.viaMuster | bool | `true` |  |
| agent-platform-mcps.agentgateway.musterUrl | string | `"http://muster.agent-platform.svc.cluster.local:8090/mcp"` |  |
| agent-platform-mcps.mcpServers | list | `[]` |  |
| kagent.fullnameOverride | string | `"kagent"` |  |
| kagent.registry | string | `"gsoci.azurecr.io"` |  |
| kagent.controller.image.repository | string | `"giantswarm/kagent/controller-extensions"` |  |
| kagent.controller.agentImage.repository | string | `"giantswarm/kagent/golang-adk"` |  |
| kagent.controller.substrate.enabled | bool | `true` |  |
| kagent.controller.substrate.ateApiEndpoint | string | `"dns:///api.ate-system.svc:443"` |  |
| kagent.controller.substrate.atenetRouterURL | string | `"http://atenet-router.ate-system.svc:80"` |  |
| kagent.controller.auth.mode | string | `"trusted-proxy"` |  |
| kagent.controller.auth.userIdClaim | string | `"email"` |  |
| kagent.controller.authorization.mode | string | `"kubernetes"` |  |
| kagent.controller.authorization.usernamePrefix | string | `""` |  |
| kagent.controller.authorization.groupsClaim | string | `"groups"` |  |
| kagent.controller.authorization.groupsPrefix | string | `""` |  |
| kagent.controller.authorization.namespaceSelector | string | `"giantswarm.io/organization"` |  |
| kagent.controller.authorization.includeNamespaces | list | `[]` |  |
| kagent.controller.sessionIdleTTL | string | `"336h"` |  |
| kagent.controller.podAnnotations."karpenter.sh/do-not-disrupt" | string | `"true"` |  |
| kagent.controller.pdb.enabled | bool | `true` |  |
| kagent.controller.pdb.unhealthyPodEvictionPolicy | string | `"AlwaysAllow"` |  |
| kagent.controller.resources.requests.cpu | string | `"100m"` |  |
| kagent.controller.resources.requests.memory | string | `"128Mi"` |  |
| kagent.controller.resources.limits.cpu | int | `2` |  |
| kagent.controller.resources.limits.memory | string | `"1536Mi"` |  |
| kagent.controller.vpa.enabled | string | `"auto"` |  |
| kagent.controller.vpa.updateMode | string | `"InPlaceOrRecreate"` |  |
| kagent.controller.vpa.controlledValues | string | `"RequestsOnly"` |  |
| kagent.controller.vpa.minAllowed.cpu | string | `"100m"` |  |
| kagent.controller.vpa.minAllowed.memory | string | `"128Mi"` |  |
| kagent.controller.vpa.maxAllowed.cpu | string | `"1900m"` |  |
| kagent.controller.vpa.maxAllowed.memory | string | `"1280Mi"` |  |
| kagent.controller.metrics.enabled | bool | `true` |  |
| kagent.controller.metrics.bindAddress | string | `":8080"` |  |
| kagent.controller.metrics.secureServing | bool | `false` |  |
| kagent.controller.metrics.service.port | int | `8080` |  |
| kagent.controller.metrics.serviceMonitor.enabled | string | `"auto"` |  |
| kagent.controller.metrics.serviceMonitor.interval | string | `"60s"` |  |
| kagent.controller.metrics.serviceMonitor.labels."observability.giantswarm.io/tenant" | string | `"giantswarm"` |  |
| kagent.controller.env[0].name | string | `"OTEL_EXPORTER_OTLP_HEADERS"` |  |
| kagent.controller.env[0].value | string | `"auto"` |  |
| kagent.ui.image.repository | string | `"giantswarm/kagent/ui"` |  |
| kagent.substrateWorkerPool.create | bool | `true` |  |
| kagent.substrateWorkerPool.name | string | `"kagent-default"` |  |
| kagent.substrateWorkerPool.replicas | int | `4` |  |
| kagent.substrateWorkerPool.workerImage | string | `""` |  |
| kagent.substrateWorkerPool.sandboxClass | string | `"gvisor"` |  |
| kagent.substrateWorkerPool.podDisruptionBudget.enabled | bool | `true` |  |
| kagent.substrateWorkerPool.podDisruptionBudget.minAvailable | string | `nil` |  |
| kagent.substrateWorkerPool.podDisruptionBudget.maxUnavailable | int | `1` |  |
| kagent.substrateWorkerPool.podDisruptionBudget.unhealthyPodEvictionPolicy | string | `"AlwaysAllow"` |  |
| kagent.substrateWorkerPool.priorityClass.enabled | bool | `true` |  |
| kagent.substrateWorkerPool.priorityClass.name | string | `"agent-platform-worker-pool"` |  |
| kagent.substrateWorkerPool.priorityClass.value | int | `1000000` |  |
| kagent.substrateWorkerPool.template.nodeSelector."kubernetes.io/arch" | string | `"amd64"` |  |
| kagent.substrateWorkerPool.template.resources.requests.cpu | string | `"250m"` |  |
| kagent.substrateWorkerPool.template.resources.requests.memory | string | `"512Mi"` |  |
| kagent.substrateWorkerPool.template.resources.limits.cpu | string | `"2"` |  |
| kagent.substrateWorkerPool.template.resources.limits.memory | string | `"2Gi"` |  |
| kagent.database.postgres.vectorEnabled | bool | `true` |  |
| kagent.database.postgres.vectorSchema | string | `"public"` |  |
| kagent.namespaceOverride | string | `"kagent"` |  |
| kagent.podSecurityContext.runAsNonRoot | bool | `true` |  |
| kagent.podSecurityContext.seccompProfile.type | string | `"RuntimeDefault"` |  |
| kagent.securityContext.allowPrivilegeEscalation | bool | `false` |  |
| kagent.securityContext.capabilities.drop[0] | string | `"ALL"` |  |
| kagent.securityContext.seccompProfile.type | string | `"RuntimeDefault"` |  |
| kagent.providers.default | string | `"anthropic"` |  |
| kagent.providers.anthropic.provider | string | `"Anthropic"` |  |
| kagent.providers.anthropic.model | string | `"claude-sonnet-5-5"` |  |
| kagent.providers.anthropic.apiKeySecretRef | string | `"kagent-anthropic"` |  |
| kagent.providers.anthropic.apiKeySecretKey | string | `"ANTHROPIC_API_KEY"` |  |
| kagent.providers.anthropic.apiKey | string | `""` |  |
| kagent.providers.anthropic.config.promptCaching | bool | `true` |  |
| kagent.providers.anthropic.config.cacheTTL | string | `"5m"` |  |
| kagent.otel.exporter.otlp.endpoint | string | `"auto"` |  |
| kagent.otel.exporter.otlp.protocol | string | `"auto"` |  |
| kagent.otel.exporter.otlp.timeout | string | `"500"` |  |
| kagent.otel.traces.enabled | string | `"auto"` |  |
| kagent.otel.logs.enabled | string | `"auto"` |  |
| kagent.oauth2-proxy.enabled | bool | `false` |  |
| kagent.oauth2-proxy.fullnameOverride | string | `"kagent-oauth2-proxy"` |  |
| kagent.oauth2-proxy.image.registry | string | `"gsoci.azurecr.io"` |  |
| kagent.oauth2-proxy.image.repository | string | `"giantswarm/oauth2-proxy"` |  |
| kagent.oauth2-proxy.image.tag | string | `"v7.15.5"` |  |
| kagent.oauth2-proxy.namespaceOverride | string | `"kagent"` |  |
| kagent.oauth2-proxy.redis.enabled | bool | `false` |  |
| kagent.oauth2-proxy.sessionStorage.type | string | `"cookie"` |  |
| kagent.oauth2-proxy.extraVolumes[0].name | string | `"custom-templates"` |  |
| kagent.oauth2-proxy.extraVolumes[0].configMap.name | string | `"kagent-oauth2-proxy-templates"` |  |
| kagent.oauth2-proxy.extraVolumeMounts[0].name | string | `"custom-templates"` |  |
| kagent.oauth2-proxy.extraVolumeMounts[0].mountPath | string | `"/templates"` |  |
| kagent.oauth2-proxy.extraVolumeMounts[0].readOnly | bool | `true` |  |
| kagent.oauth2-proxy.config.existingSecret | string | `""` |  |
| kagent.oauth2-proxy.config.clientID | string | `""` |  |
| kagent.oauth2-proxy.config.clientSecret | string | `""` |  |
| kagent.oauth2-proxy.config.cookieSecret | string | `""` |  |
| kagent.oauth2-proxy.extraEnv[0].name | string | `"OIDC_ISSUER_URL"` |  |
| kagent.oauth2-proxy.extraEnv[0].value | string | `""` |  |
| kagent.oauth2-proxy.extraEnv[1].name | string | `"OIDC_REDIRECT_URL"` |  |
| kagent.oauth2-proxy.extraEnv[1].value | string | `""` |  |
| kagent.oauth2-proxy.extraEnv[2].name | string | `"UPSTREAM_URL"` |  |
| kagent.oauth2-proxy.extraEnv[2].value | string | `"http://kagent-ui:8080"` |  |
| kagent.oauth2-proxy.extraArgs.provider | string | `"oidc"` |  |
| kagent.oauth2-proxy.extraArgs.oidc-issuer-url | string | `"$(OIDC_ISSUER_URL)"` |  |
| kagent.oauth2-proxy.extraArgs.redirect-url | string | `"$(OIDC_REDIRECT_URL)"` |  |
| kagent.oauth2-proxy.extraArgs.upstream | string | `"$(UPSTREAM_URL)"` |  |
| kagent.oauth2-proxy.extraArgs.email-domain | string | `"*"` |  |
| kagent.oauth2-proxy.extraArgs.pass-authorization-header | bool | `true` |  |
| kagent.oauth2-proxy.extraArgs.set-authorization-header | bool | `true` |  |
| kagent.oauth2-proxy.extraArgs.approval-prompt | string | `"auto"` |  |
| kagent.oauth2-proxy.extraArgs.scope | string | `"openid profile email groups offline_access"` |  |
| kagent.oauth2-proxy.extraArgs.cookie-secure | bool | `true` |  |
| kagent.oauth2-proxy.extraArgs.cookie-samesite | string | `"lax"` |  |
| kagent.oauth2-proxy.extraArgs.cookie-refresh | string | `"10m"` |  |
| kagent.oauth2-proxy.extraArgs.reverse-proxy | bool | `true` |  |
| kagent.oauth2-proxy.extraArgs.skip-jwt-bearer-tokens | bool | `true` |  |
| kagent.oauth2-proxy.extraArgs.skip-auth-route | string | `"^/(health|login)$"` |  |
| kagent.oauth2-proxy.extraArgs.skip-auth-regex | string | `"^/(login|env-config\\.js|favicon\\.svg|assets/[^/]+\\.(js|css|svg|png|woff2?))$"` |  |
| kagent.oauth2-proxy.extraArgs.custom-templates-dir | string | `"/templates"` |  |
| kagent.oauth2-proxy.service.type | string | `"ClusterIP"` |  |
| kagent.oauth2-proxy.service.portNumber | int | `4180` |  |
| kagent.oauth2-proxy.metrics.enabled | bool | `true` |  |
| kagent.oauth2-proxy.metrics.serviceMonitor.enabled | string | `"auto"` |  |
| kagent.oauth2-proxy.metrics.serviceMonitor.interval | string | `"60s"` |  |
| kagent.oauth2-proxy.metrics.serviceMonitor.labels."observability.giantswarm.io/tenant" | string | `"giantswarm"` |  |
| kagent.grafana-mcp.enabled | bool | `false` |  |
| kagent.fluxServiceAccountName | string | `"kagent-flux"` | The ServiceAccount the agents' Flux `HelmRelease`s execute as. The connectivity chart renders it in the kagent namespace whenever kagent is on, bound to the Role `<name>-agent-releases` there (the Generic agent chart's Agents and RemoteMCPServers and Helm's release Secrets, nothing outside the kagent namespace); this chart derives agent-manager's `flux.helmReleaseServiceAccount` from it and the portal's `agentPlatform.fluxServiceAccountName` is rendered from the same value — ONE value, three consumers, so they cannot disagree. Under a Flux multi-tenancy lockdown a `HelmRelease` without it runs as the rights-less default ServiceAccount and fails. Empty renders no identity and hands both callers an empty name. |
| kagent.harness.create | bool | `true` |  |
| kagent.harness.image | string | `""` |  |
| kagent.harness.compaction.tokenThreshold | int | `600000` |  |
| kagent.harness.compaction.eventRetentionSize | int | `4` |  |
| kagent.harness.snapshotLocation | string | `""` |  |
| kagent.harness.snapshotStore.prefix | string | `"kagent"` |  |
| kagent.harness.snapshotStore.crossplane.enabled | bool | `false` |  |
| kagent.harness.snapshotStore.crossplane.provider | string | `"aws"` |  |
| kagent.harness.snapshotStore.crossplane.providerConfigRef | string | `""` |  |
| kagent.harness.snapshotStore.crossplane.region | string | `""` |  |
| kagent.harness.snapshotStore.crossplane.observeOnly | bool | `false` |  |
| kagent.harness.snapshotStore.crossplane.tags | object | `{}` |  |
| kagent.harness.snapshotStore.crossplane.aws.bucketName | string | `""` |  |
| kagent.harness.snapshotStore.crossplane.aws.accountId | string | `""` |  |
| kagent.harness.snapshotStore.crossplane.aws.oidcProvider | string | `""` |  |
| kagent.harness.snapshotStore.crossplane.aws.roleName | string | `""` |  |
| kagent.harness.snapshotStore.crossplane.capz.storageAccountName | string | `""` |  |
| kagent.harness.snapshotStore.crossplane.capz.containerName | string | `""` |  |
| kagent.harness.snapshotStore.crossplane.capz.resourceGroup | string | `""` |  |
| kagent.harness.snapshotStore.crossplane.capz.subscriptionId | string | `""` |  |
| kagent.harness.snapshotStore.crossplane.capz.replicationType | string | `"LRS"` |  |
| kagent.harness.snapshotStore.crossplane.capz.workloadIdentity.oidcIssuerUrl | string | `""` |  |
| kagent.harness.snapshotStore.crossplane.capz.workloadIdentity.identityName | string | `""` |  |
| kagent.harness.snapshotStore.crossplane.capz.workloadIdentity.providerKubernetes.providerConfigRef | string | `""` |  |
| kagent.harness.snapshotStore.crossplane.capz.workloadIdentity.providerKubernetes.serviceAccount.name | string | `""` |  |
| kagent.harness.snapshotStore.crossplane.capz.workloadIdentity.providerKubernetes.serviceAccount.namespace | string | `"crossplane"` |  |
| kagent.harness.snapshotStore.s3proxy.enabled | bool | `false` |  |
| kagent.harness.snapshotStore.s3proxy.image.repository | string | `"gsoci.azurecr.io/giantswarm/s3proxy"` |  |
| kagent.harness.snapshotStore.s3proxy.image.tag | string | `"4.1.1"` |  |
| kagent.harness.snapshotStore.s3proxy.replicas | int | `2` |  |
| kagent.harness.snapshotStore.s3proxy.javaOpts | string | `"-XX:MaxRAMPercentage=70"` |  |
| kagent.harness.snapshotStore.s3proxy.resources.requests.cpu | string | `"250m"` |  |
| kagent.harness.snapshotStore.s3proxy.resources.requests.memory | string | `"1Gi"` |  |
| kagent.harness.snapshotStore.s3proxy.resources.requests.ephemeral-storage | string | `"256Mi"` |  |
| kagent.harness.snapshotStore.s3proxy.resources.limits.memory | string | `"1Gi"` |  |
| kagent.harness.snapshotStore.s3proxy.resources.limits.ephemeral-storage | string | `"1Gi"` |  |
| kagent.harness.snapshotStore.s3proxy.azure.endpoint | string | `""` |  |
| kagent.harness.snapshotStore.s3proxy.azure.account | string | `""` |  |
| kagent.harness.snapshotStore.s3proxy.azure.container | string | `""` |  |
| kagent.harness.snapshotStore.s3proxy.azure.accountKeySecretRef.name | string | `""` |  |
| kagent.harness.snapshotStore.s3proxy.azure.accountKeySecretRef.key | string | `""` |  |
| kagent.harness.env[0].name | string | `"KAGENT_PROPAGATE_TOKEN"` |  |
| kagent.harness.env[0].value | string | `"true"` |  |
| kagent.harness.env[1].name | string | `"OTEL_EXPORTER_OTLP_HEADERS"` |  |
| kagent.harness.env[1].value | string | `"auto"` |  |
| kagent.controllerRoute.enabled | bool | `false` |  |
| kagent.controllerRoute.hostname | string | `""` |  |
| kagent.controllerRoute.parentRef.name | string | `"giantswarm-default"` |  |
| kagent.controllerRoute.parentRef.namespace | string | `"envoy-gateway-system"` |  |
| kagent.controllerRoute.grpc.services."kagent.api.v1alpha1.AgentService" | list | `[]` |  |
| kagent.controllerRoute.grpc.services."kagent.api.v1alpha1.AgentTemplateService" | list | `[]` |  |
| kagent.controllerRoute.grpc.services."kagent.api.v1alpha1.HarnessService" | list | `[]` |  |
| kagent.controllerRoute.grpc.services."kagent.api.v1alpha1.ModelService" | list | `[]` |  |
| kagent.controllerRoute.grpc.services."kagent.api.v1alpha1.SessionService" | list | `[]` |  |
| kagent.controllerRoute.grpc.services."kagent.api.v1alpha1.SystemService" | list | `[]` |  |
| kagent.controllerRoute.grpc.services."lf.a2a.v1.A2AService" | list | `[]` |  |
| kagent.controllerRoute.mcp.enabled | bool | `true` |  |
| kagent.controllerRoute.mcp.pathPrefix | string | `"/kagent/mcp"` |  |
| kagent.controllerRoute.mcp.timeout | int | `300` |  |
| kagent.controllerRoute.mcp.displayName | string | `"Kagent"` |  |
| kagent.controllerRoute.jwtAuthentication.enabled | bool | `true` |  |
| kagent.controllerRoute.jwtAuthentication.mode | string | `"Strict"` |  |
| kagent.controllerRoute.jwtAuthentication.issuer | string | `""` |  |
| kagent.controllerRoute.jwtAuthentication.jwks.host | string | `"dex.giantswarm.svc.cluster.local"` |  |
| kagent.controllerRoute.jwtAuthentication.jwks.port | int | `5556` |  |
| kagent.controllerRoute.jwtAuthentication.jwks.path | string | `"/keys"` |  |
| kagent.controllerRoute.jwtAuthentication.jwks.tls.enabled | bool | `false` |  |
| kagent.controllerRoute.jwtAuthentication.jwks.tls.caSecretName | string | `""` |  |
| kagent.uiRoute.enabled | bool | `false` |  |
| kagent.uiRoute.hostname | string | `""` |  |
| kagent.uiRoute.parentRef.name | string | `"giantswarm-default"` |  |
| kagent.uiRoute.parentRef.namespace | string | `"envoy-gateway-system"` |  |
| kagent.uiRoute.backendTrafficPolicy.enabled | bool | `true` |  |
| kagent.uiRoute.backendTrafficPolicy.timeout | string | `"60s"` |  |
| kagent.uiRoute.backendTrafficPolicy.annotations | object | `{}` |  |
| kagent.uiRoute.backendTrafficPolicy.labels | object | `{}` |  |
| kagent.modelConfigs | list | `[]` |  |
| kagent.remoteMcpServers | list | `[]` |  |
| kagent.harnesses | list | `[]` |  |
| dashboards.enabled | bool | `true` |  |
| dashboards.namespace | string | `""` |  |
| dashboards.organization | string | `"Shared Org"` |  |
| dashboards.folder | string | `"Agent Platform"` |  |
| postgres.enabled | bool | `false` |  |
| postgres.namespace | string | `"kagent"` |  |
| postgres.clusterName | string | `"kagent-pg"` |  |
| postgres.instances | int | `3` |  |
| postgres.primaryUpdateMethod | string | `"switchover"` |  |
| postgres.storage.size | string | `"20Gi"` |  |
| postgres.storage.storageClass | string | `""` |  |
| postgres.image.name | string | `""` |  |
| postgres.imagePullSecrets | list | `[]` |  |
| postgres.affinity | object | `{}` |  |
| postgres.resources.requests.cpu | string | `"100m"` |  |
| postgres.resources.requests.memory | string | `"512Mi"` |  |
| postgres.resources.requests.ephemeral-storage | string | `"256Mi"` |  |
| postgres.resources.limits.cpu | string | `"1"` |  |
| postgres.resources.limits.memory | string | `"2Gi"` |  |
| postgres.resources.limits.ephemeral-storage | string | `"2Gi"` |  |
| postgres.ephemeralVolumesSizeLimit.shm | string | `"256Mi"` |  |
| postgres.ephemeralVolumesSizeLimit.temporaryData | string | `"1Gi"` |  |
| postgres.vector.enabled | bool | `false` |  |
| postgres.vector.extensionImage.reference | string | `""` |  |
| postgres.applicationDatabase.name | string | `"kagent"` |  |
| postgres.applicationDatabase.owner | string | `"kagent"` |  |
| postgres.applicationDatabase.schema | string | `"kagent"` |  |
| postgres.applicationDatabase.ensure | string | `"present"` |  |
| postgres.sessionsDatabase.enabled | bool | `false` |  |
| postgres.sessionsDatabase.name | string | `"sessions"` |  |
| postgres.sessionsDatabase.owner | string | `"sessions"` |  |
| postgres.substrateDatabase | string | `"substrate"` |  |
| postgres.databases.substrate.enabled | bool | `true` |  |
| postgres.databases.substrate.name | string | `"substrate"` |  |
| postgres.databases.substrate.component | string | `"substrate"` |  |
| postgres.databases.substrate.extensions | list | `[]` |  |
| postgres.databases.substrate.reclaimPolicy | string | `"retain"` |  |
| postgres.databases.substrate.secretNamespaces[0] | string | `"ate-system"` |  |
| postgres.databases.kagent-v2.enabled | bool | `true` |  |
| postgres.databases.kagent-v2.name | string | `"kagent_v2"` |  |
| postgres.databases.kagent-v2.extensions[0] | string | `"vector"` |  |
| postgres.databases.kagent-v2.reclaimPolicy | string | `"retain"` |  |
| postgres.databases.kagent-v2.component | string | `"kagent"` |  |
| postgres.databases.kagent-v2.secretNamespaces | list | `[]` |  |
| postgres.backup.enabled | bool | `false` |  |
| postgres.backup.method | string | `"plugin"` |  |
| postgres.backup.schedule | string | `"0 0 2 * * *"` |  |
| postgres.backup.immediate | bool | `true` |  |
| postgres.backup.suspend | bool | `false` |  |
| postgres.backup.serverName | string | `""` |  |
| postgres.backup.objectStore.existingName | string | `""` |  |
| postgres.backup.objectStore.destinationPath | string | `""` |  |
| postgres.backup.objectStore.endpointURL | string | `""` |  |
| postgres.backup.objectStore.retentionPolicy | string | `"30d"` |  |
| postgres.backup.objectStore.wal.compression | string | `"gzip"` |  |
| postgres.backup.objectStore.wal.maxParallel | int | `1` |  |
| postgres.backup.objectStore.data.compression | string | `"gzip"` |  |
| postgres.backup.objectStore.s3.inheritFromIAMRole | bool | `false` |  |
| postgres.backup.objectStore.s3.accessKeyId.name | string | `""` |  |
| postgres.backup.objectStore.s3.accessKeyId.key | string | `"ACCESS_KEY_ID"` |  |
| postgres.backup.objectStore.s3.secretAccessKey.name | string | `""` |  |
| postgres.backup.objectStore.s3.secretAccessKey.key | string | `"ACCESS_SECRET_KEY"` |  |
| postgres.backup.objectStore.azure.inheritFromAzureAD | bool | `false` |  |
| postgres.backup.objectStore.azure.connectionString.name | string | `""` |  |
| postgres.backup.objectStore.azure.connectionString.key | string | `""` |  |
| postgres.backup.objectStore.azure.storageAccount.name | string | `""` |  |
| postgres.backup.objectStore.azure.storageAccount.key | string | `""` |  |
| postgres.backup.objectStore.azure.storageKey.name | string | `""` |  |
| postgres.backup.objectStore.azure.storageKey.key | string | `""` |  |
| postgres.backup.objectStore.sidecar.resources.requests.cpu | string | `"10m"` |  |
| postgres.backup.objectStore.sidecar.resources.requests.memory | string | `"64Mi"` |  |
| postgres.backup.objectStore.sidecar.resources.requests.ephemeral-storage | string | `"16Mi"` |  |
| postgres.backup.objectStore.sidecar.resources.limits.memory | string | `"256Mi"` |  |
| postgres.backup.objectStore.sidecar.resources.limits.ephemeral-storage | string | `"256Mi"` |  |
| postgres.backup.volumeSnapshot.className | string | `""` |  |
| postgres.backup.volumeSnapshot.walClassName | string | `""` |  |
| postgres.backup.volumeSnapshot.online | bool | `true` |  |
| postgres.backup.serviceAccount.annotations | object | `{}` |  |
| postgres.backup.networkPolicy.ports[0] | string | `"443"` |  |
| postgres.backup.networkPolicy.fqdns | list | `[]` |  |
| postgres.backup.networkPolicy.cidrs | list | `[]` |  |
| postgres.backup.crossplane.enabled | bool | `false` |  |
| postgres.backup.crossplane.provider | string | `"aws"` |  |
| postgres.backup.crossplane.providerConfigRef | string | `""` |  |
| postgres.backup.crossplane.region | string | `""` |  |
| postgres.backup.crossplane.observeOnly | bool | `false` |  |
| postgres.backup.crossplane.tags | object | `{}` |  |
| postgres.backup.crossplane.aws.bucketName | string | `""` |  |
| postgres.backup.crossplane.aws.accountId | string | `""` |  |
| postgres.backup.crossplane.aws.oidcProvider | string | `""` |  |
| postgres.backup.crossplane.aws.roleName | string | `""` |  |
| postgres.backup.crossplane.aws.lifecycleDays | int | `45` |  |
| postgres.backup.crossplane.azure.storageAccountName | string | `""` |  |
| postgres.backup.crossplane.azure.containerName | string | `""` |  |
| postgres.backup.crossplane.azure.resourceGroup | string | `""` |  |
| postgres.backup.crossplane.azure.replicationType | string | `"LRS"` |  |
| postgres.backup.crossplane.azure.lifecycleDays | int | `45` |  |
| postgres.backup.crossplane.azure.private | bool | `false` |  |
| postgres.backup.crossplane.azure.subscriptionId | string | `""` |  |
| postgres.backup.crossplane.azure.vnetName | string | `""` |  |
| postgres.backup.crossplane.azure.subnetName | string | `"node-subnet"` |  |
| postgres.backup.crossplane.azure.privateDnsZoneRef | string | `""` |  |
| klausGateway.image.registry | string | `"gsoci.azurecr.io"` |  |
| klausGateway.podAnnotations."karpenter.sh/do-not-disrupt" | string | `"true"` |  |
| klausGateway.podDisruptionBudget.enabled | bool | `true` |  |
| klausGateway.podDisruptionBudget.minAvailable | string | `""` |  |
| klausGateway.podDisruptionBudget.maxUnavailable | int | `1` |  |
| klausGateway.podDisruptionBudget.unhealthyPodEvictionPolicy | string | `"AlwaysAllow"` |  |
| klausGateway.routing.store | string | `"memory"` |  |
| klausGateway.observability.enabled | string | `"auto"` |  |
| klausGateway.observability.otlpEndpoint | string | `"auto"` |  |
| klausGateway.observability.otlpHeaders | string | `"auto"` |  |
| klausGateway.serviceMonitor.enabled | string | `"auto"` |  |
| klausGateway.serviceMonitor.labels."observability.giantswarm.io/tenant" | string | `"giantswarm"` |  |
| klausGateway.slack.enabled | bool | `false` |  |
| klausGateway.slack.mode | string | `"events"` |  |
| klausGateway.slack.secretName | string | `""` |  |
| klausGateway.slack.dmMode | string | `""` |  |
| klausGateway.slack.channelMode | string | `""` |  |
| klausGateway.slack.contextBotIDs | list | `[]` | contextBotIDs lists the Slack bot_ids (B…) whose posts a thread read hands to the agent: the installation's alerting integrations a conversation is opened under (Alertmanager, PagerDuty). Every human's message is shared; any other bot's post is left out. Empty (the default) shares no bot's post and is not forwarded; a list needs klaus-gateway 4.2.0 or later. Rendered as SLACK_CONTEXT_BOT_IDS. |
| klausGateway.slack.channelAllowlist | list | `[]` |  |
| klausGateway.slack.botToken | string | `""` |  |
| klausGateway.slack.signingSecret | string | `""` |  |
| klausGateway.slack.appToken | string | `""` |  |
| klausGateway.obo.enabled | bool | `false` |  |
| klausGateway.obo.musterUrl | string | `""` |  |
| klausGateway.obo.callbackBaseUrl | string | `""` |  |
| klausGateway.obo.storePath | string | `""` |  |
| klausGateway.obo.persistence.enabled | bool | `false` |  |
| klausGateway.obo.persistence.size | string | `"64Mi"` |  |
| klausGateway.obo.existingSecret | string | `""` |  |
| klausGateway.obo.stateKey | string | `""` |  |
| klausGateway.obo.storeKey | string | `""` |  |
| klausGateway.obo.connectors.enabled | bool | `false` |  |
| klausGateway.a2a.enabled | bool | `false` |  |
| klausGateway.a2a.defaultAgent | string | `""` |  |
| klausGateway.a2a.url | string | `"grpc://agentgateway.agent-platform.svc.cluster.local:8080"` |  |
| klausGateway.a2a.fallbackIconUrlTemplate | string | `""` |  |
| klausGateway.refusals.enabled | string | `"auto"` |  |
| klausGateway.agentgatewayRoute.enabled | bool | `false` |  |
| klausGateway.agentgatewayRoute.hostname | string | `""` |  |
| agentgateway.fullnameOverride | string | `"agentgateway-controller"` |  |
| agentgateway.image.registry | string | `"gsoci.azurecr.io"` |  |
| agentgateway.controller.image.registry | string | `"gsoci.azurecr.io"` |  |
| agentgateway.controller.image.repository | string | `"giantswarm/agentgateway-upstream/controller"` |  |
| agentgateway.controller.image.tag | string | `"2.6.10"` |  |
| agentgateway.controller.replicaCount | int | `2` |  |
| agentgateway.inferenceExtension.enabled | bool | `true` |  |
| agentgateway.proxy.image.registry | string | `"gsoci.azurecr.io"` |  |
| agentgateway.proxy.image.repository | string | `"giantswarm/agentgateway-upstream/agentgateway"` |  |
| agentgateway.proxy.image.tag | string | `"2.6.10"` |  |
| agentgateway.podAnnotations."application.giantswarm.io/team" | string | `"bumblebee"` |  |
| agentgateway.podSecurityContext.runAsNonRoot | bool | `true` |  |
| agentgateway.podSecurityContext.seccompProfile.type | string | `"RuntimeDefault"` |  |
| agentgateway.securityContext.allowPrivilegeEscalation | bool | `false` |  |
| agentgateway.securityContext.readOnlyRootFilesystem | bool | `true` |  |
| agentgateway.securityContext.runAsNonRoot | bool | `true` |  |
| agentgateway.securityContext.capabilities.drop[0] | string | `"ALL"` |  |
| agentgateway.securityContext.seccompProfile.type | string | `"RuntimeDefault"` |  |
| agentgateway.resources.requests.cpu | string | `"50m"` |  |
| agentgateway.resources.requests.memory | string | `"128Mi"` |  |
| agentgateway.resources.limits.cpu | string | `"500m"` |  |
| agentgateway.resources.limits.memory | string | `"512Mi"` |  |
| agentgateway.monitoring.enabled | string | `"auto"` |  |
| agentgateway.monitoring.serviceMonitor.enabled | bool | `true` |  |
| agentgateway.monitoring.serviceMonitor.interval | string | `"60s"` |  |
| agentgateway.monitoring.serviceMonitor.extraLabels."observability.giantswarm.io/tenant" | string | `"giantswarm"` |  |
| agentgateway.monitoring.grafanaDashboard.enabled | bool | `true` |  |
| agentgateway.monitoring.grafanaDashboard.labels."app.giantswarm.io/kind" | string | `"dashboard"` |  |
| agentgateway.monitoring.grafanaDashboard.annotations."observability.giantswarm.io/organization" | string | `"Shared Org"` |  |
| agentgateway.monitoring.grafanaDashboard.annotations."observability.giantswarm.io/folder" | string | `"Agent Platform"` |  |
| agentSandbox.podSecurity.enabled | string | `"auto"` |  |
| agentSandbox.podSecurity.namespace | string | `"agent-sandbox-system"` |  |
| agentSandbox.podSecurity.podSecurityContext.runAsNonRoot | bool | `true` |  |
| agentSandbox.podSecurity.podSecurityContext.seccompProfile.type | string | `"RuntimeDefault"` |  |
| agentSandbox.podSecurity.containerSecurityContext.allowPrivilegeEscalation | bool | `false` |  |
| agentSandbox.podSecurity.containerSecurityContext.capabilities.drop[0] | string | `"ALL"` |  |
| agentSandbox.podSecurity.containerSecurityContext.runAsNonRoot | bool | `true` |  |
| agentSandbox.podSecurity.containerSecurityContext.seccompProfile.type | string | `"RuntimeDefault"` |  |
| model-manager.fullnameOverride | string | `"model-manager"` |  |
| model-manager.observability.otel.endpoint | string | `"auto"` |  |
| model-manager.observability.otel.protocol | string | `"auto"` |  |
| model-manager.observability.otel.headers | string | `"auto"` |  |
| model-manager.ollama.endpoint | string | `""` |  |
| model-manager.ollama.agentHost | string | `""` |  |
| model-manager.lemonade.endpoint | string | `""` |  |
| model-manager.lemonade.agentHost | string | `""` |  |
| model-manager.lmstudio.endpoint | string | `""` |  |
| model-manager.lmstudio.agentHost | string | `""` |  |
| model-manager.kagent.namespace | string | `"kagent"` |  |
| model-manager.kagent.apiVersion | string | `"v1alpha3"` |  |
| model-manager.kagent.disableWiring | bool | `false` |  |
| model-manager.mcp.enabled | bool | `true` |  |
| model-manager.oauth.enabled | bool | `true` |  |
| model-manager.oauth.provider | string | `"dex"` |  |
| model-manager.oauth.dex.allowPrivateURLs | bool | `true` |  |
| model-manager.oauth.sso.allowPrivateIPs | bool | `true` |  |
| model-manager.oauth.downstream.enabled | bool | `true` |  |
| model-manager.muster.mcpServer.enabled | bool | `true` |  |
| model-manager.muster.mcpServer.auth.forwardToken | bool | `true` |  |
| model-manager.muster.mcpServer.auth.requiredAudiences[0] | string | `"dex-k8s-authenticator"` |  |
| model-manager.networkPolicy.enabled | bool | `false` |  |
| model-manager.serviceMonitor.enabled | string | `"auto"` |  |
| model-manager.serviceMonitor.interval | string | `"60s"` |  |
| model-manager.serviceMonitor.labels."observability.giantswarm.io/tenant" | string | `"giantswarm"` |  |
| modelManager.kserve.requireApi | bool | `true` |  |
| modelManager.networkPolicy.ingress.additionalPeers | list | `[]` |  |
| modelManager.networkPolicy.huggingFace.fqdns[0].matchName | string | `"huggingface.co"` |  |
| modelManager.networkPolicy.huggingFace.fqdns[1].matchPattern | string | `"*.huggingface.co"` |  |
| modelManager.networkPolicy.huggingFace.fqdns[2].matchPattern | string | `"*.hf.co"` |  |
| modelManager.networkPolicy.huggingFace.fqdns[3].matchPattern | string | `"*.*.hf.co"` |  |
| modelManager.networkPolicy.huggingFace.fqdns[4].matchPattern | string | `"*.*.*.hf.co"` |  |
| modelManager.networkPolicy.huggingFace.cidrs | list | `[]` |  |
| modelManager.networkPolicy.registry.fqdns[0].matchName | string | `"gsoci.azurecr.io"` |  |
| modelManager.networkPolicy.registry.fqdns[1].matchPattern | string | `"*.blob.core.windows.net"` |  |
| modelManager.networkPolicy.registry.cidrs | list | `[]` |  |
| modelManager.networkPolicy.workloadClusters | object | `{}` |  |
| modelManager.networkPolicy.egress.fqdns | list | `[]` |  |
| modelManager.networkPolicy.egress.cidrs | list | `[]` |  |
| modelManager.networkPolicy.registeredBackends | list | `[]` |  |
| vm-manager.fullnameOverride | string | `"vm-manager"` |  |
| vm-manager.observability.otel.endpoint | string | `"auto"` |  |
| vm-manager.observability.otel.protocol | string | `"auto"` |  |
| vm-manager.observability.otel.headers | string | `"auto"` |  |
| vm-manager.persistence.existingClaim | string | `""` |  |
| vm-manager.persistence.create | bool | `false` |  |
| vm-manager.oauth.enabled | bool | `true` |  |
| vm-manager.oauth.provider | string | `"dex"` |  |
| vm-manager.oauth.dex.allowPrivateURLs | bool | `true` |  |
| vm-manager.oauth.sso.allowPrivateIPs | bool | `true` |  |
| vm-manager.muster.mcpServer.enabled | bool | `true` |  |
| vm-manager.muster.mcpServer.auth.forwardToken | bool | `true` |  |
| vm-manager.muster.mcpServer.auth.requiredAudiences | list | `[]` |  |
| vm-manager.networkPolicy.enabled | bool | `false` |  |
| vm-manager.serviceMonitor.enabled | string | `"auto"` |  |
| vm-manager.serviceMonitor.interval | string | `"60s"` |  |
| vm-manager.serviceMonitor.labels."observability.giantswarm.io/tenant" | string | `"giantswarm"` |  |
| vmManager.podDisruptionBudget.enabled | bool | `true` |  |
| vmManager.podDisruptionBudget.minAvailable | int | `1` |  |
| vmManager.podDisruptionBudget.maxUnavailable | string | `nil` |  |
| vmManager.podDisruptionBudget.unhealthyPodEvictionPolicy | string | `"AlwaysAllow"` |  |
| vmManager.networkPolicy.ingress.additionalPeers | list | `[]` |  |
| vmManager.networkPolicy.guestEgress.cidrs[0] | string | `"0.0.0.0/0"` |  |
| vmManager.networkPolicy.guestEgress.except | list | `[]` |  |
| agent-manager.fullnameOverride | string | `"agent-manager"` |  |
| agent-manager.observability.otel.endpoint | string | `"auto"` |  |
| agent-manager.observability.otel.protocol | string | `"auto"` |  |
| agent-manager.observability.otel.headers | string | `"auto"` |  |
| agent-manager.kagent.namespace | string | `"kagent"` |  |
| agent-manager.kagent.apiVersion | string | `"v1alpha3"` |  |
| agent-manager.harness.egress | object | `{}` | The origins a coding agent reaches, by the name of its Harness ({claude: [https://github.com, …], codex: […], omp: […]}): the installation's forge and git hosts plus the toolchain's registries; the model host is not listed (kagent adds the ModelConfig's destination). agent-manager writes the list into the Agent's spec.egress and the Substrate egress gate refuses any other origin with a 403; agent-manager refuses an agent on a coding Harness without an entry. Empty (the default) is not forwarded and the agent-manager chart's own list applies: GitHub for claude (and codex from agent-manager 2.2.0) plus the Go and npm registries for claude-go and claude-node. Each kagent.harnesses entry an installation adds gets its entry here; an installation whose forge is not GitHub sets every Harness it serves: Helm merges the map into the chart's, so a Harness left out keeps the GitHub list. Needs agent-manager 1.11.0 or later. |
| agent-manager.agentChart.ociUrl | string | `"oci://gsoci.azurecr.io/charts/giantswarm/agent"` |  |
| agent-manager.agentChart.semver | string | `">=2.0.0 <3.0.0"` |  |
| agent-manager.skills.repositories[0] | string | `"https://github.com/giantswarm/agent-skills"` |  |
| agent-manager.mcp.enabled | bool | `true` |  |
| agent-manager.oauth.enabled | bool | `true` |  |
| agent-manager.oauth.provider | string | `"dex"` |  |
| agent-manager.oauth.dex.allowPrivateURLs | bool | `true` |  |
| agent-manager.oauth.sso.allowPrivateIPs | bool | `true` |  |
| agent-manager.oauth.downstream.enabled | bool | `true` |  |
| agent-manager.muster.mcpServer.enabled | bool | `true` |  |
| agent-manager.muster.mcpServer.auth.forwardToken | bool | `true` |  |
| agent-manager.muster.mcpServer.auth.requiredAudiences[0] | string | `"dex-k8s-authenticator"` |  |
| agent-manager.networkPolicy.enabled | bool | `false` |  |
| agent-manager.serviceMonitor.enabled | string | `"auto"` |  |
| agent-manager.serviceMonitor.interval | string | `"60s"` |  |
| agent-manager.serviceMonitor.labels."observability.giantswarm.io/tenant" | string | `"giantswarm"` |  |
| agentManager.route.enabled | bool | `false` |  |
| agentManager.route.pathPrefix | string | `"/agent-manager"` |  |
| agentManager.route.hostname | string | `""` |  |
| agentManager.route.parentRef.name | string | `"giantswarm-default"` |  |
| agentManager.route.parentRef.namespace | string | `"envoy-gateway-system"` |  |
| agentManager.route.jwtAuthentication.enabled | bool | `false` |  |
| agentManager.route.jwtAuthentication.mode | string | `"Strict"` |  |
| agentManager.route.jwtAuthentication.issuer | string | `""` |  |
| agentManager.route.jwtAuthentication.jwks.host | string | `"dex.giantswarm.svc.cluster.local"` |  |
| agentManager.route.jwtAuthentication.jwks.port | int | `5556` |  |
| agentManager.route.jwtAuthentication.jwks.path | string | `"/keys"` |  |
| agentManager.route.jwtAuthentication.jwks.tls.enabled | bool | `false` |  |
| agentManager.route.jwtAuthentication.jwks.tls.caSecretName | string | `""` |  |
| agentManager.podDisruptionBudget.enabled | bool | `true` |  |
| agentManager.podDisruptionBudget.minAvailable | string | `nil` |  |
| agentManager.podDisruptionBudget.maxUnavailable | int | `1` |  |
| agentManager.podDisruptionBudget.unhealthyPodEvictionPolicy | string | `"AlwaysAllow"` |  |
| agentManager.flux.requireApi | bool | `false` |  |
| agentManager.networkPolicy.ingress.additionalPeers | list | `[]` |  |
| agentManager.networkPolicy.egress.fqdns[0].matchPattern | string | `"*.blob.core.windows.net"` |  |
| agentManager.networkPolicy.egress.fqdns[1].matchName | string | `"api.github.com"` |  |
| agentManager.networkPolicy.egress.cidrs | list | `[]` |  |
| agentManager.migration.enabled | bool | `true` |  |
| agentManager.migration.image.registry | string | `"gsoci.azurecr.io"` |  |
| agentManager.migration.image.repository | string | `"giantswarm/agent-manager"` |  |
| agentManager.migration.image.tag | string | `"2.17.14"` |  |
| agentManager.migration.dryRun | bool | `false` |  |
| agentManager.migration.gitopsNamespaces | list | `[]` |  |
| cluster-manager.fullnameOverride | string | `"cluster-manager"` |  |
| cluster-manager.observability.otel.endpoint | string | `"auto"` |  |
| cluster-manager.observability.otel.protocol | string | `"auto"` |  |
| cluster-manager.observability.otel.headers | string | `"auto"` |  |
| cluster-manager.installation.name | string | `""` |  |
| cluster-manager.mcp.enabled | bool | `true` |  |
| cluster-manager.oauth.enabled | bool | `true` |  |
| cluster-manager.oauth.provider | string | `"dex"` |  |
| cluster-manager.oauth.dex.allowPrivateURLs | bool | `true` |  |
| cluster-manager.oauth.sso.allowPrivateIPs | bool | `true` |  |
| cluster-manager.oauth.downstream.enabled | bool | `true` |  |
| cluster-manager.muster.mcpServer.enabled | bool | `true` |  |
| cluster-manager.muster.mcpServer.auth.forwardToken | bool | `true` |  |
| cluster-manager.muster.mcpServer.auth.requiredAudiences[0] | string | `"dex-k8s-authenticator"` |  |
| cluster-manager.serviceMonitor.enabled | string | `"auto"` |  |
| cluster-manager.serviceMonitor.interval | string | `"60s"` |  |
| cluster-manager.serviceMonitor.labels."observability.giantswarm.io/tenant" | string | `"giantswarm"` |  |
| clusterManager.flux.requireApi | bool | `false` |  |
| clusterManager.prewarmPriorityClass.enabled | bool | `true` |  |
| clusterManager.prewarmPriorityClass.name | string | `"agent-platform-prewarm-placeholder"` |  |
| clusterManager.prewarmPriorityClass.value | int | `-1000` |  |
| clusterManager.networkPolicy.ingress.additionalPeers | list | `[]` |  |
| clusterManager.networkPolicy.workloadClusters.provider | string | `""` |  |
| clusterManager.networkPolicy.workloadClusters.fqdns | list | `[]` |  |
| clusterManager.networkPolicy.workloadClusters.cidrs | list | `[]` |  |
| clusterManager.networkPolicy.workloadClusters.ports[0] | int | `443` |  |
| clusterManager.networkPolicy.workloadClusters.ports[1] | int | `6443` |  |
| clusterManager.networkPolicy.egress.fqdns | list | `[]` |  |
| clusterManager.networkPolicy.egress.cidrs | list | `[]` |  |
| tenants.platform.users | list | `[{"apiGroup":"rbac.authorization.k8s.io","kind":"Group","name":"system:authenticated"}]` | Every signed-in person: bound to agent-platform:user in the kagent namespace, and to `list` (with get and watch) on muster's MCPServers in muster's namespace (the servers for everyone). RBAC subjects. The default, system:authenticated, gives this to every user. It also gives it to every ServiceAccount, so every pod in the cluster can read the platform tenant's Agents, RemoteMCPServer URLs and muster's MCPServer specs. To give it to people only, replace the default with an OIDC group that every user belongs to, written as the API server sees it (with the installation's OIDC groups prefix). |
| tenants.platform.editors | list | `[{"apiGroup":"rbac.authorization.k8s.io","kind":"Group","name":"giantswarm-ad:giantswarm-admins"},{"apiGroup":"rbac.authorization.k8s.io","kind":"Group","name":"giantswarm-github:giantswarm:giantswarm-admins"}]` | The platform's operators: bound to agent-platform:editor in the kagent namespace. RBAC subjects. The Giant Swarm admin groups, as in muster.rbac.*.subjects. |
| tenants.platformTeam | list | `[]` | The customer's platform team, per installation: RBAC subjects bound to agent-platform:editor in the kagent namespace beside `platform.editors`, and added to muster's mcpserver-editor and workflow-editor subjects beside muster.rbac.*.subjects (the meta chart appends them to the muster release's values). Empty by default. A group is written as the API server sees it (with the OIDC groups prefix of the installation). |
| tenants.organizations.enabled | bool | `false` | Admit the agent workers of the Organizations' namespaces and turn on agent-manager's tenant reconciler. With components.agent-manager on, the agent-manager release gets `tenants.enabled` (agent-manager 2.1.0 or later), which puts a WorkerPool in each namespace labelled `giantswarm.io/organization` that holds an agent, with copies of the kagent namespace's default ModelConfig (`default-model-config`, its key Secret kagent.providers.<default>.apiKeySecretRef, which must be set in these values: the kagent chart's own provider defaults are not read) and of the workers' own policy (the CiliumNetworkPolicy `substrate-workers` in the cilium flavor, which needs cilium.io/v2 served or agent-manager does not start; the NetworkPolicy `substrate-workers-ingress` in the kubernetes flavor; none with networkPolicy.enabled off). Each tenant that holds an agent keeps 1 warm worker unless agent-manager.tenants.workerPoolReplicas sets another count. The render fails, naming the key, below agent-manager 2.1.0, with kagent off, with agent-manager's OAuth or downstream OAuth off, without kagent.fluxServiceAccountName or without that key Secret. agent-manager.tenants.workerPoolReplicas and .interval are yours; any other agent-manager.tenants key is derived and must be unset or equal. On, with Agent Substrate on, the connectivity release lets the worker pods of every such namespace reach the atenet router's tunnel, the egress gateway and the actors' dns, as the kagent namespace's workers do (both flavors), and the workers' Kyverno PolicyException covers them there when Substrate's controllers write them (ate-controller, the Deployment and ReplicaSet controllers); a labelled pod a person writes there is judged like any other. It needs Kyverno 1.15.2 or later: an older Kyverno matches the exception's namespaceSelector against no labels, so the exception never applies and the workers are refused. The namespaces are selected by the label, never listed; a namespace without the label gets nothing. Two ValidatingAdmissionPolicies hold the workers there for every requester, cluster-admin included: only agent-manager's ServiceAccount writes a WorkerPool, as a copy of the platform WorkerPool (kagent.substrateWorkerPool.name; only replicas may differ), and only Substrate's controllers write a Deployment, ReplicaSet or Pod labelled ate.dev/worker-pool; no one adds an ephemeral container to a worker, execs into one or attaches to one (docs/substrate-security.md). On, Substrate's credential provider also reads each such namespace's Secrets for the atespace of the same name, and for ate-golden, where every template's golden actor boots (substrate.credentialProvider.namespacePolicies). That ate-golden grant crosses tenants: while components.substrate.versionRange is below the release that carries agent-substrate/substrate#2543 (golden actors in their template's atespace), one atespace reads every Organization's Secrets, held back only by kagent naming the template's own namespace in its egress policy. Keep this off on customer installations and keep the switch itself until that floor moves; the re-pin that moves it also drops the ate-golden entry. On, a tenant also brings its own model key (giantswarm/agent-platform#759; README, "A tenant's own model"), and every model call of an Organization's namespace still goes through the `llm` listener, so the gateway meters it under the tenant. The connectivity release's modelconfig-llm-routing policies fill in the listener as the `spec.<provider>.baseUrl` of a ModelConfig there that has none, and two more ValidatingAdmissionPolicies hold every such namespace but kagent, for every requester: `agent-platform-tenant-model-routing` admits a ModelConfig only when the listener serves its provider (llmRouting.models) and its baseUrl is the listener (a Bedrock ModelConfig, any provider the listener does not serve, and a baseUrl that is not the listener are refused); `agent-platform-tenant-secret-creation` admits the creation of a Secret without the `tenant-credential-` prefix only for a requester who may already read that Secret (Helm, GitOps and the cluster's controllers keep writing as today). Only agent-manager's copy of `default-model-config` names the platform's key there. The render fails without llmRouting.enabled, with a default ModelConfig provider (kagent.providers.<default>.provider) the listener does not serve, and without the modelconfig-llm-routing policy (llmRouting.modelConfigPolicy.enabled). Point every ModelConfig already in an Organization namespace at the listener, or delete it, before you turn this on: later updates of one that is not are refused. On, with components.muster on, the muster release gets `muster.mcpServersInAllNamespaces: true` (giantswarm/muster#1601): muster serves the MCPServers of the namespaces named `org-…` next to its own, and lists them with the person's Dex token, so a person sees a server only where Kubernetes RBAC lets them list `mcpservers` (muster's namespace through tenants.platform.users). An own muster.muster.mcpServersInAllNamespaces against this switch fails the render. The render fails, naming the key, below muster 5.48.0, with muster's OAuth server off or not on the dex provider, and with tenants.platform.users empty. muster's muster.writesAsCaller.kubernetesAudience follows mcp-kubernetes.kubernetesAudience, the audience the API server trusts; an own value that differs fails the render. Before you turn this on: Dex lets muster's client ask for that audience, and each OAuth app of an Organization's MCP server registers `<muster's public URL>/oauth/ns/<namespace>/callback` (UPGRADE.md). Off, the default, nothing changes. |
| workspaces.enabled | bool | `false` |  |
| workspaces.storage.storageClassName | string | `"workspaces-rwx"` |  |
| workspaces.storage.storageClass.create | bool | `false` |  |
| workspaces.storage.storageClass.preset | string | `""` |  |
| workspaces.storage.storageClass.efs.fileSystemId | string | `""` |  |
| workspaces.storage.storageClass.efs.basePath | string | `"/workspaces"` |  |
| workspaces.storage.storageClass.efs.directoryPerms | string | `"700"` |  |
| workspaces.storage.storageClass.azureFiles.skuName | string | `"PremiumV2_LRS"` |  |
| workspaces.storage.storageClass.azureFiles.networkEndpointType | string | `"privateEndpoint"` |  |
| workspaces.storage.storageClass.nfs.server | string | `""` |  |
| workspaces.storage.storageClass.nfs.share | string | `"/"` |  |
| workspaces.storage.storageClass.parameters | object | `{}` |  |
| workspaces.storage.storageClass.mountOptions | list | `[]` |  |
| workspaces.substrate.csiDriver.name | string | `""` |  |
| workspaces.substrate.csiDriver.controllerEndpoint | string | `""` |  |
| workspaces.substrate.csiDriver.nodeSocketOverride | string | `""` |  |
| workspaces.substrate.csiDriver.tls.enabled | bool | `true` |  |
| workspaces.substrate.csiDriver.tls.usePodIdentity | bool | `true` |  |
| workspaces.substrate.csiDriver.tls.serverName | string | `""` |  |
| workspaces.substrate.csiCompanion.enabled | bool | `false` |  |
| workspaces.substrate.csiCompanion.preset | string | `""` |  |
| workspaces.substrate.csiCompanion.image.registry | string | `"gsoci.azurecr.io"` |  |
| workspaces.substrate.csiCompanion.image.repository | string | `""` |  |
| workspaces.substrate.csiCompanion.image.tag | string | `""` |  |
| workspaces.substrate.csiCompanion.controller.args | list | `[]` |  |
| workspaces.substrate.csiCompanion.controller.extraArgs | list | `[]` |  |
| workspaces.substrate.csiCompanion.controller.nodeSelector | object | `{}` |  |
| workspaces.substrate.csiCompanion.controller.tolerations | list | `[]` |  |
| workspaces.substrate.csiCompanion.controller.resources.requests.cpu | string | `"10m"` |  |
| workspaces.substrate.csiCompanion.controller.resources.requests.memory | string | `"64Mi"` |  |
| workspaces.substrate.csiCompanion.controller.resources.requests.ephemeral-storage | string | `"64Mi"` |  |
| workspaces.substrate.csiCompanion.controller.resources.limits.memory | string | `"256Mi"` |  |
| workspaces.substrate.csiCompanion.controller.resources.limits.ephemeral-storage | string | `"256Mi"` |  |
| workspaces.substrate.csiCompanion.proxy.image.registry | string | `"gsoci.azurecr.io"` |  |
| workspaces.substrate.csiCompanion.proxy.image.repository | string | `"giantswarm/envoy"` |  |
| workspaces.substrate.csiCompanion.proxy.image.tag | string | `"v1.40.2"` |  |
| workspaces.substrate.csiCompanion.proxy.port | int | `10000` |  |
| workspaces.substrate.csiCompanion.proxy.clientIdentity | string | `"spiffe://cluster.local/ns/ate-system/sa/ate-api-server"` |  |
| workspaces.substrate.csiCompanion.proxy.resources.requests.cpu | string | `"10m"` |  |
| workspaces.substrate.csiCompanion.proxy.resources.requests.memory | string | `"64Mi"` |  |
| workspaces.substrate.csiCompanion.proxy.resources.requests.ephemeral-storage | string | `"64Mi"` |  |
| workspaces.substrate.csiCompanion.proxy.resources.limits.memory | string | `"256Mi"` |  |
| workspaces.substrate.csiCompanion.proxy.resources.limits.ephemeral-storage | string | `"256Mi"` |  |
| workspaces.substrate.csiCompanion.service.port | int | `50051` |  |
| workspaces.substrate.csiCompanion.node.args | list | `[]` |  |
| workspaces.substrate.csiCompanion.node.extraArgs | list | `[]` |  |
| workspaces.substrate.csiCompanion.node.socketDir | string | `"/var/lib/kubelet/plugins/agent-platform-csi-companion"` |  |
| workspaces.substrate.csiCompanion.node.substrateDir | string | `"/var/lib/ate"` |  |
| workspaces.substrate.csiCompanion.node.nodeSelector | object | `{}` |  |
| workspaces.substrate.csiCompanion.node.tolerations | list | `[]` |  |
| workspaces.substrate.csiCompanion.node.efs.stateDir | string | `"/var/run/agent-platform-csi-companion/efs"` |  |
| workspaces.substrate.csiCompanion.node.efs.configDir | string | `"/var/lib/agent-platform-csi-companion/efs-utils"` |  |
| workspaces.substrate.csiCompanion.node.resources.requests.cpu | string | `"10m"` |  |
| workspaces.substrate.csiCompanion.node.resources.requests.memory | string | `"64Mi"` |  |
| workspaces.substrate.csiCompanion.node.resources.requests.ephemeral-storage | string | `"64Mi"` |  |
| workspaces.substrate.csiCompanion.node.resources.limits.memory | string | `"512Mi"` |  |
| workspaces.substrate.csiCompanion.node.resources.limits.ephemeral-storage | string | `"256Mi"` |  |
| workspaces.substrate.csiCompanion.livenessProbe.image.registry | string | `"gsoci.azurecr.io"` |  |
| workspaces.substrate.csiCompanion.livenessProbe.image.repository | string | `"giantswarm/livenessprobe"` |  |
| workspaces.substrate.csiCompanion.livenessProbe.image.tag | string | `"v2.20.0"` |  |
| workspaces.substrate.csiCompanion.livenessProbe.nodePort | int | `29662` |  |
| workspaces.substrate.csiCompanion.livenessProbe.resources.requests.cpu | string | `"5m"` |  |
| workspaces.substrate.csiCompanion.livenessProbe.resources.requests.memory | string | `"16Mi"` |  |
| workspaces.substrate.csiCompanion.livenessProbe.resources.requests.ephemeral-storage | string | `"16Mi"` |  |
| workspaces.substrate.csiCompanion.livenessProbe.resources.limits.memory | string | `"64Mi"` |  |
| workspaces.substrate.csiCompanion.livenessProbe.resources.limits.ephemeral-storage | string | `"64Mi"` |  |
| workspaces.substrate.csiCompanion.cloudIdentity.aws.roleARN | string | `""` |  |
| workspaces.substrate.csiCompanion.cloudIdentity.azure.workloadIdentityClientID | string | `""` |  |
| workspaces.organizations | list | `[]` |  |
| workspace-manager.fullnameOverride | string | `"workspace-manager"` |  |
| workspace-manager.observability.otel.endpoint | string | `"auto"` |  |
| workspace-manager.observability.otel.protocol | string | `"auto"` |  |
| workspace-manager.observability.otel.headers | string | `"auto"` |  |
| workspace-manager.oauth.enabled | bool | `true` |  |
| workspace-manager.oauth.baseURL | string | `""` |  |
| workspace-manager.oauth.dex.allowPrivateURLs | bool | `true` |  |
| workspace-manager.oauth.sso.allowPrivateIPs | bool | `true` |  |
| workspace-manager.muster.mcpServer.enabled | bool | `true` |  |
| workspace-manager.muster.mcpServer.auth.forwardToken | bool | `true` |  |
| workspace-manager.muster.mcpServer.auth.requiredAudiences[0] | string | `"dex-k8s-authenticator"` |  |
| workspace-manager.providers | list | `[]` |  |
| workspace-manager.grant.signingKey | object | `{}` |  |
| workspace-manager.sync.cycle | string | `""` |  |
| workspace-manager.sessions.cleanupAfter | string | `""` |  |
| workspace-manager.storage.sizing.factor | string | `""` |  |
| workspace-manager.storage.sizing.headroom | string | `""` |  |
| workspace-manager.storage.sizing.maxSize | string | `""` |  |
| workspace-manager.serviceMonitor.enabled | string | `"auto"` |  |
| workspace-manager.serviceMonitor.interval | string | `"60s"` |  |
| workspace-manager.serviceMonitor.labels."observability.giantswarm.io/tenant" | string | `"giantswarm"` |  |
| workspaceManager.route.enabled | bool | `true` |  |
| workspaceManager.route.parentRefs | list | `[]` |  |
| workspaceManager.grantKey.create | bool | `true` |  |
| workspaceManager.grantKey.secretName | string | `"workspace-manager-grant-keys"` |  |
| workspaceManager.grantKey.key | string | `"key-1"` |  |
| workspaceManager.networkPolicy.ingress.additionalPeers | list | `[]` |  |
| workspaceManager.networkPolicy.egress.fqdns | list | `[]` |  |
| workspaceManager.networkPolicy.egress.cidrs | list | `[]` |  |
| toolchain-manager.owners.groups | list | `[]` |  |
| toolchain-manager.owners.emails | list | `[]` |  |
| toolchain-manager.sources[0].repository | string | `"giantswarm/agent-toolchains"` |  |
| toolchain-manager.sources[0].registry | string | `"gsoci.azurecr.io/giantswarm/agent-toolchains"` |  |
| toolchain-manager.additionalSources | list | `[]` |  |
| toolchain-manager.registryPullSecret | string | `""` |  |
| toolchain-manager.github.appInstallURL | string | `""` |  |
| backstage.observability.otel.endpoint | string | `"auto"` |  |
| backstage.observability.otel.protocol | string | `"auto"` |  |
| backstage.observability.otel.headers | string | `"auto"` |  |
| backstage.hostname | string | `""` |  |
| backstage.parentRefs | list | `[]` |  |
| backstage.installationName | string | `"agent-platform"` |  |
| backstage.extraScopes[0] | string | `"federated:id"` |  |
| backstage.extraScopes[1] | string | `"audience:server:client_id:dex-k8s-authenticator"` |  |
| backstage.startUrlSearchParams | object | `{}` |  |
| backstage.enabledExtensions | list | `[]` |  |
| backstage.disabledExtensions[0] | string | `"page:gs/clusters"` |  |
| backstage.disabledExtensions[1] | string | `"nav-item:gs/clusters"` |  |
| backstage.disabledExtensions[2] | string | `"page:gs/deployments"` |  |
| backstage.disabledExtensions[3] | string | `"nav-item:gs/deployments"` |  |
| backstage.disabledExtensions[4] | string | `"page:gs/installations"` |  |
| backstage.disabledExtensions[5] | string | `"nav-item:gs/installations"` |  |
| backstage.disabledExtensions[6] | string | `"page:flux"` |  |
| backstage.disabledExtensions[7] | string | `"nav-item:flux"` |  |
| backstage.disabledExtensions[8] | string | `"page:ai-chat"` |  |
| backstage.disabledExtensions[9] | string | `"api:ai-chat/service"` |  |
| backstage.disabledExtensions[10] | string | `"api:ai-chat/drawer"` |  |
| backstage.disabledExtensions[11] | string | `"app-root-element:ai-chat/drawer"` |  |
| backstage.skillsRepositories[0] | string | `"https://github.com/giantswarm/agent-skills"` |  |
| backstage.configReload.enabled | bool | `true` |  |
| backstage.configReload.image.registry | string | `"gsoci.azurecr.io"` |  |
| backstage.configReload.image.name | string | `"giantswarm/kubectl"` |  |
| backstage.configReload.image.version | string | `"v1.37.1"` |  |
| backstage.ingress.enabled | bool | `false` |  |
| backstage.resources.verticalPodAutoscaler.enabled | bool | `false` |  |
| backstage.backstage.args[0] | string | `"--config"` |  |
| backstage.backstage.args[1] | string | `"app-config.yaml"` |  |
| backstage.backstage.args[2] | string | `"--config"` |  |
| backstage.backstage.args[3] | string | `"app-config.production.yaml"` |  |
| backstage.backstage.extraAppConfig[0].filename | string | `"app-config.agent-platform.yaml"` |  |
| backstage.backstage.extraAppConfig[0].configMapRef | string | `"agent-platform-backstage-app-config"` |  |
| backstage.backstage.extraEnvVars[0].name | string | `"AUTH_SESSION_SECRET"` |  |
| backstage.backstage.extraEnvVars[0].valueFrom.secretKeyRef.name | string | `"{{ .Values.global.identity.existingSecret }}"` |  |
| backstage.backstage.extraEnvVars[0].valueFrom.secretKeyRef.key | string | `"backstage-session-secret"` |  |
| backstage.backstage.extraEnvVars[1].name | string | `"AGENT_PLATFORM_OIDC_CLIENT_SECRET"` |  |
| backstage.backstage.extraEnvVars[1].valueFrom.secretKeyRef.name | string | `"{{ .Values.global.identity.existingSecret }}"` |  |
| backstage.backstage.extraEnvVars[1].valueFrom.secretKeyRef.key | string | `"dex-client-secret"` |  |
| backstage.backstage.extraEnvVars[2].name | string | `"NODE_EXTRA_CA_CERTS"` |  |
| backstage.backstage.extraEnvVars[2].value | string | `"{{ with (dig \"identity\" \"ca\" \"secretName\" \"\" .Values.global) }}/etc/agent-platform/idp-ca/{{ dig \"identity\" \"ca\" \"key\" \"ca.crt\" $.Values.global }}{{ end }}"` |  |
| backstage.backstage.extraVolumes[0].name | string | `"idp-ca"` |  |
| backstage.backstage.extraVolumes[0].secret.secretName | string | `"{{ dig \"identity\" \"ca\" \"secretName\" \"\" .Values.global | default \"agent-platform-idp-ca\" }}"` |  |
| backstage.backstage.extraVolumes[0].secret.optional | bool | `true` |  |
| backstage.backstage.extraVolumeMounts[0].name | string | `"idp-ca"` |  |
| backstage.backstage.extraVolumeMounts[0].mountPath | string | `"/etc/agent-platform/idp-ca"` |  |
| backstage.backstage.extraVolumeMounts[0].readOnly | bool | `true` |  |
| mcp-kubernetes.fullnameOverride | string | `"mcp-kubernetes"` |  |
| mcp-kubernetes.mcpKubernetes.instrumentation.tracingExporter | string | `"auto"` |  |
| mcp-kubernetes.mcpKubernetes.instrumentation.otlpEndpoint | string | `"auto"` |  |
| mcp-kubernetes.mcpKubernetes.instrumentation.otlpInsecure | string | `"auto"` |  |
| mcp-kubernetes.mcpKubernetes.instrumentation.otlpProtocol | string | `"auto"` |  |
| mcp-kubernetes.mcpKubernetes.instrumentation.otlpHeaders | string | `"auto"` |  |
| mcp-kubernetes.mcpKubernetes.instrumentation.serviceMonitor.enabled | string | `"auto"` |  |
| mcp-kubernetes.mcpKubernetes.instrumentation.serviceMonitor.labels."observability.giantswarm.io/tenant" | string | `"giantswarm"` |  |
| mcp-kubernetes.mcpKubernetes.oauth.enabled | bool | `true` |  |
| mcp-kubernetes.mcpKubernetes.oauth.provider | string | `"dex"` |  |
| mcp-kubernetes.mcpKubernetes.oauth.allowPrivateURLs | bool | `true` |  |
| mcp-kubernetes.mcpKubernetes.oauth.sso.allowPrivateIPs | bool | `true` |  |
| mcp-kubernetes.mcpKubernetes.oauth.enableDownstreamOAuth | bool | `true` |  |
| mcp-kubernetes.grafanaDashboards.enabled | string | `"auto"` |  |
| mcp-kubernetes.grafanaDashboards.folder | string | `"Agent Platform"` |  |
| mcp-kubernetes.grafanaDashboards.giantswarm.enabled | bool | `true` |  |
| mcp-kubernetes.grafanaDashboards.giantswarm.organization | string | `"Shared Org"` |  |
| mcp-kubernetes.kubernetesAudience | string | `"dex-k8s-authenticator"` |  |
| cloudnative-pg.image.repository | string | `"gsoci.azurecr.io/giantswarm/cloudnative-pg"` |  |
| kagent-crds.kmcp.enabled | bool | `false` |  |
| kagent-crds.substrate.enabled | bool | `false` |  |
| substrate.createNamespace | bool | `false` |  |
| substrate.image.registry | string | `"gsoci.azurecr.io"` |  |
| substrate.image.repository | string | `"giantswarm/substrate"` |  |
| substrate.metrics.podMonitor.enabled | string | `"auto"` |  |
| substrate.metrics.podMonitor.labels."observability.giantswarm.io/tenant" | string | `"giantswarm"` |  |
| substrate.ateController.busyWorker.annotations."karpenter.sh/do-not-disrupt" | string | `"true"` |  |
| substrate.credentialProvider.namespacePolicies[0].atespace | string | `"kagent"` |  |
| substrate.credentialProvider.namespacePolicies[0].allowedNamespaces[0] | string | `"kagent"` |  |
| substrate.credentialProvider.namespacePolicies[1].atespace | string | `"ate-golden"` |  |
| substrate.credentialProvider.namespacePolicies[1].allowedNamespaces[0] | string | `"kagent"` |  |
| substrate.credentialProvider.additionalProviders[0].uriAuthority | string | `"muster.giantswarm.io"` |  |
| substrate.credentialProvider.additionalProviders[0].host | string | `"muster.agent-platform.svc:50051"` |  |
| substrate.credentialProvider.additionalProviders[1].uriAuthority | string | `"google-access-token.k8s.io"` |  |
| substrate.credentialProvider.additionalProviders[1].host | string | `"google-access-token-credential-provider.ate-system.svc:50051"` |  |
| substrate.postgres.enabled | string | `"auto"` |  |
| substrate.postgres.readWriteConnectionString | string | `""` |  |
| substrate.postgres.schema | string | `"public"` |  |
| substrate.rustfs.enabled | bool | `false` |  |
| substrate.otel.endpoint | string | `"auto"` |  |
| substrate.otel.metrics.enabled | bool | `false` |  |
| substrate.podLabels."observability.giantswarm.io/tenant" | string | `"auto"` |  |
| substrate.images.postgres | string | `"gsoci.azurecr.io/giantswarm/postgres:18.4-alpine@sha256:9a8afca54e7861fd90fab5fdf4c42477a6b1cb7d293595148e674e0a3181de15"` |  |
| substrate.images.rustfs | string | `"gsoci.azurecr.io/giantswarm/rustfs:1.0.0-beta.3@sha256:378642b05b7dcb4849fb77ebe6aca4ced1c3f66e7e504247df95a5c9018d3358"` |  |
| substrate.images.awsCli | string | `"gsoci.azurecr.io/giantswarm/aws-cli:2.17.0@sha256:643507c10ada7964ca6157b3d799f030b90577643da9955d319a77399ed80d73"` |  |
| substrate.images.pause | string | `"gsoci.azurecr.io/giantswarm/pause:3.10.2@sha256:f548e0e8e3dc1896ca956272154dde3314e8cc4fde0a57577ee9fa1c63f5baf4"` |  |
| substrate.atenetEgress.resources.requests.ephemeral-storage | string | `"16Mi"` |  |
| substrate.atenetEgress.resources.limits.ephemeral-storage | string | `"256Mi"` |  |
| substrate.atenetEgress.extProc.resources.requests.ephemeral-storage | string | `"16Mi"` |  |
| substrate.atenetEgress.extProc.resources.limits.ephemeral-storage | string | `"256Mi"` |  |
| substrate.atenetEgress.drainSignal.sizeLimit | string | `"16Mi"` |  |
| substrate.atelet.storageBackend | string | `"s3"` |  |
| substrate.atelet.nodeSelector | object | `{}` |  |
| substrate.atelet.tolerations | list | `[]` |  |
| substrate.atelet.affinity | object | `{}` |  |
| substrate.atelet.priorityClass.preemptionPolicy | string | `"PreemptLowerPriority"` |  |
| substrate.atelet.resources.requests.cpu | string | `"50m"` |  |
| substrate.atelet.resources.requests.memory | string | `"128Mi"` |  |
| substrate.atelet.resources.limits.cpu | string | `"2"` |  |
| substrate.atelet.resources.limits.memory | string | `"1Gi"` |  |
| substrate.atelet.extraEnv | list | `[]` |  |
| substrate.atelet.imageCache.pinnedImages | list | `[]` |  |
| substrate-crds | object | `{}` |  |
| google-access-token-credential-provider.namespacePolicies | list | `[]` |  |
| hooks.kubectlImage.registry | string | `"gsoci.azurecr.io"` |  |
| hooks.kubectlImage.repository | string | `"giantswarm/alpine-k8s"` |  |
| hooks.kubectlImage.tag | string | `"1.37.1"` |  |
| hooks.opensslImage.registry | string | `"gsoci.azurecr.io"` |  |
| hooks.opensslImage.repository | string | `"giantswarm/alpine-openssl"` |  |
| hooks.opensslImage.tag | string | `"3.5.9"` |  |
| kserve-llmisvc-crd | object | `{}` |  |
| kserve-llmisvc-resources.kserve.createSharedResources | bool | `true` |  |
| kserve-llmisvc-resources.kserve.controller.deploymentMode | string | `"Standard"` |  |
| kserve-llmisvc-resources.kserve.controller.gateway.disableIngressCreation | bool | `true` |  |
| kserve-llmisvc-resources.kserve.llmisvc.createGIECRDs | bool | `true` |  |
| kserve-llmisvc-resources.kserve.llmisvc.controller.metricsSecure | bool | `false` |  |
| kserve-llmisvc-resources.kserve.llmisvc.controller.serviceMonitor.enabled | string | `"auto"` |  |
| kserve-llmisvc-resources.kserve.llmisvc.controller.serviceMonitor.interval | string | `"60s"` |  |
| kserve-llmisvc-resources.kserve.llmisvc.controller.serviceMonitor.labels."observability.giantswarm.io/tenant" | string | `"giantswarm"` |  |
| kserve-runtime-configs.kserve.llmisvcConfigs.enabled | bool | `true` |  |
| kserve-runtime-configs.kserve.llmisvcConfigs.imageRegistry | string | `"gsoci.azurecr.io/giantswarm/llm-d-fast/"` |  |
| kserve-runtime-configs.kserve.llmisvcConfigs.images.kserve-config-llm-template.main | string | `"gsoci.azurecr.io/giantswarm/llm-d-fast/llm-d-cuda:v0.8.0"` |  |
| kserve-runtime-configs.kserve.llmisvcConfigs.images.kserve-config-llm-worker-data-parallel.main | string | `"gsoci.azurecr.io/giantswarm/llm-d-fast/llm-d-cuda:v0.8.0"` |  |
| kserve-runtime-configs.kserve.llmisvcConfigs.images.kserve-config-llm-decode-template.main | string | `"gsoci.azurecr.io/giantswarm/llm-d-fast/llm-d-cuda:v0.8.0"` |  |
| kserve-runtime-configs.kserve.llmisvcConfigs.images.kserve-config-llm-decode-worker-data-parallel.main | string | `"gsoci.azurecr.io/giantswarm/llm-d-fast/llm-d-cuda:v0.8.0"` |  |
| kserve-runtime-configs.kserve.llmisvcConfigs.images.kserve-config-llm-prefill-template.main | string | `"gsoci.azurecr.io/giantswarm/llm-d-fast/llm-d-cuda:v0.8.0"` |  |
| kserve-runtime-configs.kserve.llmisvcConfigs.images.kserve-config-llm-prefill-worker-data-parallel.main | string | `"gsoci.azurecr.io/giantswarm/llm-d-fast/llm-d-cuda:v0.8.0"` |  |
| kserve-runtime-configs.kserve.llmisvcConfigs.tracing.exporterEndpoint | string | `"auto"` |  |
| kserve-runtime-configs.kserve.llmisvcConfigs.tracing.podLabels."observability.giantswarm.io/tenant" | string | `"auto"` |  |
| kserve-runtime-configs.kserve.llmisvcConfigs.rolloutStrategy.maxSurge | int | `0` |  |
| kserve-runtime-configs.kserve.llmisvcConfigs.rolloutStrategy.maxUnavailable | int | `1` |  |
| kserve-runtime-configs.kserve.servingruntime.enabled | bool | `false` |  |
| gpu-operator.driver.enabled | bool | `false` |  |
| gpu-operator.toolkit.enabled | bool | `false` |  |
| gpu-operator.dcgmExporter.serviceMonitor.additionalLabels."observability.giantswarm.io/tenant" | string | `"giantswarm"` |  |
| modelServing.kserve.requireApi | bool | `true` | api-versions serving.kserve.io/v1alpha2; false skips it. |
| modelServing.namespace.name | string | `"model-serving"` |  |
| modelServing.namespace.create | bool | `true` |  |
| modelServing.namespace.keep | bool | `true` |  |
| modelServing.namespace.labels | object | `{}` |  |
| modelServing.serving.gpuResourceName | string | `"nvidia.com/gpu"` |  |
| modelServing.serving.runtimeClassName | string | `""` |  |
| modelServing.serving.nodeSelector | object | `{}` |  |
| modelServing.serving.shmSizeLimit | string | `"8Gi"` |  |
| modelServing.serving.modelCacheSizeLimit | string | `"100Gi"` |  |
| modelServing.serving.emptyDirSizeLimit | string | `"1Gi"` |  |
| modelServing.gpuPool.taint.key | string | `"nvidia.com/gpu"` |  |
| modelServing.gpuPool.taint.value | string | `""` |  |
| modelServing.gpuPool.taint.effect | string | `"NoSchedule"` |  |
| modelServing.gpuPool.nodeSelector | object | `{}` |  |
| modelServing.fastLinks | list | `[]` |  |
| modelServing.prepull.enabled | bool | `true` |  |
| modelServing.prepull.images[0] | string | `"gsoci.azurecr.io/giantswarm/storage-initializer:v0.21.0"` |  |
| modelServing.prepull.images[1] | string | `"gsoci.azurecr.io/giantswarm/llm-d-fast/llm-d-cuda:v0.8.0"` |  |
| modelServing.prepull.nodeSelector | object | `{}` |  |
| modelServing.prepull.gpuReadyLabel | string | `"nvidia.com/gpu.count"` |  |
| modelServing.prepull.tolerations[0].operator | string | `"Exists"` |  |
| modelServing.prepull.pauseImage.registry | string | `"gsoci.azurecr.io"` |  |
| modelServing.prepull.pauseImage.repository | string | `"giantswarm/pause"` |  |
| modelServing.prepull.pauseImage.tag | string | `"3.10.2"` |  |
| modelServing.prepull.resources.requests.cpu | string | `"5m"` |  |
| modelServing.prepull.resources.requests.memory | string | `"8Mi"` |  |
| modelServing.prepull.resources.limits.memory | string | `"32Mi"` |  |
| modelServing.prepull.modelPresets | list | `[]` |  |
| modelServing.presets | list | `[]` |  |
| modelServing.shippedPresets.enabled | bool | `true` |  |
| modelServing.shippedPresets.exclude | list | `[]` |  |
| modelServing.modelImages.registry | string | `""` |  |
| modelServing.cache.enabled | bool | `true` |  |
| modelServing.cache.pvc.name | string | `"hf-cache"` |  |
| modelServing.cache.pvc.existingClaim | string | `""` |  |
| modelServing.cache.pvc.size | string | `"100Gi"` |  |
| modelServing.cache.pvc.storageClassName | string | `""` |  |
| modelServing.cache.pvc.volumeName | string | `""` |  |
| modelServing.cache.pvc.accessModes[0] | string | `"ReadWriteOnce"` |  |
| modelServing.cache.storageClass.create | bool | `true` |  |
| modelServing.cache.storageClass.name | string | `""` |  |
| modelServing.cache.storageClass.provisioner | string | `"ebs.csi.aws.com"` |  |
| modelServing.cache.storageClass.parameters.type | string | `"gp3"` |  |
| modelServing.cache.storageClass.parameters.iops | string | `"3000"` |  |
| modelServing.cache.storageClass.parameters.throughput | string | `"500"` |  |
| modelServing.cache.fsGroup | int | `1000` |  |
| modelServing.policies.enabled | string | `"auto"` |  |
| modelServing.policies.storageInitializerMemoryLimit | string | `"8Gi"` |  |
| modelServing.policies.progressDeadlineSeconds | int | `3600` |  |
| modelServing.policies.env[0].name | string | `"HF_HUB_DISABLE_XET"` |  |
| modelServing.policies.env[0].value | string | `"1"` |  |
| modelServing.imageVerification.enabled | bool | `true` |  |
| modelServing.imageVerification.images[0] | string | `"gsoci.azurecr.io/giantswarm/*"` |  |
| modelServing.imageVerification.attestors[0].keyless.issuer | string | `"https://oidc.circleci.com"` |  |
| modelServing.imageVerification.attestors[0].keyless.subjectRegExp | string | `"^https://circleci\\.com/api/v2/projects/[a-f0-9-]+/pipeline-definitions/([a-f0-9-]+|nil)$"` |  |
| modelServing.imageVerification.attestors[0].keyless.rekor.url | string | `"https://rekor.sigstore.dev"` |  |
| modelServing.imageVerification.type | string | `"SigstoreBundle"` |  |
| modelServing.imageVerification.mutateDigest | bool | `true` |  |
| modelServing.imageVerification.required | bool | `true` |  |
| modelServing.imageVerification.failureAction | string | `"Enforce"` |  |
| modelServing.imageVerification.kyvernoEgress.enabled | bool | `true` |  |
| modelServing.imageVerification.kyvernoEgress.namespace | string | `"kyverno"` |  |
| modelServing.imageVerification.kyvernoEgress.podSelector | object | `{}` |  |
| modelServing.imageVerification.kyvernoEgress.hosts[0].matchName | string | `"gsoci.azurecr.io"` |  |
| modelServing.imageVerification.kyvernoEgress.hosts[1].matchPattern | string | `"*.blob.core.windows.net"` |  |
| modelServing.imageVerification.kyvernoEgress.hosts[2].matchName | string | `"tuf-repo-cdn.sigstore.dev"` |  |
| modelServing.imageVerification.kyvernoEgress.hosts[3].matchName | string | `"rekor.sigstore.dev"` |  |
| modelServing.networkPolicy.llmisvcWorkload.port | int | `8000` |  |
| modelServing.networkPolicy.additionalIngressNamespaces | list | `[]` |  |
| modelServing.networkPolicy.otlpEndpoint | string | `"auto"` |  |
| modelServing.networkPolicy.huggingFace.fqdns[0].matchName | string | `"huggingface.co"` |  |
| modelServing.networkPolicy.huggingFace.fqdns[1].matchPattern | string | `"*.huggingface.co"` |  |
| modelServing.networkPolicy.huggingFace.fqdns[2].matchPattern | string | `"*.hf.co"` |  |
| modelServing.networkPolicy.huggingFace.fqdns[3].matchPattern | string | `"*.*.hf.co"` |  |
| modelServing.networkPolicy.huggingFace.fqdns[4].matchPattern | string | `"*.*.*.hf.co"` |  |
| modelServing.networkPolicy.huggingFace.cidrs | list | `[]` |  |
| modelServing.modelsGateway.enabled | bool | `false` |  |
| modelServing.modelsGateway.name | string | `"models"` |  |
| modelServing.modelsGateway.hostPrefix | string | `"models"` |  |
| modelServing.modelsGateway.gatewayClassName | string | `""` |  |
| modelServing.modelsGateway.tls.secretName | string | `""` |  |
| modelServing.modelsGateway.tls.issuerRef.name | string | `""` |  |
| modelServing.modelsGateway.tls.issuerRef.kind | string | `"ClusterIssuer"` |  |
| modelServing.modelsGateway.tls.issuerRef.group | string | `"cert-manager.io"` |  |
| modelServing.modelsGateway.service.annotations."service.beta.kubernetes.io/aws-load-balancer-scheme" | string | `"internet-facing"` |  |
| modelServing.modelsGateway.externalDns.enabled | bool | `true` |  |
| modelServing.modelsGateway.jwtAuthentication.mode | string | `"Strict"` |  |
| modelServing.modelsGateway.jwtAuthentication.issuer | string | `""` |  |
| modelServing.modelsGateway.jwtAuthentication.audiences[0] | string | `"dex-k8s-authenticator"` |  |
| modelServing.modelsGateway.jwtAuthentication.jwks.host | string | `""` |  |
| modelServing.modelsGateway.jwtAuthentication.jwks.port | int | `443` |  |
| modelServing.modelsGateway.jwtAuthentication.jwks.path | string | `"/keys"` |  |
| modelServing.modelsGateway.jwtAuthentication.jwks.tls.enabled | bool | `false` |  |
| modelServing.modelsGateway.jwtAuthentication.jwks.tls.caSecretName | string | `""` |  |
