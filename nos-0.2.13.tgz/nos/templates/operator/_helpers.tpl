{{/*
Expand the name of the chart.
*/}}
{{- define "operator.name" -}}
{{- default (printf "%s-%s" .Chart.Name "operator") .Values.operator.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "operator.fullname" -}}
{{- if .Values.operator.fullnameOverride }}
{{- .Values.operator.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name "operator" | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label. A label value is at
most 63 characters and begins and ends alphanumeric: the cut of a long version
(a branch build's <version>-dev.<branch>.<date>.<time>.<sha>, or the
<version>+<digest> helm-controller installs) can land on any run of ".", "_"
(from "+") and "-", so the whole run is trimmed.
*/}}
{{- define "operator.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimAll "-._" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "operator.labels" -}}
helm.sh/chart: {{ include "operator.chart" . }}
{{ include "operator.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: nos
app.kubernetes.io/component: operator
{{- end }}

{{/*
Selector labels
*/}}
{{- define "operator.selectorLabels" -}}
app.kubernetes.io/name: {{ include "operator.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the operator config ConfigMap
*/}}
{{- define "operator.config.configMapName" -}}
{{- include "operator.fullname" . }}-config
{{- end }}

{{/*
Create the name of the file storing the scheduler config
*/}}
{{- define "operator.schedulerConfigFileName" -}}
scheduler_config.yaml
{{- end }}

{{/*
Create the name of the file storing the Operator configuration
*/}}
{{- define "operator.configFileName" -}}
operator_config.yaml
{{- end }}

{{/*
Create the name of the secret containing the cert of the webhook used for validating CRDs
*/}}
{{- define "operator.webhookCertSecretName" -}}
{{ include "operator.fullname" . }}-webhook-server-cert
{{- end }}

{{/*
Create the name of the service pointing to the operator webhook server
*/}}
{{- define "operator.webhookServiceName" -}}
{{ include "operator.fullname" . }}-webhook
{{- end }}

{{/*
Create the name of the controller manager leader election role
*/}}
{{- define "operator.leaderElectionRoleName" -}}
{{ include "operator.fullname" . }}-leader-election
{{- end }}

{{/*
Create the name of the controller manager auth proxy role
*/}}
{{- define "operator.authProxyRoleName" -}}
{{ include "operator.fullname" . }}-auth-proxy
{{- end }}

{{/*
Create the name of the controller manager metrics reader role
*/}}
{{- define "operator.metricsReaderRoleName" -}}
{{ include "operator.fullname" . }}-metrics-reader
{{- end }}
