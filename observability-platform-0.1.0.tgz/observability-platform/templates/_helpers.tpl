{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "name" -}}
{{- .Chart.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimAll "-._" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "labels.common" -}}
app: {{ include "name" . | quote }}
{{ include "labels.selector" . }}
app.kubernetes.io/managed-by: {{ .Release.Service | quote }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
application.giantswarm.io/team: {{ index .Chart.Annotations "io.giantswarm.application.team" | quote }}
helm.sh/chart: {{ include "chart" . | quote }}
{{- end -}}

{{/*
Selector labels
*/}}
{{- define "labels.selector" -}}
app.kubernetes.io/name: {{ include "name" . | quote }}
app.kubernetes.io/instance: {{ .Release.Name | quote }}
{{- end -}}

{{/*
Object storage validation.
*/}}
{{- define "observability-platform.objectStorage.validate" -}}
{{- $os := .Values.global.objectStorage -}}
{{- $backend := $os.backend | default "" -}}
{{- if not (has $backend (list "azure" "s3")) -}}
{{- fail (printf "global.objectStorage.backend is %q. Set it to \"azure\" or \"s3\" - see docs/OBJECT_STORAGE.md." $backend) -}}
{{- end -}}
{{- if eq $backend "s3" -}}
{{- if and (not (include "observability-platform.localObjectStorage.garage.enabled" .)) (not ($os.s3 | default dict).endpoint) -}}
{{- fail "global.objectStorage.backend is \"s3\" and global.objectStorage.s3.endpoint is empty. Set it to the store endpoint, host[:port] without a scheme - see docs/OBJECT_STORAGE.md." -}}
{{- end -}}
{{- end -}}
{{- if eq $backend "azure" -}}
{{- $azure := $os.azure -}}
{{- $azurite := include "observability-platform.localObjectStorage.azurite.enabled" . -}}
{{- if and (not $azurite) (not (or $azure.accountName $azure.connectionString)) -}}
{{- fail "global.objectStorage.azure.accountName is empty. Set it to the Azure storage account holding the containers, or set global.objectStorage.azure.connectionString to reach an endpoint of your own, or set localObjectStorage.enabled to run against a local Azurite emulator - see docs/OBJECT_STORAGE.md." -}}
{{- end -}}
{{- if and .Values.tempo.enabled $azure.connectionString (not $azurite) -}}
{{- fail "tempo.enabled is true and global.objectStorage.azure.connectionString is set. Tempo reads no connection string: it needs global.objectStorage.azure.accountName and the account key in the credentials Secret. Set accountName instead of connectionString, or set tempo.enabled to false - see docs/OBJECT_STORAGE.md." -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Azurite switch. `true` when localObjectStorage.enabled is set, the backend is `azure`
and Mimir, Loki or Tempo is enabled. Empty otherwise, so templates test it with `if`.
*/}}
{{- define "observability-platform.localObjectStorage.azurite.enabled" -}}
{{- if and .Values.localObjectStorage.enabled (eq (.Values.global.objectStorage.backend | default "") "azure") (or .Values.mimir.enabled .Values.loki.enabled .Values.tempo.enabled) -}}
true
{{- end -}}
{{- end -}}

{{/*
Garage switch. `true` when localObjectStorage.enabled is set, the backend is `s3`
and Mimir, Loki or Tempo is enabled. Empty otherwise, so templates test it with `if`.
*/}}
{{- define "observability-platform.localObjectStorage.garage.enabled" -}}
{{- if and .Values.localObjectStorage.enabled (eq (.Values.global.objectStorage.backend | default "") "s3") (or .Values.mimir.enabled .Values.loki.enabled .Values.tempo.enabled) -}}
true
{{- end -}}
{{- end -}}

{{/*
Storage account name delivered to Mimir, Loki and Tempo. Empty with backend `s3`.
*/}}
{{- define "observability-platform.objectStorage.accountName" -}}
{{- if include "observability-platform.localObjectStorage.azurite.enabled" . -}}
{{- include "observability-platform.azurite.accountName" . -}}
{{- else if eq .Values.global.objectStorage.backend "azure" -}}
{{- .Values.global.objectStorage.azure.accountName -}}
{{- end -}}
{{- end -}}

{{/*
Connection string delivered to Mimir and Loki. Empty with backend `s3`.
*/}}
{{- define "observability-platform.objectStorage.connectionString" -}}
{{- if include "observability-platform.localObjectStorage.azurite.enabled" . -}}
{{- $account := include "observability-platform.azurite.accountName" . -}}
{{- printf "DefaultEndpointsProtocol=http;AccountName=%s;AccountKey=%s;BlobEndpoint=http://%s/%s;" $account (include "observability-platform.azurite.accountKey" .) (include "observability-platform.azurite.host" .) $account -}}
{{- else if eq .Values.global.objectStorage.backend "azure" -}}
{{- .Values.global.objectStorage.azure.connectionString -}}
{{- end -}}
{{- end -}}

{{/*
Azure Blob endpoint suffix delivered to Tempo. Tempo switches to Azurite path style
when the suffix does not start with `blob.`.
*/}}
{{- define "observability-platform.objectStorage.endpointSuffix" -}}
{{- if include "observability-platform.localObjectStorage.azurite.enabled" . -}}
{{- include "observability-platform.azurite.host" . -}}
{{- else -}}
blob.core.windows.net
{{- end -}}
{{- end -}}

{{/*
S3 endpoint delivered to Mimir and Tempo. The Garage host under Garage. Empty with
backend `azure`.
*/}}
{{- define "observability-platform.objectStorage.s3.endpoint" -}}
{{- if include "observability-platform.localObjectStorage.garage.enabled" . -}}
{{- include "observability-platform.garage.host" . -}}
{{- else if eq .Values.global.objectStorage.backend "s3" -}}
{{- .Values.global.objectStorage.s3.endpoint -}}
{{- end -}}
{{- end -}}

{{/*
S3 region delivered to Mimir and Tempo. The Garage region under Garage. Empty with
backend `azure`.
*/}}
{{- define "observability-platform.objectStorage.s3.region" -}}
{{- if include "observability-platform.localObjectStorage.garage.enabled" . -}}
{{- include "observability-platform.garage.region" . -}}
{{- else if eq .Values.global.objectStorage.backend "s3" -}}
{{- .Values.global.objectStorage.s3.region -}}
{{- end -}}
{{- end -}}

{{/*
S3 plain-HTTP switch delivered to Mimir and Tempo. Always `true` or `false`.
`true` under Garage. `false` with backend `azure`.
*/}}
{{- define "observability-platform.objectStorage.s3.insecure" -}}
{{- if include "observability-platform.localObjectStorage.garage.enabled" . -}}
true
{{- else if and (eq .Values.global.objectStorage.backend "s3") .Values.global.objectStorage.s3.insecure -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}
