# gitlab

GitLab CE in one Omnibus container on the installation's PostgreSQL, Valkey and object storage, a small GitLab instance for testing integrations.

**Homepage:** <https://github.com/giantswarm/gitlab>

## Source Code

* <https://gitlab.com/gitlab-org/omnibus-gitlab>
* <https://hub.docker.com/r/gitlab/gitlab-ce>

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| registry.domain | string | `"gsoci.azurecr.io"` | Registry the image is pulled from. |
| image.name | string | `"giantswarm/gitlab-ce"` | Image repository in the registry, the mirror of `gitlab/gitlab-ce`. |
| image.tag | string | `""` | Image tag; empty means the chart's appVersion. |
| image.pullPolicy | string | `"IfNotPresent"` | Image pull policy. |
| replicas | int | `1` | Number of GitLab pods: 1, or 0 to stop the instance and keep its volume. Omnibus is a single instance. |
| externalUrl | string | `"https://gitlab.example.com"` | The URL GitLab is reached at, with scheme (the hostname of the HTTPRoute or Ingress). TLS is terminated in front of the pod, so an `https://` URL serves plain HTTP in the pod and generates `https://` links. |
| rootPassword.existingSecret | string | `"gitlab-root-password"` | Name of an existing Secret holding the initial root password; the installer creates it. The password is only read when the instance is set up for the first time. The pod waits until the Secret exists. |
| rootPassword.key | string | `"password"` | Key of the password in that Secret. |
| postgresql.host | string | `""` | Host of the PostgreSQL primary, e.g. the `<cluster>-rw` Service of a CloudNativePG Cluster. Required. |
| postgresql.port | int | `5432` | Port of the PostgreSQL primary. |
| postgresql.database | string | `"gitlabhq_production"` | Database GitLab owns. Its owner creates the `pg_trgm` and `btree_gist` extensions on first start. |
| postgresql.username | string | `"gitlab"` | Role GitLab connects as, the database's owner. |
| postgresql.sslMode | string | `"prefer"` | libpq `sslmode` of the connection: disable, prefer, require, verify-ca or verify-full. |
| postgresql.existingSecret | string | `"gitlab-db-app"` | Name of the Secret holding the role's password, e.g. CloudNativePG's `<cluster>-app` Secret. |
| postgresql.key | string | `"password"` | Key of the password in that Secret. |
| redis.host | string | `""` | Host of the Redis-compatible server (Valkey). Required. |
| redis.port | int | `6379` | Port of the server. |
| redis.existingSecret | string | `"gitlab-valkey-auth"` | Name of the Secret holding the password of the server's default user. |
| redis.key | string | `"default"` | Key of the password in that Secret. |
| objectStorage.endpoint | string | `""` | S3 endpoint URL, e.g. an in-cluster Garage or MinIO Service. Required. GitLab proxies every download, so the endpoint needs no route from outside the cluster. |
| objectStorage.region | string | `"garage"` | Region of the endpoint. |
| objectStorage.pathStyle | bool | `true` | Address buckets in the path (`<endpoint>/<bucket>`) instead of the host name. |
| objectStorage.accessKeyId | string | `""` | S3 access key id. Required. Not a secret on its own; the secret key is read from `existingSecret`. |
| objectStorage.existingSecret | string | `"gitlab-object-storage"` | Name of the Secret holding the S3 secret access key. |
| objectStorage.secretKeyKey | string | `"secretKey"` | Key of the secret access key in that Secret. |
| objectStorage.buckets | object | `{"artifacts":"gitlab-artifacts","ci_catalog_bundles":"gitlab-ci-catalog-bundles","ci_secure_files":"gitlab-ci-secure-files","dependency_proxy":"gitlab-dependency-proxy","external_diffs":"gitlab-external-diffs","lfs":"gitlab-lfs","packages":"gitlab-packages","terraform_state":"gitlab-terraform-state","uploads":"gitlab-uploads"}` | Bucket of each object type; the chart creates them (`objectStorage.createBuckets`). Every type is stored in object storage; GitLab Pages is off. |
| objectStorage.createBuckets.enabled | bool | `true` | Create every bucket of `objectStorage.buckets` before GitLab is installed or upgraded: a pre-install and pre-upgrade hook Job with the key above, which leaves a bucket that exists as it is. The key needs the permission to create buckets. |
| objectStorage.createBuckets.resources | object | `{"limits":{"memory":"256Mi"},"requests":{"cpu":"50m","memory":"128Mi"}}` | Resources of the hook Job's container. |
| timeZone | string | `"UTC"` | Time zone of the instance. |
| omnibus.pumaWorkers | int | `2` | Puma worker processes. 2 fits the 4 GiB memory request. |
| omnibus.sidekiqConcurrency | int | `10` | Sidekiq concurrency. |
| omnibus.extraConfig | string | `""` | Further `gitlab.rb` lines, appended to the generated `GITLAB_OMNIBUS_CONFIG` (a later line wins). |
| http.port | int | `80` | Port nginx listens on in the pod and the Service exposes. |
| ssh.enabled | bool | `false` | Expose git over SSH. Off: clones and pushes go over HTTPS only. |
| ssh.externalPort | int | `22` | Port shown in SSH clone URLs: the NodePort, the Gateway listener's port, or the LoadBalancer port. |
| ssh.service.type | string | `"NodePort"` | Type of the SSH Service: NodePort, LoadBalancer or ClusterIP (behind a TCPRoute). |
| ssh.service.nodePort | string | `nil` | Fixed node port for the NodePort type; empty lets Kubernetes pick one. |
| service.type | string | `"ClusterIP"` | Type of the HTTP Service. |
| httpRoute.enabled | bool | `false` | Render a Gateway API HTTPRoute for `externalUrl`'s host. |
| httpRoute.parentRefs | list | `[]` | Gateways the route attaches to. |
| httpRoute.annotations | object | `{}` | Annotations of the HTTPRoute. |
| tcpRoute.enabled | bool | `false` | Render a Gateway API TCPRoute (v1alpha2) for SSH; needs `ssh.enabled` and a TCP listener on the Gateway. |
| tcpRoute.parentRefs | list | `[]` | Gateways the route attaches to, naming the TCP listener. |
| ingress.enabled | bool | `false` | Render an Ingress for `externalUrl`'s host. |
| ingress.className | string | `"nginx"` | IngressClass of the Ingress. |
| ingress.annotations | object | `{}` | Annotations of the Ingress, e.g. `cert-manager.io/cluster-issuer: letsencrypt-giantswarm`. |
| ingress.tls.enabled | bool | `true` | Terminate TLS at the Ingress with the certificate in `ingress.tls.secretName`. |
| ingress.tls.secretName | string | `""` | Secret of the certificate; empty means `<release>-tls`. |
| networkPolicy.enabled | bool | `true` | Render a NetworkPolicy admitting traffic to the HTTP and SSH ports only. |
| networkPolicy.from | list | `[]` | Peers allowed to reach those ports; empty means from anywhere. |
| persistence.size | string | `"30Gi"` | Size of the volume holding /var/opt/gitlab (the Git repositories of Gitaly) and /etc/gitlab (the generated secrets: keep the volume, or the database's encrypted columns cannot be read). |
| persistence.storageClass | string | `""` | StorageClass of the volume; empty means the cluster's default. |
| persistence.accessMode | string | `"ReadWriteOnce"` | Access mode of the volume. |
| shmSize | string | `"256Mi"` | Size of the memory-backed /dev/shm (Puma and Sidekiq metrics). |
| resources | object | `{"limits":{"memory":"6Gi"},"requests":{"cpu":"2","memory":"4Gi"}}` | Resources of the GitLab container: Puma, Sidekiq, Gitaly, Workhorse and nginx, with PostgreSQL and Redis outside. |
| probes.startupSeconds | int | `900` | Seconds the first set-up may take before liveness checks begin (startupProbe period times failures). |
| podSecurityContext | object | `{"seccompProfile":{"type":"RuntimeDefault"}}` | Pod security context. The Omnibus image starts as root and drops to its service users itself: see the README. |
| securityContext | object | `{"allowPrivilegeEscalation":false,"capabilities":{"add":["CHOWN","DAC_OVERRIDE","FOWNER","SETUID","SETGID","KILL","NET_BIND_SERVICE","SYS_CHROOT","AUDIT_WRITE"],"drop":["ALL"]},"privileged":false,"readOnlyRootFilesystem":false,"seccompProfile":{"type":"RuntimeDefault"}}` | Container security context: no privilege escalation, every capability dropped except those Omnibus' root start needs to chown its data and switch to its service users, and those sshd's privilege separation needs to chroot its pre-authentication child. See the README for the Pod Security exception. |
| nodeSelector | object | `{}` | Node selector of the pod. |
| tolerations | list | `[]` | Tolerations of the pod. |
| affinity | object | `{}` | Affinity of the pod. |
| podAnnotations | object | `{}` | Extra annotations of the pod. |
