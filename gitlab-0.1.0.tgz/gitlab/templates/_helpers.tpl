{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "name" -}}
{{- .Chart.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label. A label value is at
most 63 characters and begins and ends alphanumeric: the cut of a long version
(a branch build's <version>-dev.<branch>.<date>.<time>.<sha>, or the
<version>+<digest> helm-controller installs) can land on any run of ".", "_"
(from "+") and "-", so the whole run is trimmed.
*/}}
{{- define "chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimAll "-._" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "labels.common" -}}
app: {{ include "name" . | quote }}
{{ include "labels.selector" . }}
app.kubernetes.io/managed-by: {{ .Release.Service | quote }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
application.giantswarm.io/team: {{ index .Chart.Annotations "io.giantswarm.application.team" | quote }}
helm.sh/chart: {{ include "chart" . | quote }}
{{- end -}}

{{/*
Labels of the bucket Job: the common labels under a name of its own, so no
selector of the GitLab pod matches it.
*/}}
{{- define "labels.createBuckets" -}}
app: {{ include "name" . | quote }}
app.kubernetes.io/name: {{ printf "%s-create-buckets" (include "name" .) | quote }}
app.kubernetes.io/instance: {{ .Release.Name | quote }}
app.kubernetes.io/component: create-buckets
app.kubernetes.io/managed-by: {{ .Release.Service | quote }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
application.giantswarm.io/team: {{ index .Chart.Annotations "io.giantswarm.application.team" | quote }}
helm.sh/chart: {{ include "chart" . | quote }}
{{- end -}}

{{/*
Selector labels
*/}}
{{- define "labels.selector" -}}
app.kubernetes.io/name: {{ include "name" . | quote }}
app.kubernetes.io/instance: {{ .Release.Name | quote }}
{{- end -}}

{{/*
The name of the release's objects.
*/}}
{{- define "fullname" -}}
{{- if contains .Chart.Name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name .Chart.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{/*
The GitLab image reference.
*/}}
{{- define "image" -}}
{{- printf "%s/%s:%s" .Values.registry.domain .Values.image.name (.Values.image.tag | default .Chart.AppVersion) -}}
{{- end -}}

{{/*
The host of externalUrl.
*/}}
{{- define "host" -}}
{{- $url := urlParse .Values.externalUrl -}}
{{- required "externalUrl needs a scheme and a host, e.g. https://gitlab.example.com" $url.hostname -}}
{{- end -}}

{{/*
The object types of GitLab's consolidated object storage the chart stores in
buckets; pages is the one more type, switched off with GitLab Pages.
*/}}
{{- define "objectTypes" -}}
artifacts external_diffs lfs uploads packages dependency_proxy terraform_state ci_secure_files ci_catalog_bundles
{{- end -}}

{{/*
The bucket of each object type, one name per line in the order of objectTypes;
types may share a bucket.
*/}}
{{- define "buckets" -}}
{{- $buckets := .Values.objectStorage.buckets -}}
{{- range splitList " " (include "objectTypes" .) }}
{{ required (printf "objectStorage.buckets.%s names the bucket of %s" . .) (get $buckets .) }}
{{- end }}
{{- end -}}

{{/*
GITLAB_OMNIBUS_CONFIG: one instance behind a TLS-terminating proxy, on the
installation's PostgreSQL, Redis and object storage, with the parts no test
instance needs switched off. Passwords come from the container's environment
(the Secrets in values), never from the rendered configuration.
*/}}
{{- define "omnibusConfig" -}}
{{- $pg := .Values.postgresql -}}
{{- $redis := .Values.redis -}}
{{- $os := .Values.objectStorage -}}
external_url {{ .Values.externalUrl | quote }}
gitlab_rails['time_zone'] = {{ .Values.timeZone | quote }}
gitlab_rails['gitlab_shell_ssh_port'] = {{ .Values.ssh.externalPort | int }}
nginx['listen_port'] = {{ .Values.http.port | int }}
nginx['listen_https'] = false
nginx['proxy_set_headers'] = { 'X-Forwarded-Proto' => '{{ (urlParse .Values.externalUrl).scheme }}', 'X-Forwarded-Ssl' => '{{ ternary "on" "off" (eq (urlParse .Values.externalUrl).scheme "https") }}' }
letsencrypt['enable'] = false
registry['enable'] = false
gitlab_rails['registry_enabled'] = false
gitlab_kas['enable'] = false
gitlab_pages['enable'] = false
prometheus_monitoring['enable'] = false
puma['worker_processes'] = {{ .Values.omnibus.pumaWorkers | int }}
sidekiq['concurrency'] = {{ .Values.omnibus.sidekiqConcurrency | int }}
gitlab_rails['usage_ping_enabled'] = false
postgresql['enable'] = false
gitlab_rails['db_adapter'] = 'postgresql'
gitlab_rails['db_encoding'] = 'unicode'
gitlab_rails['db_host'] = {{ required "postgresql.host names the PostgreSQL primary" $pg.host | quote }}
gitlab_rails['db_port'] = {{ $pg.port | int }}
gitlab_rails['db_database'] = {{ $pg.database | quote }}
gitlab_rails['db_username'] = {{ $pg.username | quote }}
gitlab_rails['db_password'] = ENV.fetch('GITLAB_DB_PASSWORD')
gitlab_rails['db_sslmode'] = {{ $pg.sslMode | quote }}
redis['enable'] = false
gitlab_rails['redis_host'] = {{ required "redis.host names the Redis-compatible server" $redis.host | quote }}
gitlab_rails['redis_port'] = {{ $redis.port | int }}
gitlab_rails['redis_password'] = ENV.fetch('GITLAB_REDIS_PASSWORD')
gitlab_rails['object_store']['enabled'] = true
gitlab_rails['object_store']['proxy_download'] = true
gitlab_rails['object_store']['connection'] = { 'provider' => 'AWS', 'endpoint' => {{ required "objectStorage.endpoint names the S3 endpoint" $os.endpoint | quote }}, 'region' => {{ $os.region | quote }}, 'path_style' => {{ $os.pathStyle }}, 'aws_access_key_id' => {{ required "objectStorage.accessKeyId is the S3 access key id" $os.accessKeyId | quote }}, 'aws_secret_access_key' => ENV.fetch('GITLAB_OBJECT_STORE_SECRET_KEY') }
{{- range splitList " " (include "objectTypes" .) }}
gitlab_rails['object_store']['objects']['{{ . }}']['bucket'] = {{ required (printf "objectStorage.buckets.%s names the bucket of %s" . .) (get $os.buckets .) | quote }}
{{- end }}
gitlab_rails['object_store']['objects']['pages']['enabled'] = false
gitlab_rails['external_diffs_enabled'] = true
{{- with .Values.omnibus.extraConfig }}
{{ . }}
{{- end }}
{{- end -}}
