# mcp-prometheus

A Helm chart for mcp-prometheus - MCP server for Prometheus metrics

**Homepage:** <https://github.com/giantswarm/mcp-prometheus>

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| Giant Swarm | <team-planeteers@giantswarm.io> |  |

## Source Code

* <https://github.com/giantswarm/mcp-prometheus>

## Requirements

Kubernetes: `>=1.25.0-0`

## Rolling on credential rotation

The server reads its OAuth credentials (the Dex or Google client secret, the
token encryption key, the Valkey password) from a Secret at start and never
again. The pod template carries a `checksum/oauth-secret` annotation so a
changed credential restarts the server:

- With `app.oauth.existingSecret` empty the chart renders the Secret from
  `app.oauth.dexClientSecret` (or `googleClientSecret`), `app.oauth.encryptionKey`
  and `app.oauth.storage.valkey.password`; the annotation is the SHA-256 of that
  Secret's data and follows every change of those values.
- With `app.oauth.existingSecret` set the chart cannot read the Secret; the
  annotation is `app.oauth.existingSecretChecksum` verbatim. Change it in the
  same change that rotates the Secret (a hash over the new data, a counter, a
  date). A Flux `HelmRelease` can instead feed the Secret's keys into the values
  above through `valuesFrom` entries with `targetPath`, so the chart renders the
  Secret itself and the checksum follows the rotation on its own.

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| replicaCount | int | `1` |  |
| image.registry | string | `"gsoci.azurecr.io"` |  |
| image.repository | string | `"giantswarm/mcp-prometheus"` |  |
| image.pullPolicy | string | `"IfNotPresent"` |  |
| image.tag | string | `""` |  |
| imagePullSecrets | list | `[]` |  |
| nameOverride | string | `""` |  |
| fullnameOverride | string | `""` |  |
| serviceAccount.create | bool | `true` |  |
| serviceAccount.automount | bool | `true` |  |
| serviceAccount.annotations | object | `{}` |  |
| serviceAccount.name | string | `""` |  |
| podAnnotations | object | `{}` |  |
| podLabels | object | `{}` |  |
| podSecurityContext.runAsUser | int | `1000` |  |
| podSecurityContext.runAsGroup | int | `1000` |  |
| podSecurityContext.runAsNonRoot | bool | `true` |  |
| podSecurityContext.fsGroup | int | `1000` |  |
| securityContext.readOnlyRootFilesystem | bool | `true` |  |
| securityContext.allowPrivilegeEscalation | bool | `false` |  |
| securityContext.runAsUser | int | `1000` |  |
| securityContext.runAsGroup | int | `1000` |  |
| securityContext.runAsNonRoot | bool | `true` |  |
| securityContext.seccompProfile.type | string | `"RuntimeDefault"` |  |
| securityContext.capabilities.drop[0] | string | `"ALL"` |  |
| service.type | string | `"ClusterIP"` |  |
| service.port | int | `8080` |  |
| service.appProtocol | string | `""` |  |
| ingress.enabled | bool | `false` |  |
| ingress.className | string | `""` |  |
| ingress.annotations | object | `{}` |  |
| ingress.hosts[0].host | string | `"mcp-prometheus.local"` |  |
| ingress.hosts[0].paths[0].path | string | `"/"` |  |
| ingress.hosts[0].paths[0].pathType | string | `"Prefix"` |  |
| ingress.tls | list | `[]` |  |
| resources.limits.cpu | string | `"500m"` |  |
| resources.limits.memory | string | `"512Mi"` |  |
| resources.requests.cpu | string | `"100m"` |  |
| resources.requests.memory | string | `"128Mi"` |  |
| livenessProbe | object | `{}` |  |
| readinessProbe | object | `{}` |  |
| autoscaling.enabled | bool | `false` |  |
| autoscaling.minReplicas | int | `1` |  |
| autoscaling.maxReplicas | int | `100` |  |
| autoscaling.targetCPUUtilizationPercentage | int | `80` |  |
| volumes[0].name | string | `"tmp"` |  |
| volumes[0].emptyDir | object | `{}` |  |
| volumeMounts[0].name | string | `"tmp"` |  |
| volumeMounts[0].mountPath | string | `"/tmp"` |  |
| ciliumNetworkPolicy.enabled | bool | `true` |  |
| ciliumNetworkPolicy.labels | object | `{}` |  |
| ciliumNetworkPolicy.annotations | object | `{}` |  |
| ciliumNetworkPolicy.ingress.muster.namespace | string | `"agent-platform"` |  |
| ciliumNetworkPolicy.ingress.muster.matchLabels."app.kubernetes.io/name" | string | `"muster"` |  |
| ciliumNetworkPolicy.ingress.metricsScrapers[0].namespace | string | `"kube-system"` |  |
| ciliumNetworkPolicy.ingress.metricsScrapers[0].matchLabels."app.kubernetes.io/instance" | string | `"alloy-metrics"` |  |
| ciliumNetworkPolicy.ingress.teleportPeers[0].namespace | string | `"kube-system"` |  |
| ciliumNetworkPolicy.ingress.teleportPeers[0].matchLabels.app | string | `"teleport-kube-agent"` |  |
| ciliumNetworkPolicy.ingress.gatewayPeers[0].namespace | string | `"envoy-gateway-system"` |  |
| ciliumNetworkPolicy.ingress.gatewayPeers[0].matchLabels."app.kubernetes.io/name" | string | `"envoy"` |  |
| ciliumNetworkPolicy.ingress.additionalPeers | list | `[]` |  |
| monitoring.enabled | bool | `true` |  |
| monitoring.serviceMonitor.enabled | bool | `false` |  |
| monitoring.serviceMonitor.labels | object | `{}` |  |
| nodeSelector | object | `{}` |  |
| tolerations | list | `[]` |  |
| affinity | object | `{}` |  |
| app.server.transport | string | `"streamable-http"` |  |
| app.server.httpAddr | string | `":8080"` |  |
| app.server.sseEndpoint | string | `"/sse"` |  |
| app.server.messageEndpoint | string | `"/message"` |  |
| app.server.httpEndpoint | string | `"/mcp"` |  |
| app.server.debug | bool | `false` |  |
| app.server.metricsAddr | string | `":9091"` |  |
| app.oauth.enabled | bool | `false` |  |
| app.oauth.provider | string | `"dex"` |  |
| app.oauth.redirectURL | string | `""` |  |
| app.oauth.google.clientID | string | `""` |  |
| app.oauth.existingSecret | string | `""` |  |
| app.oauth.existingSecretChecksum | string | `""` |  |
| app.oauth.dexClientSecret | string | `""` |  |
| app.oauth.googleClientSecret | string | `""` |  |
| app.oauth.encryptionKey | string | `""` |  |
| app.oauth.allowPublicRegistration | bool | `false` |  |
| app.oauth.allowPrivateIPJWKS | bool | `false` | Permit the configured Dex JWKS endpoint to resolve to private addresses. HTTPS and TLS verification remain required. Dex discovery and token calls already follow HTTP_PROXY, HTTPS_PROXY and NO_PROXY without this setting. |
| app.oauth.allowPrivateURLs | bool | `false` | Deprecated: read as allowPrivateIPJWKS; set that instead. Refused from v0.14.0. |
| app.oauth.dexCASecret.name | string | `""` |  |
| app.oauth.dexCASecret.key | string | `"ca.crt"` |  |
| app.oauth.storage.type | string | `"memory"` |  |
| app.oauth.storage.valkey.url | string | `""` |  |
| app.oauth.storage.valkey.password | string | `""` |  |
| app.oauth.storage.valkey.existingSecret | string | `""` |  |
| app.oauth.storage.valkey.secretKeyPassword | string | `"valkey-password"` |  |
| app.oauth.storage.valkey.tlsEnabled | bool | `false` |  |
| app.oauth.storage.valkey.keyPrefix | string | `"mcp-prometheus:"` |  |
| app.oauth.trustedAudiences | list | `[]` |  |
| app.tenancy.mode | string | `"grafana-organization"` |  |
| app.tenancy.static.tenants | string | `""` |  |
| app.tenancy.static.groups | object | `{}` |  |
| app.env | list | `[]` |  |
| gatewayAPI.enabled | bool | `false` |  |
| gatewayAPI.httpRoute.parentRefs | list | `[]` |  |
| gatewayAPI.httpRoute.hostnames | list | `[]` |  |
| gatewayAPI.httpRoute.labels | object | `{}` |  |
| gatewayAPI.httpRoute.annotations | object | `{}` |  |
| gatewayAPI.httpRoute.rules | list | `[]` |  |
| gatewayAPI.backendTrafficPolicy.enabled | bool | `false` |  |
| gatewayAPI.backendTrafficPolicy.timeout | string | `"0s"` |  |
| gatewayAPI.backendTrafficPolicy.annotations | object | `{}` |  |
| gatewayAPI.backendTrafficPolicy.labels | object | `{}` |  |
