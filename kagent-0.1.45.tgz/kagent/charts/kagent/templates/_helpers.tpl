{{/*
Create a default fully qualified app name.
*/}}
{{- define "kagent.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- if not .Values.nameOverride }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "kagent.labels" -}}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{ include "kagent.selectorLabels" . }}
{{- if .Chart.Version }}
app.kubernetes.io/version: {{ .Chart.Version | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: kagent
{{- with .Values.labels }}
{{ toYaml . | nindent 0 }}
{{- end }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "kagent.selectorLabels" -}}
app.kubernetes.io/name: {{ default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*Default model name*/}}
{{- define "kagent.defaultModelConfigName" -}}
default-model-config
{{- end }}

{{/*
Expand the namespace of the release.
Allows overriding it for multi-namespace deployments in combined charts.
*/}}
{{- define "kagent.namespace" -}}
{{- default .Release.Namespace .Values.namespaceOverride | trunc 63 | trimSuffix "-" -}}
{{- end }}

{{/*
Namespaces where Substrate ate-api-server needs read access to Secrets and ConfigMaps
referenced by generated ActorTemplates (install namespace plus rbac.namespaces).
*/}}
{{- define "kagent.substrate.envSourceNamespaces" -}}
{{- $installNs := include "kagent.namespace" . -}}
{{- $extra := .Values.rbac.namespaces | default list -}}
{{- $all := append $extra $installNs | uniq | sortAlpha -}}
{{- join "," $all -}}
{{- end }}

{{/*
Watch namespaces - transforms list of namespaces cached by the controller into comma-separated string.
Precedence: controller.watchNamespaces (explicit override) > rbac.namespaces > empty (watch all).
*/}}
{{- define "kagent.watchNamespaces" -}}
{{- if .Values.controller.watchNamespaces -}}
  {{- .Values.controller.watchNamespaces | uniq | join "," -}}
{{- else if and .Values.rbac .Values.rbac.namespaces -}}
  {{- .Values.rbac.namespaces | uniq | join "," -}}
{{- end -}}
{{- end -}}

{{/*
Guards on the rbac block
*/}}
{{- define "kagent.rbac.validate" -}}
{{- if and .Values.rbac (hasKey .Values.rbac "clusterScoped") -}}
{{- fail "rbac.clusterScoped has been removed. Leave rbac.namespaces empty for cluster-scoped RBAC, or set rbac.namespaces=[<ns>, ...] for namespaced RBAC." -}}
{{- end -}}
{{- if and .Values.rbac .Values.rbac.namespaces -}}
{{- $installNs := include "kagent.namespace" . -}}
{{- if not (has $installNs .Values.rbac.namespaces) -}}
{{- fail (printf "rbac.namespaces is set but does not include the install namespace %q" $installNs) -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Returns "1" when a PodDisruptionBudget threshold is explicitly set, empty otherwise.

Uses `kindIs "invalid"` rather than `default ""` so that an explicit `0` counts as
set: Helm's `default` treats 0 as empty, which would silently drop a
`maxUnavailable: 0` budget and render a manifest the user never asked for.
An empty string is also treated as unset, so `minAvailable: ""` disables the field.
*/}}
{{- define "kagent.pdb.isSet" -}}
{{- if not (kindIs "invalid" .) -}}
{{- if ne (toString .) "" -}}1{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Guards on a component `pdb` block.

Kubernetes rejects a PodDisruptionBudget that sets both `minAvailable` and
`maxUnavailable`, and a budget that sets neither is meaningless, so both cases
fail at template time with a message naming the offending values path rather
than surfacing later as an opaque API server error.

Call with a dict: (dict "pdb" .Values.controller.pdb "path" "controller.pdb")
*/}}
{{- define "kagent.pdb.validate" -}}
{{- $pdb := .pdb | default dict -}}
{{- if $pdb.enabled -}}
{{- $hasMin := include "kagent.pdb.isSet" $pdb.minAvailable -}}
{{- $hasMax := include "kagent.pdb.isSet" $pdb.maxUnavailable -}}
{{- if and $hasMin $hasMax -}}
{{- fail (printf "%s: minAvailable and maxUnavailable are mutually exclusive. Set exactly one (to use minAvailable, set %s.maxUnavailable=null)." .path .path) -}}
{{- end -}}
{{- if not (or $hasMin $hasMax) -}}
{{- fail (printf "%s is enabled but neither minAvailable nor maxUnavailable is set. Set exactly one." .path) -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
UI selector labels
*/}}
{{- define "kagent.ui.selectorLabels" -}}
{{ include "kagent.selectorLabels" . }}
app.kubernetes.io/component: ui
{{- end }}

{{/*
Controller selector labels
*/}}
{{- define "kagent.controller.selectorLabels" -}}
{{ include "kagent.selectorLabels" . }}
app.kubernetes.io/component: controller
{{- end }}

{{/*
Engine selector labels
*/}}
{{- define "kagent.engine.selectorLabels" -}}
{{ include "kagent.selectorLabels" . }}
app.kubernetes.io/component: engine
{{- end }}

{{/*
Controller labels
*/}}
{{- define "kagent.controller.labels" -}}
{{ include "kagent.labels" . }}
app.kubernetes.io/component: controller
{{- end }}

{{/*
UI labels
*/}}
{{- define "kagent.ui.labels" -}}
{{ include "kagent.labels" . }}
app.kubernetes.io/component: ui
{{- end }}

{{/*
Engine labels
*/}}
{{- define "kagent.engine.labels" -}}
{{ include "kagent.labels" . }}
app.kubernetes.io/component: engine
{{- end }}

{{/*
Check if leader election should be enabled (more than 1 replica)
*/}}
{{- define "kagent.leaderElectionEnabled" -}}
{{- gt (.Values.controller.replicas | int) 1 -}}
{{- end -}}

{{/*
Extract the TCP port from controller.metrics.bindAddress.

Anchors the digit run to the end of the string so every Go-style
address form the controller binary accepts is handled correctly: bare
":port", host-qualified "host:port", and bracketed IPv6 "[::1]:port"
all yield the trailing port. Returns "0" or "" when the binary's
disable sentinel is in use; callers must consult
`kagent.controller.metricsEnabled` before rendering manifests.
*/}}
{{- define "kagent.controller.metricsPort" -}}
{{- regexFind "[0-9]+$" (.Values.controller.metrics.bindAddress | toString) -}}
{{- end -}}

{{/*
Returns "1" when the controller metrics resources (Service, RBAC,
container port, env vars) should render, empty otherwise. Honours both
disable signals: `controller.metrics.enabled=false` and the binary's
own `--metrics-bind-address=0` sentinel reached through `bindAddress`.
The two are equivalent so the field name keeps faith with the binary's
documented contract (see go/core/pkg/app/app.go).
*/}}
{{- define "kagent.controller.metricsEnabled" -}}
{{- $port := include "kagent.controller.metricsPort" . -}}
{{- if and .Values.controller.metrics.enabled $port (ne $port "0") -}}1{{- end -}}
{{- end -}}

{{/*
PostgreSQL service name for the bundled postgres instance
*/}}
{{- define "kagent.postgresqlServiceName" -}}
{{- printf "%s-postgresql" (include "kagent.fullname" .) -}}
{{- end -}}

{{/*
Bundled PostgreSQL image - constructs the full image reference from registry/repository/name/tag
*/}}
{{- define "kagent.postgresql.image" -}}
{{- $pg := .Values.database.postgres.bundled -}}
{{- $parts := compact (list $pg.image.registry $pg.image.repository $pg.image.name) -}}
{{- printf "%s:%s" (join "/" $parts) $pg.image.tag -}}
{{- end -}}

{{/*
Password secret name - returns the chart-managed Secret name for POSTGRES_PASSWORD.
*/}}
{{- define "kagent.passwordSecretName" -}}
{{- printf "%s-postgresql" (include "kagent.fullname" .) -}}
{{- end -}}

{{/*
A2A Base URL - computes the default URL based on the controller service name if not explicitly set.
The `name.namespace.svc` short form is used so the URL resolves regardless of the cluster's DNS domain.
*/}}
{{- define "kagent.a2aBaseUrl" -}}
{{- if .Values.controller.a2aBaseUrl -}}
{{- .Values.controller.a2aBaseUrl -}}
{{- else -}}
{{- printf "http://%s-controller.%s.svc:%d" (include "kagent.fullname" .) (include "kagent.namespace" .) (.Values.controller.service.ports.port | int) -}}
{{- end -}}
{{- end -}}

{{/*
Controller Service host:port for nginx upstream (no scheme).
*/}}
{{- define "kagent.controllerServiceAuthority" -}}
{{- printf "%s-controller.%s.svc:%d" (include "kagent.fullname" .) (include "kagent.namespace" .) (.Values.controller.service.ports.port | int) -}}
{{- end -}}

{{/*
In-cluster HTTP API base for Next.js server-side calls (includes /api).
*/}}
{{- define "kagent.controllerInternalHttpApiBase" -}}
{{- printf "http://%s/api" (include "kagent.controllerServiceAuthority" .) -}}
{{- end -}}

{{/*
imagePullSecrets from global values (for subchart usage).
Reads .Values.global.imagePullSecrets set by the parent chart.
*/}}
{{- define "kagent.imagePullSecrets" -}}
{{- $global := ((.Values.global).imagePullSecrets) | default list -}}
{{- if $global -}}
imagePullSecrets:
{{- toYaml $global | nindent 2 }}
{{- end -}}
{{- end -}}

{{/*
Body of oauth2-proxy's custom sign_in.html template (see
templates/oauth2-proxy-templates.yaml). Kept as its own named template, rather
than inline in that ConfigMap, so oauth2-proxy.extraEnv in values.yaml can hash
the content.

oauth2-proxy renders this as its own Go html/template (not a Helm template) when
it shows the sign-in page to an unauthenticated visitor -- e.g. a request to
/agents/foo is served this page at /oauth2/sign_in?rd=%2Fagents%2Ffoo.
`Redirect` is oauth2-proxy's template variable carrying that original
destination (escaped with a Helm string-literal action so Helm emits it for
oauth2-proxy to evaluate, instead of trying to evaluate it itself). It is
forwarded to kagent's branded /login page.
*/}}
{{- define "kagent.oauth2ProxySignInHTML" -}}
<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="refresh" content="0;url=/login?rd={{ "{{" }} or .Redirect "/" | urlquery {{ "}}" }}">
  <script>window.location.href = "/login?rd={{ "{{" }} or .Redirect "/" | urlquery {{ "}}" }}";</script>
</head>
<body>Redirecting to login...</body>
</html>
{{- end -}}
