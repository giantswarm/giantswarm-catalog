{{- define "kepler-collector.name" -}}
kepler-collector
{{- end -}}

{{- define "kepler-collector.fullname" -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "kepler-collector.labels" -}}
app.kubernetes.io/name: {{ include "kepler-collector.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
io.giantswarm.application.team: {{ index .Chart.Annotations "io.giantswarm.application.team" | quote }}
{{- end -}}

{{- define "kepler-collector.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
{{- default (include "kepler-collector.fullname" .) .Values.serviceAccount.name -}}
{{- else -}}
{{- default "default" .Values.serviceAccount.name -}}
{{- end -}}
{{- end -}}

{{- define "kepler-collector.watermarkConfigMapNamespace" -}}
{{- default .Release.Namespace .Values.config.watermarkConfigMapNamespace -}}
{{- end -}}
