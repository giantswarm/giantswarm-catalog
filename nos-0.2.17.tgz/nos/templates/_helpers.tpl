{{/*
Create chart name and version as used by the chart label. A label value is at
most 63 characters and begins and ends alphanumeric: the cut of a long version
(a branch build's <version>-dev.<branch>.<date>.<time>.<sha>, or the
<version>+<digest> helm-controller installs) can land on any run of ".", "_"
(from "+") and "-", so the whole run is trimmed.
*/}}
{{- define "nos.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimAll "-._" }}
{{- end }}

{{/*
Define nos full name including the Chart release name
*/}}
{{- define "nos.fullname" -}}
{{- $name := .Chart.Name -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- (printf "%s-%s" .Release.Name $name) | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{/*
Nos labels
*/}}
{{- define "nos.labels" -}}
helm.sh/chart: {{ include "nos.chart" . }}
app.kubernetes.io/name: {{ .Chart.Name }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
application.giantswarm.io/team: {{ index .Chart.Annotations "application.giantswarm.io/team" | quote }}
{{- end }}


{{- define "nos.metricsConfigMap.name" -}}
{{- printf "%s-metrics" (include "nos.fullname" .) -}}
{{- end -}}

{{- define "nos.installationInfoConfigMap.name" -}}
{{- printf "%s-installation-info" (include "nos.fullname" .) -}}
{{- end -}}

{{/*{{- define "nos.installationUUID" -}}*/}}
{{/*{{- with lookup "v1" "ConfigMap" .Release.Namespace (include "nos.installationInfoConfigMap.name" . ) }}*/}}
{{/*{{- .data.uuid -}}*/}}
{{/*{{- else -}}*/}}
{{/*{{- uuidv4 -}}*/}}
{{/*{{- end -}}*/}}
{{/*{{- end}}*/}}
