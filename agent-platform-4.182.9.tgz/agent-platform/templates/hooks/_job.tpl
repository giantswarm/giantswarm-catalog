{{/*
The Helm hook Jobs of this chart. A hook is either ONE plain kubectl command in
the gsoci copy of registry.k8s.io/kubectl (gitops.hooks.image; the image is distroless, there is
no shell) or a small shell script in the gsoci copy of alpine/k8s (gitops.hooks.helmImage: kubectl,
helm, jq, /bin/sh) where the hook needs helm or has to tolerate a missing
object. Every hook runs under the restricted pod security profile (the
namespace the FluxInstance labels warns on anything less), as the hook
ServiceAccount (rbac.yaml, cluster-admin, itself a hook at the events its Jobs
need) or — the self-management hooks — as the regular ServiceAccount
<release>-self (self/rbac.yaml, a namespaced Role). Every hook but the
serving teardown renders only with the bundled engine. Hook weights in use:
  -10  the hook ServiceAccount + ClusterRoleBinding (rbac.yaml, pre-delete; and
       pre-install + pre-upgrade while the kagent namespace hook renders) and
       the hook identity's
       network policy (netpol.yaml: egress to the apiserver for every pod
       labelled component: hooks, at every event a hook of this chart runs —
       a default-deny cluster admits nothing else, #413)
   -9  server-side apply the four Flux Operator CRDs of the flux-engine
       subchart (hooks/flux-operator-crds.yaml; pre-install, pre-upgrade;
       their ConfigMap at -10)
   -8  create the namespace the kagent component installs into if it is
       missing (hooks/kagent-namespace.yaml; pre-install, pre-upgrade)
   -6  stop a resumer Job still running from the last operation (hooks/self.yaml;
       pre-delete — and pre-upgrade when self-management is off, the hand-back)
   -5  suspend the chart's own HelmRelease and drop the values Secret
       (hooks/self.yaml; same events as -6)
   -2  the serving teardown: the llm-d controller's release, the well-known
       LLMInferenceServiceConfigs with their finalizer, the configs' release
       (hooks/serving-teardown.yaml; pre-delete, or pre-upgrade when the
       serving slice is switched off in place; a script in the helm image)
    0  delete the platform HelmReleases in reverse dependency order and wait
       per wave (teardown.yaml, pre-delete; a script in the helm image);
       write the user-supplied values into the values Secret and start the
       resumer (hooks/self.yaml, post-install + post-upgrade);
       delete the FluxInstance, kept through Helm's pass, and wait for the
       operator to uninstall Flux (teardown.yaml, post-delete)
    5  delete the Flux Operator, kept through Helm's pass (teardown.yaml,
       post-delete)
before-hook-creation clears a previous run's Job (a failed one is left in place
for inspection until the next attempt), hook-succeeded removes every hook
object once ALL hooks of the event succeeded — Helm applies that policy after
the last hook, so the ServiceAccount outlives the Jobs that need it.
*/}}

{{/*
Common hook ServiceAccount name (one per release; cluster-scoped binding of the
same name).
*/}}
{{- define "agent-platform.hooks.serviceAccountName" -}}
{{- printf "%s-hooks" .Release.Name -}}
{{- end -}}

{{/*
The kubectl image the hooks run.
*/}}
{{- define "agent-platform.hooks.image" -}}
{{- $i := .Values.gitops.hooks.image -}}
{{- include "agent-platform.mirror.ref" (dict "ref" (printf "%s/%s:%s" $i.registry $i.repository $i.tag) "mirror" (include "agent-platform.mirror.registry" .)) -}}
{{- end -}}

{{/*
The ephemeral-storage request and limit of every hook container, and the
sizeLimit of the /tmp emptyDir it mounts (the limit). Kyverno's
require-emptydir-requests-and-limits refuses a container mounting an emptyDir
without them. /tmp holds kubectl's discovery and HTTP cache, helm's cache and
config and a script's few small files; nothing in it scales with the cluster.
*/}}
{{- define "agent-platform.hooks.tmpRequest" -}}16Mi{{- end -}}
{{- define "agent-platform.hooks.tmpLimit" -}}256Mi{{- end -}}

{{/*
One hook Job. Arguments (a dict):
  root    the top-level context
  name    Job name suffix (the Job is <release>-<name>)
  hook    the helm.sh/hook event(s), e.g. pre-delete
  weight  the helm.sh/hook-weight
  args    kubectl arguments (a list; the entrypoint is kubectl) — OR
  script  a shell script (run as `sh -eu -c` in the helm image)
  image   the image, default gitops.hooks.image (pass the helm image for a script)
  serviceAccountName  default the hook ServiceAccount <release>-hooks
  configMap  a ConfigMap mounted read-only at /manifests (optional)
  backoffLimit  the Job's retries, default 2 (0 for a hook that refuses on purpose)
  about   one line for the humans reading the manifest
*/}}
{{- define "agent-platform.hooks.job" -}}
{{- $root := .root -}}
{{- $image := .image | default (include "agent-platform.hooks.image" $root) -}}
{{- $sa := .serviceAccountName | default (include "agent-platform.hooks.serviceAccountName" $root) -}}
apiVersion: batch/v1
kind: Job
metadata:
  name: {{ printf "%s-%s" $root.Release.Name .name }}
  namespace: {{ $root.Release.Namespace }}
  labels:
    {{- include "labels.common" $root | nindent 4 }}
    app.kubernetes.io/component: hooks
  annotations:
    helm.sh/hook: {{ .hook }}
    helm.sh/hook-weight: {{ .weight | quote }}
    helm.sh/hook-delete-policy: before-hook-creation,hook-succeeded
    agent-platform.giantswarm.io/about: {{ .about | quote }}
spec:
  # kubectl waits up to 5 minutes for the deletions it requested; the Job gives
  # up after 10 and Helm's --timeout bounds the whole event. Two retries cover a
  # transient API error; a hook that still fails aborts the operation before
  # Helm deletes anything (a failed pre-delete hook leaves the release
  # `uninstalling` and the platform untouched).
  backoffLimit: {{ ternary .backoffLimit 2 (hasKey . "backoffLimit") }}
  activeDeadlineSeconds: 600
  # hook-succeeded removes a finished Job; a failed one is kept for an hour.
  ttlSecondsAfterFinished: 3600
  template:
    metadata:
      labels:
        {{- include "labels.common" $root | nindent 8 }}
        app.kubernetes.io/component: hooks
    spec:
      serviceAccountName: {{ $sa }}
      restartPolicy: Never
      securityContext:
        runAsNonRoot: true
        runAsUser: 65532
        runAsGroup: 65532
        seccompProfile:
          type: RuntimeDefault
      {{- with $root.Values.global.imagePullSecrets }}
      imagePullSecrets:
        {{- range . }}
        - name: {{ if kindIs "map" . }}{{ .name }}{{ else }}{{ . }}{{ end }}
        {{- end }}
      {{- end }}
      containers:
        - name: {{ ternary "sh" "kubectl" (hasKey . "script") }}
          image: {{ $image | quote }}
          {{- if hasKey . "script" }}
          command: ["/bin/sh", "-eu", "-c"]
          args:
            - |
              {{- .script | nindent 14 }}
          {{- else }}
          args:
            {{- range .args }}
            - {{ . | quote }}
            {{- end }}
          {{- end }}
          env:
            # kubectl keeps its discovery cache and helm its cache and config
            # under $HOME; the root filesystem is read-only.
            - name: HOME
              value: /tmp
          securityContext:
            allowPrivilegeEscalation: false
            readOnlyRootFilesystem: true
            capabilities:
              drop:
                - ALL
          # The requests stay small: a hook is a burst of kubectl runs. The limit
          # is headroom, not a budget — one kubectl run peaks near 50 MiB, the
          # Helm CLI near 80 MiB, the decode of one release Secret near 35 MiB,
          # and nothing a hook does scales with the cluster. A hook pod was OOM-killed at
          # 128Mi three seconds into its first kubectl calls on a busy node
          # (giantswarm/agent-platform#593); 512Mi is four times that pod's
          # whole budget and is never approached in a normal run.
          resources:
            requests:
              cpu: 10m
              memory: 32Mi
              ephemeral-storage: {{ include "agent-platform.hooks.tmpRequest" $root }}
            limits:
              memory: 512Mi
              ephemeral-storage: {{ include "agent-platform.hooks.tmpLimit" $root }}
          volumeMounts:
            - name: tmp
              mountPath: /tmp
            {{- if .configMap }}
            - name: manifests
              mountPath: /manifests
              readOnly: true
            {{- end }}
      volumes:
        - name: tmp
          emptyDir:
            sizeLimit: {{ include "agent-platform.hooks.tmpLimit" $root }}
        {{- with .configMap }}
        - name: manifests
          configMap:
            name: {{ . }}
        {{- end }}
{{- end -}}
