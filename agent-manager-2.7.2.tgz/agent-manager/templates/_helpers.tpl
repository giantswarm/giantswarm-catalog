{{/*
Expand the name of the chart.
*/}}
{{- define "agent-manager.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "agent-manager.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Chart label value. A label value must begin and end alphanumeric: the
63-character cut of a dev version (0.2.10-dev.<branch>.<date>.<time>.h<sha>)
can land on any run of ".", "_" (from "+") and "-", so the whole run is trimmed.
*/}}
{{- define "agent-manager.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimAll "-._" }}
{{- end }}

{{/*
Common labels.
*/}}
{{- define "agent-manager.labels" -}}
helm.sh/chart: {{ include "agent-manager.chart" . }}
{{ include "agent-manager.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
application.giantswarm.io/team: {{ index .Chart.Annotations "io.giantswarm.application.team" | quote }}
{{- end }}

{{/*
Selector labels.
*/}}
{{- define "agent-manager.selectorLabels" -}}
app.kubernetes.io/name: {{ include "agent-manager.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
ServiceAccount name.
*/}}
{{- define "agent-manager.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "agent-manager.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Every namespace agents may live in: kagent.namespace plus the additional ones,
deduplicated. Rendered as a JSON list.
*/}}
{{- define "agent-manager.managedNamespaces" -}}
{{- $all := list .Values.kagent.namespace -}}
{{- range .Values.kagent.additionalNamespaces -}}
{{- $all = append $all . -}}
{{- end -}}
{{- $all | uniq | toJson -}}
{{- end }}

{{/*
The platform identity contract (global.identity), an empty dict when absent.
*/}}
{{- define "agent-manager.globalIdentity" -}}
{{- dig "identity" (dict) (.Values.global | default dict) | toJson }}
{{- end }}

{{/*
Whether the ServiceAccount holds any RBAC: not with downstream OAuth, where
every Kubernetes call carries the caller's token.
*/}}
{{- define "agent-manager.serviceAccountRBAC" -}}
{{- if and .Values.rbac.create (not (and .Values.oauth.enabled .Values.oauth.downstream.enabled)) }}true{{ end }}
{{- end }}

{{/*
The ClusterRole the tenant reconciler binds to the agents' Flux ServiceAccount
in every tenant namespace.
*/}}
{{- define "agent-manager.tenantFluxClusterRole" -}}
agent-platform-tenant-flux
{{- end }}

{{/*
The network policy resource the tenant reconciler copies, as
{"group": ..., "resource": ...}; empty without a flavor or without names.
*/}}
{{- define "agent-manager.tenantNetworkPolicyResource" -}}
{{- $flavor := .Values.tenants.networkPolicy.flavor -}}
{{- if and $flavor .Values.tenants.networkPolicy.names -}}
{{- if eq $flavor "kubernetes" -}}
{{- dict "group" "networking.k8s.io" "resource" "networkpolicies" | toJson -}}
{{- else if eq $flavor "cilium" -}}
{{- dict "group" "cilium.io" "resource" "ciliumnetworkpolicies" | toJson -}}
{{- else -}}
{{- fail (printf "tenants.networkPolicy.flavor %q: kubernetes, cilium or empty" $flavor) -}}
{{- end -}}
{{- end -}}
{{- end }}

{{/*
Existing Secret with the provider credentials: oauth.existingSecret, else the
platform's global.identity.existingSecret, else the chart-rendered one.
*/}}
{{- define "agent-manager.oauthSecretName" -}}
{{- $g := include "agent-manager.globalIdentity" . | fromJson -}}
{{- .Values.oauth.existingSecret | default (dig "existingSecret" "" $g) | default (printf "%s-oauth" (include "agent-manager.fullname" .)) }}
{{- end }}

{{/*
Whether the chart renders its own OAuth Secret (no existing one named).
*/}}
{{- define "agent-manager.oauthRendersSecret" -}}
{{- $g := include "agent-manager.globalIdentity" . | fromJson -}}
{{- if and .Values.oauth.enabled (not .Values.oauth.existingSecret) (not (dig "existingSecret" "" $g)) }}true{{ end }}
{{- end }}

{{/*
OAuth base URL: oauth.baseURL, else https://<fullname>.<global.domain>.
*/}}
{{- define "agent-manager.oauthBaseURL" -}}
{{- $domain := dig "domain" "" (.Values.global | default dict) -}}
{{- $derived := "" -}}
{{- if $domain }}{{ $derived = printf "https://%s.%s" (include "agent-manager.fullname" .) $domain }}{{ end -}}
{{- required "oauth.baseURL is required when oauth.enabled (or set global.domain)" (.Values.oauth.baseURL | default $derived) }}
{{- end }}

{{/*
Dex issuer / client id with the global.identity fallbacks.
*/}}
{{- define "agent-manager.oauthDexIssuerURL" -}}
{{- $g := include "agent-manager.globalIdentity" . | fromJson -}}
{{- required "oauth.dex.issuerURL (or global.identity.issuerUrl) is required for the dex provider" (.Values.oauth.dex.issuerURL | default (dig "issuerUrl" "" $g)) }}
{{- end }}

{{- define "agent-manager.oauthDexClientID" -}}
{{- $g := include "agent-manager.globalIdentity" . | fromJson -}}
{{- required "oauth.dex.clientID (or global.identity.clientId) is required for the dex provider" (.Values.oauth.dex.clientID | default (dig "clientId" "" $g)) }}
{{- end }}

{{/*
CA Secret of a private-certificate Dex: oauth.dex.caSecret, else
global.identity.ca. Name empty means system trust.
*/}}
{{- define "agent-manager.oauthDexCASecretName" -}}
{{- $g := include "agent-manager.globalIdentity" . | fromJson -}}
{{- .Values.oauth.dex.caSecret.name | default (dig "ca" "secretName" "" $g) }}
{{- end }}

{{- define "agent-manager.oauthDexCASecretKey" -}}
{{- $g := include "agent-manager.globalIdentity" . | fromJson -}}
{{- if .Values.oauth.dex.caSecret.name }}{{ .Values.oauth.dex.caSecret.key | default "ca.crt" }}{{ else }}{{ dig "ca" "key" "" $g | default .Values.oauth.dex.caSecret.key | default "ca.crt" }}{{ end }}
{{- end }}

{{/*
Trusted audiences, comma-separated: oauth.trustedAudiences (else the platform
client id, global.identity.clientId) plus muster.mcpServer.auth.requiredAudiences,
de-duplicated, order kept. Every token muster forwards carries the required
audiences by construction, and they are the audiences the kube-apiserver
trusts — the trust anchor for a server whose only use of the token is to
present it downstream. The platform client alone refuses a portal session:
its id_token names the portal's own client next to the required audiences,
never the platform client. A Google installation requires no audiences, so
the union adds nothing there.
*/}}
{{- define "agent-manager.oauthTrustedAudiences" -}}
{{- $g := include "agent-manager.globalIdentity" . | fromJson -}}
{{- $all := .Values.oauth.trustedAudiences | default (compact (list (dig "clientId" "" $g))) -}}
{{- range .Values.muster.mcpServer.auth.requiredAudiences -}}
{{- $all = append $all . -}}
{{- end -}}
{{- $all | uniq | join "," -}}
{{- end }}

{{/*
The OTLP collector the pod exports to, as YAML {namespace, port}: the
namespace of an in-cluster Service host (<svc>.<ns>.svc[.cluster.local]),
empty for any other host; the endpoint's port, else the protocol's default
(4317 gRPC, 4318 HTTP). Empty when no endpoint is set.
*/}}
{{- define "agent-manager.otlpEgress" -}}
{{- with .Values.observability.otel.endpoint -}}
{{- $url := urlParse (ternary . (printf "grpc://%s" .) (contains "://" .)) -}}
{{- $hostPort := splitList ":" $url.host -}}
{{- $host := first $hostPort -}}
{{- $port := ternary (last $hostPort) "" (gt (len $hostPort) 1) -}}
{{- if not $port -}}
{{- $port = ternary "4318" "4317" (hasPrefix "http/" ($.Values.observability.otel.protocol | default "grpc")) -}}
{{- end -}}
{{- $labels := splitList "." $host -}}
{{- $namespace := "" -}}
{{- if and (ge (len $labels) 3) (eq (index $labels 2) "svc") -}}
{{- $namespace = index $labels 1 -}}
{{- end -}}
namespace: {{ $namespace | quote }}
port: {{ $port }}
{{- end -}}
{{- end -}}

{{/*
The kagent controller target's egress, when the session tools are on:
namespace (empty unless the host is <service>.<namespace>.svc...) and port.
*/}}
{{- define "agent-manager.kagentEgress" -}}
{{- if and .Values.oauth.enabled .Values.kagent.controllerTarget -}}
{{- $url := urlParse .Values.kagent.controllerTarget -}}
{{- if not (has $url.scheme (list "grpc" "grpcs")) -}}
{{- fail (printf "kagent.controllerTarget %q must be grpc://host:port or grpcs://host[:port]" .Values.kagent.controllerTarget) -}}
{{- end -}}
{{- $hostPort := splitList ":" $url.host -}}
{{- $port := ternary (last $hostPort) "" (gt (len $hostPort) 1) -}}
{{- if not $port -}}
{{- if eq $url.scheme "grpc" -}}
{{- fail (printf "kagent.controllerTarget %q must name a port" .Values.kagent.controllerTarget) -}}
{{- end -}}
{{- $port = "443" -}}
{{- end -}}
{{- $labels := splitList "." (first $hostPort) -}}
{{- $namespace := "" -}}
{{- if and (ge (len $labels) 3) (eq (index $labels 2) "svc") -}}
{{- $namespace = index $labels 1 -}}
{{- end -}}
namespace: {{ $namespace | quote }}
port: {{ $port }}
{{- end -}}
{{- end -}}

{{/*
muster's session bindings endpoint as egress: the Service's namespace for an
in-cluster host (<name>.<namespace>.svc...), the port the URL names or its
scheme's. Rendered with the session tools only (oauth and a controller
target), as the flag is.
*/}}
{{- define "agent-manager.musterBindingsEgress" -}}
{{- if and .Values.oauth.enabled .Values.kagent.controllerTarget .Values.muster.bindingsUrl -}}
{{- $url := urlParse .Values.muster.bindingsUrl -}}
{{- if not (has $url.scheme (list "http" "https")) -}}
{{- fail (printf "muster.bindingsUrl %q must be http(s)://host[:port]/session-bindings" .Values.muster.bindingsUrl) -}}
{{- end -}}
{{- $hostPort := splitList ":" $url.host -}}
{{- $port := ternary (last $hostPort) (ternary "443" "80" (eq $url.scheme "https")) (gt (len $hostPort) 1) -}}
{{- $labels := splitList "." (first $hostPort) -}}
{{- $namespace := "" -}}
{{- if and (ge (len $labels) 3) (eq (index $labels 2) "svc") -}}
{{- $namespace = index $labels 1 -}}
{{- end -}}
namespace: {{ $namespace | quote }}
port: {{ $port }}
{{- end -}}
{{- end -}}

{{/*
The installation's skills boot Secret: the minted one, else
skills.gitAuthSecretName. The minted one is the installation's own,
<fullname>-skills-token, never under the tenant-credential- prefix that marks a
tenant's own credentials: admission refuses a reference to it in an
Organization's namespace.
*/}}
{{- define "agent-manager.skillsGitAuthSecretName" -}}
{{- if .Values.skills.mintGitAuthSecret -}}
{{- if .Values.skills.gitAuthSecretName -}}
{{- fail "skills.mintGitAuthSecret and skills.gitAuthSecretName are mutually exclusive: the minted Secret is the installation's skills credential" -}}
{{- end -}}
{{- if not .Values.skills.github.app.secretName -}}
{{- fail "skills.mintGitAuthSecret needs skills.github.app.secretName: the Secret is filled with the skills GitHub App's installation token" -}}
{{- end -}}
{{- printf "%s-skills-token" (include "agent-manager.fullname" .) -}}
{{- else -}}
{{- .Values.skills.gitAuthSecretName -}}
{{- end -}}
{{- end }}

{{/*
The earlier names of the installation's skills boot Secret, a JSON list:
skills.previousGitAuthSecretNames and, when minting, the minted Secret's
earlier name under the tenant-credential- prefix. Agents naming one are moved
to the current name; while minting, each is rendered and kept filled as well.
*/}}
{{- define "agent-manager.skillsGitAuthPreviousSecretNames" -}}
{{- $names := list -}}
{{- if .Values.skills.mintGitAuthSecret -}}
{{- $names = append $names (printf "tenant-credential-%s-skills-token" (include "agent-manager.fullname" .)) -}}
{{- end -}}
{{- $current := include "agent-manager.skillsGitAuthSecretName" . -}}
{{- range .Values.skills.previousGitAuthSecretNames -}}
{{- if and (ne . $current) (not (has . $names)) -}}
{{- $names = append $names . -}}
{{- end -}}
{{- end -}}
{{- $names | toJson -}}
{{- end }}
