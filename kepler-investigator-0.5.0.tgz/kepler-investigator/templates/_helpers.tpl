{{- define "kepler-investigator.name" -}}
kepler-investigator
{{- end -}}

{{- define "kepler-investigator.fullname" -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "kepler-investigator.labels" -}}
app.kubernetes.io/name: {{ include "kepler-investigator.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
io.giantswarm.application.team: {{ index .Chart.Annotations "io.giantswarm.application.team" | quote }}
{{- end -}}

{{- define "kepler-investigator.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
{{- default (include "kepler-investigator.fullname" .) .Values.serviceAccount.name -}}
{{- else -}}
{{- default "default" .Values.serviceAccount.name -}}
{{- end -}}
{{- end -}}
